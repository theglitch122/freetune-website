// Lyrics translations, like Spotify's: each line of the lyrics with its translation under it,
// and the pronunciation (romanization) for lyrics in another alphabet, such as Japanese,
// Korean, Chinese, Arabic or Russian.
//
// Uses Google Translate's free web endpoint, the same one the translate.google.com page uses.
// Only the lyrics text is sent, only when you ask for a translation, with no account or
// cookies. Results are kept on this device, so a song is only translated once per language.

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36';
const ENDPOINT = 'https://translate.googleapis.com/translate_a/single';
const TIMEOUT_MS = 12000;
const MAX_CHARS = 4500; // per request

// Languages people can pick in Settings (code -> name in that language and in English).
const LANGUAGES = [
  ['en', 'English'], ['es', 'Español (Spanish)'], ['pt', 'Português (Portuguese)'], ['fr', 'Français (French)'], ['de', 'Deutsch (German)'],
  ['it', 'Italiano (Italian)'], ['nl', 'Nederlands (Dutch)'], ['pl', 'Polski (Polish)'], ['tr', 'Türkçe (Turkish)'], ['ru', 'Русский (Russian)'],
  ['uk', 'Українська (Ukrainian)'], ['ar', 'العربية (Arabic)'], ['hi', 'हिन्दी (Hindi)'], ['bn', 'বাংলা (Bengali)'], ['ur', 'اردو (Urdu)'],
  ['id', 'Bahasa Indonesia (Indonesian)'], ['vi', 'Tiếng Việt (Vietnamese)'], ['th', 'ไทย (Thai)'], ['tl', 'Filipino'], ['ja', '日本語 (Japanese)'],
  ['ko', '한국어 (Korean)'], ['zh-CN', '中文 简体 (Chinese, Simplified)'], ['zh-TW', '中文 繁體 (Chinese, Traditional)'], ['sv', 'Svenska (Swedish)'],
  ['no', 'Norsk (Norwegian)'], ['da', 'Dansk (Danish)'], ['fi', 'Suomi (Finnish)'], ['el', 'Ελληνικά (Greek)'], ['he', 'עברית (Hebrew)'],
  ['cs', 'Čeština (Czech)'], ['ro', 'Română (Romanian)'], ['hu', 'Magyar (Hungarian)'],
];
const NAMES = Object.fromEntries(LANGUAGES.map(([c, n]) => [c, n.replace(/^.*\((.*)\)$/, '$1')]));
NAMES.en = 'English';
NAMES.tl = 'Filipino';
const EXTRA_NAMES = { la: 'Latin', ca: 'Catalan', ga: 'Irish', cy: 'Welsh', sw: 'Swahili', yo: 'Yoruba', zu: 'Zulu', af: 'Afrikaans', ms: 'Malay', fa: 'Persian', ta: 'Tamil', te: 'Telugu', pa: 'Punjabi', mr: 'Marathi', gu: 'Gujarati', sr: 'Serbian', hr: 'Croatian', bg: 'Bulgarian', sk: 'Slovak', sl: 'Slovenian', lt: 'Lithuanian', lv: 'Latvian', et: 'Estonian', is: 'Icelandic', ht: 'Haitian Creole', haw: 'Hawaiian', 'zh-CN': 'Chinese', zh: 'Chinese', iw: 'Hebrew' };
const langName = (code) => NAMES[code] || EXTRA_NAMES[code] || EXTRA_NAMES[String(code).split('-')[0]] || NAMES[String(code).split('-')[0]] || code;
const sameLang = (a, b) => String(a || '').toLowerCase().split('-')[0].replace('iw', 'he') === String(b || '').toLowerCase().split('-')[0].replace('iw', 'he');

// Picks a language from a locale like "pt-BR" or "zh-Hant-TW".
function pickLanguage(locale) {
  const l = String(locale || 'en').toLowerCase();
  if (/^zh.*(tw|hk|hant)/.test(l)) return 'zh-TW';
  if (/^zh/.test(l)) return 'zh-CN';
  if (/^(nb|nn|no)/.test(l)) return 'no';
  if (/^(fil|tl)/.test(l)) return 'tl';
  const base = l.split(/[-_]/)[0];
  return LANGUAGES.some(([c]) => c === base) ? base : 'en';
}

// Google's answer: [ [ [translated, original, ...], ..., [null, null, translitTarget, translitSource] ], null, "detected", ... ]
function parseAnswer(json) {
  if (!Array.isArray(json) || !Array.isArray(json[0])) throw new Error('The translation service sent something unexpected');
  let text = '';
  let roman = '';
  for (const seg of json[0]) {
    if (!Array.isArray(seg)) continue;
    if (typeof seg[0] === 'string') text += seg[0];
    else if (seg[0] == null && typeof seg[3] === 'string') roman += seg[3];
  }
  const detected = typeof json[2] === 'string' ? json[2] : (json[8] && json[8][0] && json[8][0][0]) || '';
  return { text, roman, detected };
}

// Lines are sent in a few large requests (not one per line), separated by newlines; each
// request's answer is split back into the same number of lines.
function chunk(lines) {
  const out = [];
  let cur = [];
  let len = 0;
  for (const l of lines) {
    if (cur.length && len + l.length + 1 > MAX_CHARS) {
      out.push(cur);
      cur = [];
      len = 0;
    }
    cur.push(l);
    len += l.length + 1;
  }
  if (cur.length) out.push(cur);
  return out;
}

class Translator {
  constructor({ store, log = console.log, fetchImpl } = {}) {
    this.store = store; // JsonStore: key -> { at, lang, detected, lines, roman }
    this.log = log;
    this.fetch = fetchImpl || ((...a) => fetch(...a));
  }

  async _request(text, target, { roman = true } = {}) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
    const qs = new URLSearchParams({ client: 'gtx', sl: 'auto', tl: target, dj: '0', ie: 'UTF-8', oe: 'UTF-8' });
    let url = `${ENDPOINT}?${qs}&dt=t${roman ? '&dt=rm' : ''}`;
    try {
      const res = await this.fetch(url, {
        method: 'POST',
        signal: ctrl.signal,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'User-Agent': UA, Accept: '*/*' },
        body: 'q=' + encodeURIComponent(text),
      });
      if (res.status === 429) throw new Error('The translation service is busy. Try again in a minute.');
      if (!res.ok) throw new Error(`The translation service answered ${res.status}`);
      return parseAnswer(await res.json());
    } catch (e) {
      if (e && e.name === 'AbortError') throw new Error('The translation service took too long to answer.');
      if (e instanceof TypeError) throw new Error('Couldn’t reach the translation service. Check your internet connection.');
      throw e;
    } finally {
      clearTimeout(timer);
    }
  }

  // lines: the lyric lines (strings, '' for gaps). Returns
  // { lang, detected, detectedName, same, lines: [translation per line], roman: [per line] | null }
  async translate(key, lines, target) {
    target = target || 'en';
    const id = `${key}|${target}`;
    const hit = this.store && this.store.get(id);
    if (hit && Array.isArray(hit.lines) && hit.lines.length === lines.length) return this._shape(hit, target);

    // Only lines with words are sent (gaps and ♪ stay as they are).
    const idx = [];
    const texts = [];
    lines.forEach((l, i) => {
      const t = String(l || '').replace(/\s+/g, ' ').trim();
      if (t && /[\p{L}\p{N}]/u.test(t)) {
        idx.push(i);
        texts.push(t);
      }
    });
    const out = new Array(lines.length).fill('');
    const rom = new Array(lines.length).fill('');
    let detected = '';
    let romanOk = true;
    let pos = 0;
    for (const part of chunk(texts)) {
      const ans = await this._request(part.join('\n'), target);
      detected = detected || ans.detected;
      let got = ans.text.split('\n');
      if (got.length !== part.length) {
        // The service merged or split lines: translate this part line by line instead.
        this.log('translate: line count changed', got.length, '!=', part.length, '- going line by line');
        got = [];
        for (const one of part) got.push((await this._request(one, target, { roman: false })).text.trim());
        romanOk = false;
      }
      const r = ans.roman ? ans.roman.split('\n') : [];
      if (r.length !== part.length) romanOk = false;
      part.forEach((_, k) => {
        out[idx[pos + k]] = (got[k] || '').trim();
        if (romanOk) rom[idx[pos + k]] = (r[k] || '').trim();
      });
      pos += part.length;
    }
    // Pronunciation is only worth showing for another alphabet (not for, say, Spanish).
    const nonLatin = texts.some((t) => /[^\u0000-ɏḀ-ỿ\s\p{P}\p{N}\p{S}]/u.test(t));
    const entry = { at: Date.now(), lang: target, detected, lines: out, roman: romanOk && nonLatin && rom.some(Boolean) ? rom : null };
    if (this.store) {
      this.store.set(id, entry);
      this._trim();
    }
    return this._shape(entry, target);
  }

  _shape(e, target) {
    return { lang: target, langName: langName(target), detected: e.detected, detectedName: e.detected ? langName(e.detected) : '', same: sameLang(e.detected, target), lines: e.lines, roman: e.roman || null };
  }

  _trim() {
    const all = this.store.data;
    if (!all) return;
    const keys = Object.keys(all);
    if (keys.length <= 400) return;
    keys.sort((a, b) => (all[a].at || 0) - (all[b].at || 0)).slice(0, keys.length - 400).forEach((k) => this.store.delete(k));
  }
}

module.exports = { Translator, LANGUAGES, pickLanguage, parseAnswer, langName, sameLang };
