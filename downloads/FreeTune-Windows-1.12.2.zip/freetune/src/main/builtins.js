// Albums FreeTune adds to Your Library by itself, for music that isn't on Spotify. They're
// ordinary playlists on this device: each song is found on YouTube when it's played (and
// "Wrong song?" fixes a bad match). Each is added once; deleting it keeps it deleted.

const TYLER = { name: 'Tyler, The Creator' };
const feat = (...names) => [TYLER, ...names.map((name) => ({ name }))];
const ms = (m, s) => (m * 60 + s) * 1000;

// FreeTune's own cover for a built-in album (not the release's artwork): its title set
// large on a colour field, with the artist and year underneath.
function cover({ title, artist, year, from, to, ink = '#fff' }) {
  const esc = (x) => String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="640" viewBox="0 0 640 640">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${from}"/><stop offset="1" stop-color="${to}"/></linearGradient>
<radialGradient id="v" cx=".3" cy=".25" r=".9"><stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".45"/></radialGradient></defs>
<rect width="640" height="640" fill="url(#g)"/><rect width="640" height="640" fill="url(#v)"/>
<rect x="40" y="40" width="560" height="560" fill="none" stroke="${ink}" stroke-opacity=".35" stroke-width="2"/>
<text x="64" y="300" font-family="Georgia, 'Times New Roman', serif" font-style="italic" font-weight="700" font-size="118" fill="${ink}" letter-spacing="-3">${esc(title)}</text>
<line x1="64" y1="340" x2="300" y2="340" stroke="${ink}" stroke-width="4"/>
<text x="64" y="400" font-family="Arial, Helvetica, sans-serif" font-weight="700" font-size="34" fill="${ink}" letter-spacing="2">${esc(artist.toUpperCase())}</text>
<text x="64" y="560" font-family="Arial, Helvetica, sans-serif" font-size="28" fill="${ink}" fill-opacity=".7" letter-spacing="6">${esc(year)}</text>
</svg>`;
  return 'data:image/svg+xml,' + encodeURIComponent(svg.replace(/\n/g, ''));
}

const BUILTINS = [
  {
    key: 'tyler-bastard-2009',
    name: 'Bastard',
    cover: cover({ title: 'Bastard', artist: 'Tyler, The Creator', year: '2009', from: '#8a1c12', to: '#1a0c0a', ink: '#f4e9d8' }),
    description: 'Tyler, The Creator’s 2009 mixtape, released free on Odd Future’s website. It isn’t on Spotify, so the songs play from YouTube.',
    tracks: [
      ['Bastard', [TYLER], ms(6, 9)],
      ['Seven', [TYLER], ms(3, 29)],
      ['Odd Toddlers', feat('Casey Veggies'), ms(3, 36)],
      ['French!', feat('Hodgy Beats'), ms(4, 3)],
      ['Blow', [TYLER], ms(2, 55)],
      ['Pigs Fly', feat('Domo Genesis'), ms(3, 35)],
      ['Parade', [TYLER], ms(2, 23)],
      ['Slow It Down', feat('Hodgy Beats'), ms(3, 8)],
      ['AssMilk', feat('Earl Sweatshirt'), ms(3, 40)],
      ['VCR / Wheels', [TYLER], ms(3, 28)],
      ['Session', feat('Hodgy Beats', 'Brandun DeShay', 'Mike G'), ms(3, 35)],
      ['Sarah', [TYLER], ms(4, 47)],
      ['Jack and the Beanstalk', [TYLER], ms(3, 51)],
      ['Tina', feat('Jasper Dolphin', 'Taco'), ms(3, 7)],
      ['Inglorious', [TYLER], ms(4, 5)],
    ],
  },
];

// A built-in song: no Spotify address, so it gets its own ("freetune:...").
const toTrack = (b, [name, artists, durationMs], i) => ({
  uri: `freetune:${b.key}:${String(i + 1).padStart(2, '0')}`,
  id: `${b.key}-${i + 1}`,
  name,
  artists,
  album: { name: b.name, id: '', image: b.cover },
  image: b.cover,
  imageLarge: b.cover,
  durationMs,
  playable: true,
});

// Adds any built-in album this device hasn't had yet. settings: JsonStore.
function addBuiltIns(localPlaylists, settings, log = () => {}) {
  const done = settings.get('builtins', []) || [];
  const added = [];
  // Songs added before built-in albums had covers get theirs now.
  try {
    const lists = localPlaylists.store.get('lists', []) || [];
    let changed = false;
    for (const p of lists) for (const t of p.tracks || []) {
      const b = BUILTINS.find((x) => String(t.uri || '').startsWith(`freetune:${x.key}:`));
      if (b && b.cover && t.image !== b.cover) { t.image = t.imageLarge = b.cover; t.album = { ...(t.album || {}), image: b.cover }; changed = true; }
    }
    if (changed) localPlaylists._save(lists);
  } catch (e) {
    log('builtins: covers', e.message);
  }
  for (const b of BUILTINS) {
    if (done.includes(b.key)) continue;
    try {
      const p = localPlaylists.create(b.name, b.description);
      localPlaylists.addTracks(p.id, b.tracks.map((t, i) => toTrack(b, t, i)));
      done.push(b.key);
      added.push(b.name);
    } catch (e) {
      log('builtins: couldn’t add', b.name, e.message);
    }
  }
  if (added.length) {
    settings.set('builtins', done);
    if (settings.saveNow) settings.saveNow();
    log('builtins: added', added.join(', '));
  }
  return added;
}

const isBuiltinUri = (uri) => /^freetune:/.test(String(uri || ''));

module.exports = { BUILTINS, addBuiltIns, isBuiltinUri };
