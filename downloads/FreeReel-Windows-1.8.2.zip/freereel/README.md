# FreeReel

Private YouTube for Windows 10 and 11. No ads, no Google account, no trackers, no
autoplay rabbit holes and no Shorts. Download videos to an offline library and watch
them with no internet at all.

## Install

1. Extract this zip to a folder you'll keep (for example `Documents\FreeReel`).
2. Double-click **Install FreeReel.bat** and wait 2–5 minutes.
3. If Windows says "Windows protected your PC", click **More info**, then **Run anyway**
   (the app isn't code-signed).
4. Open FreeReel. The first launch downloads its playback engine (yt-dlp, about 15 MB).

## Make it yours

**Bring your subscriptions (once):**

1. Go to takeout.google.com and click **Deselect all**.
2. Tick **YouTube and YouTube Music**, click **All YouTube data included**, and keep only
   **subscriptions**.
3. Export, download and unzip it.
4. In FreeReel, choose **subscriptions.csv** on the Home page or in Settings.

After that, YouTube never learns who you follow: FreeReel checks each channel's public
feed for new videos.

**For you** learns from what you watch. It looks at videos related to the ones you
actually watched (more than a minute), skips anything you've seen, and keeps at most two
picks per channel. All of it is worked out and stored on your PC.

## Watching

- Picture and sound arrive as separate HD streams and are kept in sync, so you get up
  to 4K. Pick the quality in Settings or on the player.
- While a video plays, the rest of the screen dims. Move the mouse to bring it back.
- Videos pick up where you left off.
- Nothing plays by itself when a video ends unless you turn on Autoplay in Settings.
- Keys: Space or K play/pause, J/L back/forward 10 s, arrows 5 s and volume, F full
  screen, M mute, 0–9 jump to 0–90%, `<` `>` speed. Your keyboard's media keys work too.
- Paste a YouTube link into the search box to open that video.

## Downloads

Click **Download** under any video. Downloads run two at a time, resume after a restart,
and are split into small pieces so YouTube doesn't slow them down. Downloaded videos
play from your PC with no buffering and nothing sent to YouTube. They're stored in
`%APPDATA%\FreeReel\Library`.

## Privacy, exactly

- The FreeReel window can only load its own files and talk to FreeReel's engine on your
  PC. YouTube's website code, ad scripts and trackers never run.
- FreeReel's engine fetches videos, search results and thumbnails without any Google
  account, cookies or saved identifiers.
- Subscriptions, history, Watch later, downloads and settings stay in
  `%APPDATA%\FreeReel`. Pause or clear history any time in Settings.
- YouTube still sees your internet address when it sends a video. Use a VPN if you
  want to hide that.

## Limits

- Age-restricted and members-only videos need a Google sign-in, so they won't play.
- Live streams aren't supported yet.
- Comments aren't shown.
- This uses YouTube without its official API, like FreeTube and NewPipe. It isn't
  allowed by YouTube's terms, and it can break when YouTube changes things. If videos
  stop playing, go to **Settings → Update playback engine**.

## Updating

Save the update file you're given (for example `FreeReel-1.2.0.update`) into your
**Downloads** folder. FreeReel notices it within a few seconds and shows
**Restart and update**. Click it: FreeReel closes, swaps in the new version and reopens.
Your settings, history and downloads are kept. You can also use
**Settings → Updates → Install update file…** for a file saved somewhere else.

Updates are saved next to the installed version, so nothing in use is replaced, and
the app restarts into the newest one. If a new version ever fails to start three times in
a row, the app goes back to the previous one by itself.

Update files are signed. FreeReel only installs files signed with this project's key, made
for FreeReel, and newer than what you have, so a random file can't replace it.

To make an update yourself after changing the code: `node scripts/make-update.js "What changed"`.
It needs `signing/update-key.pem`. Keep that file private: anyone who has it can make
updates your apps will accept.

## Credits and license

Video extraction by [yt-dlp](https://github.com/yt-dlp/yt-dlp). FreeReel is free software
under the GNU GPL v3 or later (see `LICENSE`). Not affiliated with YouTube or Google.
