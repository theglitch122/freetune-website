﻿# FreeReel one-click installer for Windows 10 / 11.
# 1. Gets a private copy of Node.js (only if you don't already have Node 20+). It is
#    downloaded from nodejs.org, checked against nodejs.org's published checksum, and
#    kept inside this folder; nothing is installed system-wide.
# 2. Downloads FreeReel's building blocks (Electron) with npm.
# 3. Builds the FreeReel installer and opens it.
# If building the installer fails, it falls back to a desktop shortcut that runs
# FreeReel straight from this folder.

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'   # makes Invoke-WebRequest much faster
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$Tools = Join-Path $Root '.tools'

function Step($msg) { Write-Host ""; Write-Host "==> $msg" -ForegroundColor Cyan }
function Fail($msg) {
  Write-Host ""
  Write-Host "Setup stopped: $msg" -ForegroundColor Red
  Write-Host "Nothing was changed outside this folder. Fix the problem above and run 'Install FreeReel.bat' again."
  Read-Host "Press Enter to close"
  exit 1
}

Write-Host "FreeReel setup" -ForegroundColor White
Write-Host "This takes 2-5 minutes and downloads about 250 MB the first time."

if (-not [Environment]::Is64BitOperatingSystem) { Fail "FreeReel needs 64-bit Windows." }

# ── 1. Node.js ─────────────────────────────────────────────────────────────────
Step "Checking for Node.js"
$node = $null
$sysNode = Get-Command node -ErrorAction SilentlyContinue
if ($sysNode) {
  $v = (& node --version) -replace '^v', ''
  if ([int]($v.Split('.')[0]) -ge 20) { $node = $sysNode.Source; Write-Host "Using your installed Node.js $v" }
}
$portableNode = Get-ChildItem -Path $Tools -Filter 'node.exe' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $node -and $portableNode) { $node = $portableNode.FullName; Write-Host "Using FreeReel's private Node.js" }
if (-not $node) {
  Write-Host "Downloading a private copy of Node.js 22 from nodejs.org"
  try {
    $base = 'https://nodejs.org/dist/latest-v22.x/'
    $sums = (Invoke-WebRequest -UseBasicParsing "$($base)SHASUMS256.txt").Content
    $line = ($sums -split "`n") | Where-Object { $_ -match 'node-v22\.\d+\.\d+-win-x64\.zip' } | Select-Object -First 1
    if (-not $line) { throw "couldn't find the Windows download on nodejs.org" }
    $parts = $line.Trim() -split '\s+'
    $expected = $parts[0].ToLower(); $zipName = $parts[1]
    New-Item -ItemType Directory -Force -Path $Tools | Out-Null
    $zip = Join-Path $Tools $zipName
    Invoke-WebRequest -UseBasicParsing "$base$zipName" -OutFile $zip
    $actual = (Get-FileHash $zip -Algorithm SHA256).Hash.ToLower()
    if ($actual -ne $expected) { Remove-Item $zip -Force; throw "the Node.js download was corrupted (checksum mismatch)" }
    Expand-Archive -Path $zip -DestinationPath $Tools -Force
    Remove-Item $zip -Force
    $node = (Get-ChildItem -Path $Tools -Filter 'node.exe' -Recurse | Select-Object -First 1).FullName
  } catch { Fail "Couldn't get Node.js: $($_.Exception.Message)" }
}
$nodeDir = Split-Path -Parent $node
$env:Path = "$nodeDir;$env:Path"
$npm = Join-Path $nodeDir 'npm.cmd'
if (-not (Test-Path $npm)) { $npm = 'npm.cmd' }

# ── 2. Dependencies ────────────────────────────────────────────────────────────
Step "Downloading Electron and the installer builder (the largest step)"
& $npm install --no-audit --no-fund --loglevel=error
if ($LASTEXITCODE -ne 0) { Fail "npm install failed. Check your internet connection." }

# ── 3. Build the installer ─────────────────────────────────────────────────────
Step "Building the FreeReel installer"
Remove-Item -Recurse -Force (Join-Path $Root 'dist') -ErrorAction SilentlyContinue
& $npm run build:win
if ($LASTEXITCODE -ne 0) {
  Write-Host "First build attempt failed; retrying without editing the app's file details" -ForegroundColor Yellow
  & $npm run build:win -- -c.win.signAndEditExecutable=false
}
$setup = Get-ChildItem -Path (Join-Path $Root 'dist') -Filter 'FreeReel-Setup-*.exe' -ErrorAction SilentlyContinue | Select-Object -First 1

if ($setup) {
  Step "Done. Opening the installer"
  Write-Host "Installer saved at: $($setup.FullName)"
  Write-Host "Windows may show 'Windows protected your PC' because the app isn't code-signed."
  Write-Host "Click 'More info', then 'Run anyway'."
  Start-Process $setup.FullName
  Start-Sleep -Seconds 2
  exit 0
}

# ── Fallback: run from this folder via a desktop shortcut ──────────────────────
Step "Couldn't build an installer, so creating a desktop shortcut instead"
$electron = Join-Path $Root 'node_modules\electron\dist\electron.exe'
if (-not (Test-Path $electron)) { Fail "Electron didn't download correctly. Run setup again." }
$shell = New-Object -ComObject WScript.Shell
$lnk = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'FreeReel.lnk'))
$lnk.TargetPath = $electron
$lnk.Arguments = "`"$Root`""
$lnk.WorkingDirectory = $Root
$lnk.IconLocation = (Join-Path $Root 'build\icon.ico')
$lnk.Description = 'FreeReel'
$lnk.Save()
Write-Host "A FreeReel shortcut is on your desktop. Keep this folder where it is; the shortcut runs FreeReel from here."
Start-Process $electron -ArgumentList "`"$Root`"" -WorkingDirectory $Root
Read-Host "Press Enter to close"
