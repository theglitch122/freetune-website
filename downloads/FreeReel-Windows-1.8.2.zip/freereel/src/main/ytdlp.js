// yt-dlp: the open-source tool that turns a YouTube video into playable streams and
// downloads. FreeReel fetches it once from its official GitHub releases, keeps it
// updated (YouTube changes often), and runs it with FreeReel's own built-in JavaScript
// engine, so nothing else needs installing.

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const { Readable, Transform } = require('stream');
const { pipeline } = require('stream/promises');

// Nightly builds: YouTube breaks things often, and fixes land there days or weeks before a stable release.
const RELEASE = 'https://github.com/yt-dlp/yt-dlp-nightly-builds/releases/latest/download/';
const CHANNEL = 'nightly';
const ASSET = { win32: 'yt-dlp.exe', darwin: 'yt-dlp_macos', linux: 'yt-dlp_linux' }[process.platform] || 'yt-dlp';
const UPDATE_EVERY_MS = 2 * 24 * 3600 * 1000;

// ── format selection ───────────────────────────────────────────────────────────
// Separate video-only and audio-only streams give real HD; FreeReel plays them in sync.
const CODEC_RANK = (v) => (/^avc1/.test(v) ? 3 : /^vp0?9/.test(v) ? 2 : /^av01/.test(v) ? 1 : 0);

// opts.saver: for downloads — prefer the most space-efficient format at the chosen height
// (AV1 when this PC can play it smoothly, otherwise VP9, then H.264) and 30 fps over 60.
function pickFormats(info, maxHeight = 1080, opts = {}) {
  const fmts = (info.formats || []).filter((f) => f.url && !f.has_drm && /^https?$/.test(f.protocol || 'https') && !/storyboard/i.test(f.format_note || ''));
  const videos = fmts
    .filter((f) => f.vcodec && f.vcodec !== 'none' && (!f.acodec || f.acodec === 'none') && f.height)
    .filter((f) => CODEC_RANK(f.vcodec) > 0);
  const audios = fmts.filter((f) => f.acodec && f.acodec !== 'none' && (!f.vcodec || f.vcodec === 'none'));
  const muxed = fmts.filter((f) => f.acodec && f.acodec !== 'none' && f.vcodec && f.vcodec !== 'none' && f.height);

  // Best stream for each available height. For watching: H.264 (smooth hardware
  // decoding) at the highest frame rate. For smaller downloads: the most efficient codec.
  const rank = opts.saver
    ? (v) => (/^av01/.test(v) ? (opts.av1 ? 3 : 0.5) : /^vp0?9/.test(v) ? 2 : /^avc1/.test(v) ? 1 : 0)
    : CODEC_RANK;
  const better = (f, cur) => {
    if (!cur) return true;
    const r = rank(f.vcodec) - rank(cur.vcodec);
    if (r) return r > 0;
    const fa = f.fps || 30;
    const fc = cur.fps || 30;
    if (fa !== fc) return opts.saver ? fa < fc : fa > fc;
    return opts.saver ? (f.tbr || 1e9) < (cur.tbr || 1e9) : (f.tbr || 0) > (cur.tbr || 0);
  };
  const byHeight = new Map();
  for (const f of videos) if (better(f, byHeight.get(f.height))) byHeight.set(f.height, f);
  const qualities = [...byHeight.values()].sort((a, b) => b.height - a.height);
  // Many videos now carry AI-dubbed audio in other languages. Always prefer the
  // creator's original track, then YouTube's default one, then quality.
  const trackRank = (f) => {
    const note = `${f.format_note || ''} ${f.format || ''}`;
    if (/original/i.test(note) || (f.language_preference || 0) >= 10) return 3;
    if (/default/i.test(note)) return 2;
    if (/dubbed|auto-?dub|\bdub\b/i.test(note) || (f.language_preference != null && f.language_preference < 0)) return 0;
    return 1;
  };
  const byQuality = (a, b) => (/mp4a/.test(b.acodec) ? 1 : 0) - (/mp4a/.test(a.acodec) ? 1 : 0) || (b.abr || 0) - (a.abr || 0);
  // One entry per audio language, best quality of each, original first.
  const tracksMap = new Map();
  for (const f of audios) {
    const key = langKey(f);
    const cur = tracksMap.get(key);
    if (!cur || trackRank(f) > trackRank(cur) || (trackRank(f) === trackRank(cur) && byQuality(f, cur) < 0)) tracksMap.set(key, f);
  }
  const audioTracks = [...tracksMap.entries()]
    .map(([lang, f]) => ({ lang, label: langLabel(f, lang), original: trackRank(f) === 3, format: f }))
    .sort((a, b) => Number(b.original) - Number(a.original) || a.label.localeCompare(b.label));
  // Requested language ("en", "es"...) if the video has it; otherwise the original.
  const want = String(opts.lang || 'original').toLowerCase();
  let chosen = null;
  if (want !== 'original') chosen = audioTracks.find((t) => t.lang === want) || audioTracks.find((t) => t.lang.split('-')[0] === want.split('-')[0]);
  const audio = (chosen && chosen.format) || audios.sort((a, b) => trackRank(b) - trackRank(a) || byQuality(a, b))[0] || null;
  const fallback = muxed.sort((a, b) => b.height - a.height)[0] || null;
  const video = qualities.find((q) => q.height <= maxHeight) || qualities[qualities.length - 1] || null;
  return {
    video, audio, fallback, qualities,
    audioTracks: audioTracks.length > 1 ? audioTracks.map(({ lang, label, original }) => ({ lang, label, original })) : [],
    audioLang: audio ? langKey(audio) : null,
  };
}

// "en-US" -> "en-us"; formats without a language tag share one entry.
function langKey(f) {
  if (f.language) return String(f.language).toLowerCase();
  const m = /^([A-Z][a-z]+(?: \([^)]+\))?)/.exec(f.format_note || '');
  return m ? m[1].toLowerCase().replace(/[^a-z]+/g, '-') : 'default';
}
function langLabel(f, key) {
  const note = String(f.format_note || '');
  const named = /^([^,]+?)(?:\s+original)?(?:\s*\(default\))?\s*(?:,|$)/i.exec(note);
  if (named && /[A-Za-z]/.test(named[1]) && !/^(low|medium|high|ultralow|tiny)$/i.test(named[1].trim())) return named[1].trim();
  try {
    return new Intl.DisplayNames(['en'], { type: 'language' }).of(key) || key;
  } catch {
    return key;
  }
}

// YouTube's "Sign in to confirm you're not a bot" wall (the apostrophe can arrive garbled on Windows).
const isBotCheck = (s) => /confirm you.{0,3}re not a bot|not a bot/i.test(String(s));
const BOT_MESSAGE = 'YouTube is asking FreeReel to prove it isn’t a bot. YouTube has flagged your internet connection for anyone who isn’t signed in (not just FreeReel). To fix it: use a cookies file from a spare Google account (Settings → YouTube bot checks), switch networks (like a phone hotspot), or wait a few hours.';

// Errors that are about the video itself: no other method will help, so stop right away.
const isFinalError = (s) => /private video|members only|members-only|join this channel|removed|terminated|isn.t available|unavailable|age-restricted|confirm your age|copyright|not available in your country|live event|premieres in|invalid|not a valid/i.test(String(s));
const BROKEN_MESSAGE = 'YouTube changed something and none of FreeReel’s ways in work right now. FreeReel is updating its playback engine. Try again in a few minutes.';

// Ways of asking YouTube for a video, tried in order when one hits the bot check.
// The one that worked is remembered for a few hours.
const STRATEGIES = [
  { name: 'default', args: [], family: 0 },
  { name: 'safari', args: ['--extractor-args', 'youtube:player_client=web_safari,web_embedded,-tv_downgraded'], family: 0 },
  { name: 'embedded', args: ['--extractor-args', 'youtube:player_client=web_embedded'], family: 0 },
  { name: 'vr', args: ['--extractor-args', 'youtube:player_client=android_vr'], family: 0 },
  // Last resort over IPv4. Its streams are then fetched over IPv4 too (see httpstream.js).
  { name: 'vr4', args: ['-4', '--extractor-args', 'youtube:player_client=android_vr'], family: 4 },
];

function cleanError(s) {
  const lines = String(s).split('\n').map((l) => l.trim()).filter((l) => /^ERROR/.test(l));
  let msg = (lines[0] || String(s).trim().split('\n').pop() || '').replace(/^ERROR:\s*(\[[^\]]+\]\s*[\w-]+:\s*)?/, '');
  if (/Sign in to confirm your age/i.test(msg)) {
    msg = 'This video is age-restricted, which needs a Google sign-in. FreeReel doesn’t sign in to Google.';
  } else if (isBotCheck(msg)) {
    msg = BOT_MESSAGE;
  } else if (/Private video/i.test(msg)) msg = 'This video is private.';
  else if (/members-only|join this channel/i.test(msg)) msg = 'This video is for channel members only.';
  else if (/Video unavailable|This video is unavailable/i.test(msg)) msg = 'This video isn’t available.';
  return msg.slice(0, 300);
}

class YtDlp {
  constructor({ binDir, store, log = console.log, onStatus = () => {} }) {
    this.binDir = binDir;
    this.store = store;
    this.log = log;
    this.onStatus = onStatus;
    this.exe = path.join(binDir, process.platform === 'win32' ? 'yt-dlp.exe' : 'yt-dlp');
    this._ensuring = null;
    this.infoCache = new Map(); // videoId -> { info, at, expires }
    this.inflight = new Map();
  }

  installed() {
    try {
      return fs.statSync(this.exe).size > 1_000_000;
    } catch {
      return false;
    }
  }

  async ensure() {
    if (this.installed()) {
      // Move an older stable engine over to the nightly channel once, before using it.
      if (this.store.get('ytdlpChannel', null) !== CHANNEL) {
        if (!this._switching) {
          this._switching = this._maybeUpdate(true).then((out) => {
            if (out && /nightly|up to date|Updated yt-dlp/i.test(out)) this.store.set('ytdlpChannel', CHANNEL);
          }).finally(() => (this._switching = null));
        }
        await this._switching;
        return this.exe;
      }
      this._maybeUpdate();
      return this.exe;
    }
    if (!this._ensuring) this._ensuring = this._download().finally(() => (this._ensuring = null));
    return this._ensuring;
  }

  async _download() {
    fs.mkdirSync(this.binDir, { recursive: true });
    this.log('ytdlp: downloading engine');
    this.onStatus({ state: 'downloading', progress: 0 });
    let res;
    try {
      res = await fetch(RELEASE + ASSET, { redirect: 'follow' });
    } catch (e) {
      this.onStatus({ state: 'error', message: 'No internet connection' });
      throw new Error('Couldn’t download the playback engine. Check your internet connection.');
    }
    if (!res.ok || !res.body) {
      this.onStatus({ state: 'error', message: `Download failed (${res.status})` });
      throw new Error(`Couldn’t download the playback engine (HTTP ${res.status})`);
    }
    const total = Number(res.headers.get('content-length')) || 0;
    let got = 0;
    const tmp = this.exe + '.part';
    const counter = new Transform({
      transform: (chunk, _e, cb) => {
        got += chunk.length;
        if (total) this.onStatus({ state: 'downloading', progress: got / total });
        cb(null, chunk);
      },
    });
    await pipeline(Readable.fromWeb(res.body), counter, fs.createWriteStream(tmp));
    fs.renameSync(tmp, this.exe);
    if (process.platform !== 'win32') fs.chmodSync(this.exe, 0o755);
    this.store.set('ytdlpUpdatedAt', Date.now());
    this.store.set('ytdlpChannel', CHANNEL);
    this.onStatus({ state: 'ready' });
    return this.exe;
  }

  _maybeUpdate(force = false) {
    if (!force && Date.now() - this.store.get('ytdlpUpdatedAt', 0) < UPDATE_EVERY_MS) return Promise.resolve(null);
    this.store.set('ytdlpUpdatedAt', Date.now());
    return new Promise((resolve) => {
      const p = spawn(this.exe, ['--update-to', CHANNEL], { windowsHide: true, env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' } });
      let out = '';
      p.stdout.on('data', (d) => (out += d));
      p.stderr.on('data', (d) => (out += d));
      p.on('close', () => {
        this.log('ytdlp: update check:', out.trim().split('\n').pop());
        resolve(out.trim());
      });
      p.on('error', () => resolve(null));
    });
  }

  update() {
    return this._maybeUpdate(true);
  }

  _env() {
    // UTF-8 output so error messages (and titles) don't arrive garbled on Windows.
    return { ...process.env, ELECTRON_RUN_AS_NODE: '1', PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' };
  }

  // The strategy that last got past YouTube's checks (reset to the default after 6 hours).
  _strategy() {
    const m = this.store.get('ytStrategy', null);
    if (!m || Date.now() - m.at > 6 * 3600e3) return 0;
    return Math.max(0, STRATEGIES.findIndex((x) => x.name === m.name));
  }

  cookiesFile() {
    const f = this.store.get('cookiesFile', null);
    return f && fs.existsSync(f) ? f : null;
  }

  _baseArgs(strategy = this._strategy()) {
    const args = ['--no-warnings', '--no-playlist', '--js-runtimes', `node:${process.execPath}`, ...STRATEGIES[strategy].args];
    const cookies = this.cookiesFile();
    if (cookies) args.push('--cookies', cookies);
    return args;
  }

  // Blocked recently? Background work (like preloading) waits until this has passed.
  blocked() {
    return Date.now() < (this.botUntil || 0);
  }

  _onBotCheck() {
    this.botUntil = Date.now() + 15 * 60e3;
    this.log('ytdlp: YouTube bot check on every method - backing off for 15 minutes');
    // New engine versions often fix this, so check for one (at most every 6 hours).
    if (Date.now() - (this.store.get('ytdlpUpdatedAt', 0) || 0) > 6 * 3600e3) this._maybeUpdate(true);
  }

  _run(args, timeoutMs = 60000) {
    return new Promise((resolve, reject) => {
      const p = spawn(this.exe, args, { windowsHide: true, env: this._env() });
      let out = '';
      let err = '';
      const t = setTimeout(() => {
        p.kill();
        reject(new Error('YouTube took too long to respond'));
      }, timeoutMs);
      p.stdout.on('data', (d) => (out += d));
      p.stderr.on('data', (d) => (err += d));
      p.on('error', (e) => {
        clearTimeout(t);
        reject(e);
      });
      p.on('close', (code) => {
        clearTimeout(t);
        if (code === 0) resolve(out);
        else reject(new Error(cleanError(err) || `yt-dlp exited with code ${code}`));
      });
    });
  }

  // Full video details + every stream, cached until the stream links are about to expire.
  async info(videoId, { fresh = false } = {}) {
    const hit = this.infoCache.get(videoId);
    if (!fresh && hit && hit.expires - Date.now() > 15 * 60 * 1000) return hit.info;
    if (this.inflight.has(videoId)) return this.inflight.get(videoId);
    const job = (async () => {
      await this.ensure();
      const { raw, family, method } = await this._extract(videoId);
      const info = JSON.parse(raw);
      // Streams must be fetched over the same kind of address (IPv4/IPv6) as this lookup.
      Object.defineProperty(info, '_family', { value: family, enumerable: false });
      Object.defineProperty(info, '_method', { value: method, enumerable: false });
      let expires = Date.now() + 5 * 3600 * 1000;
      const any = (info.formats || []).find((f) => f.url && /expire=\d+/.test(f.url));
      if (any) expires = Number(/expire=(\d+)/.exec(any.url)[1]) * 1000;
      this.infoCache.set(videoId, { info, expires });
      if (this.infoCache.size > 60) this.infoCache.delete(this.infoCache.keys().next().value);
      return info;
    })().finally(() => this.inflight.delete(videoId));
    this.inflight.set(videoId, job);
    return job;
  }

  async _extract(videoId) {
    const url = `https://www.youtube.com/watch?v=${videoId}`;
    const first = this._strategy();
    // While YouTube is blocking this connection, one attempt per song: going through
    // every method again only adds to the traffic that keeps the block going.
    const order = this.blocked() ? [first] : [first, ...STRATEGIES.map((_, i) => i).filter((i) => i !== first)];
    let lastErr = null;
    for (const i of order) {
      const args = [...this._baseArgs(i), '-J', url];
      try {
        let raw;
        try {
          raw = await this._run(args);
        } catch (e) {
          if (!/js-runtimes|no such option/i.test(e.message)) throw e;
          raw = await this._run(args.filter((a, j) => a !== '--js-runtimes' && args[j - 1] !== '--js-runtimes'));
        }
        if (i !== first) {
          this.log('ytdlp: now using the', STRATEGIES[i].name, 'method (the previous one stopped working)');
          this.store.set('ytStrategy', { name: STRATEGIES[i].name, at: Date.now() });
        }
        this.botUntil = 0;
        return { raw, family: STRATEGIES[i].family || 0, method: STRATEGIES[i].name };
      } catch (e) {
        if (!lastErr || lastErr.message !== BOT_MESSAGE) lastErr = e;
        this.log('ytdlp:', STRATEGIES[i].name, 'method failed:', e.message.slice(0, 120));
        if (e.message !== BOT_MESSAGE && isFinalError(e.message)) throw e; // a real problem (private video etc.), not the bot check
      }
    }
    this._onBotCheck();
    if (lastErr && lastErr.message !== BOT_MESSAGE) {
      this.log('ytdlp: every method failed, last error:', lastErr.message);
      throw Object.assign(new Error(BROKEN_MESSAGE), { botCheck: true });
    }
    throw Object.assign(lastErr || new Error(BOT_MESSAGE), { botCheck: true });
  }

  // YouTube keeps refusing the streams this method gives (even fresh ones): switch to the next method.
  nextStrategy() {
    if (this.blocked()) return; // nothing works right now; don't churn through methods
    if (Date.now() - (this._rotatedAt || 0) < 30000) return; // the picture and sound both asked: switch once
    this._rotatedAt = Date.now();
    const i = (this._strategy() + 1) % STRATEGIES.length;
    this.store.set('ytStrategy', { name: STRATEGIES[i].name, at: Date.now() });
    this.log('ytdlp: streams keep being refused - switching to the', STRATEGIES[i].name, 'method');
    (this.cache || this.infoCache).clear();
  }

  invalidate(videoId) {
    this.infoCache.delete(videoId);
  }

  // Download one format to `outFile`. Resumable: an interrupted download continues.
  download({ videoId, formatId, outFile, onProgress, signal }) {
    return new Promise((resolve, reject) => {
      const args = [
        ...this._baseArgs(),
        '-f', String(formatId),
        '-o', outFile,
        '--newline',
        '--no-mtime',
        '--continue',
        '--retries', '10',
        '--fragment-retries', '10',
        '--http-chunk-size', '10M', // avoids YouTube's slow-lane throttling on long files
        '--progress-template', 'download:FRP %(progress.downloaded_bytes)s %(progress.total_bytes)s %(progress.total_bytes_estimate)s %(progress.speed)s',
        `https://www.youtube.com/watch?v=${videoId}`,
      ];
      const p = spawn(this.exe, args, { windowsHide: true, env: this._env() });
      let err = '';
      let buf = '';
      p.stdout.on('data', (d) => {
        buf += d;
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim();
          buf = buf.slice(i + 1);
          const m = /^FRP (\S+) (\S+) (\S+) (\S+)/.exec(line);
          if (m && onProgress) {
            const num = (x) => (x === 'NA' || x === 'None' ? 0 : Number(x) || 0);
            onProgress({ done: num(m[1]), total: num(m[2]) || num(m[3]), speed: num(m[4]) });
          }
        }
      });
      p.stderr.on('data', (d) => (err += d));
      const abort = () => p.kill();
      if (signal) signal.addEventListener('abort', abort, { once: true });
      p.on('error', reject);
      p.on('close', (code) => {
        if (signal) signal.removeEventListener('abort', abort);
        if (signal && signal.aborted) return reject(Object.assign(new Error('Cancelled'), { cancelled: true }));
        if (code === 0) resolve(outFile);
        else reject(new Error(cleanError(err) || `Download failed (code ${code})`));
      });
    });
  }
}

module.exports = { YtDlp, pickFormats, cleanError, isBotCheck, BOT_MESSAGE, STRATEGIES };
