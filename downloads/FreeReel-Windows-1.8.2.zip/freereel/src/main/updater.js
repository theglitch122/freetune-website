// Updater shared by FreeTune and FreeReel.
//
// How it works: save an update file (e.g. "FreeTune-1.2.0.update") into your Downloads
// folder. The app notices it, checks it, and offers "Restart to update". Installing saves
// the new version beside the old one and restarts the app — a few seconds, no rebuild.
//
// Safety: every update file is signed. The app only accepts files whose signature
// matches the public key below, that are meant for this app, and that are newer than
// what's installed. Anything else is ignored. The installed version stays in place, and
// boot.js falls back to it if an update ever fails to start.

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEA1p5/lUnzCvsegXzjvGL5/QEPVIq3oJF0qiBXphAr87U=
-----END PUBLIC KEY-----`;
const MAGIC = Buffer.from('FRUPD1\n');
const MAX_HEADER = 64 * 1024;

function cmpVersion(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

function signedText(h) {
  return `${h.app}\n${h.version}\n${h.size}\n${h.sha256}`;
}

// Read and check an update file's header. Returns null for anything that isn't valid.
function readHeader(file) {
  let fd;
  try {
    fd = fs.openSync(file, 'r');
    const head = Buffer.alloc(MAGIC.length + 4);
    if (fs.readSync(fd, head, 0, head.length, 0) !== head.length) return null;
    if (!head.subarray(0, MAGIC.length).equals(MAGIC)) return null;
    const len = head.readUInt32LE(MAGIC.length);
    if (!len || len > MAX_HEADER) return null;
    const buf = Buffer.alloc(len);
    fs.readSync(fd, buf, 0, len, head.length);
    const h = JSON.parse(buf.toString('utf8'));
    const ok = crypto.verify(null, Buffer.from(signedText(h)), PUBLIC_KEY, Buffer.from(h.signature || '', 'base64'));
    if (!ok) return null;
    const total = fs.fstatSync(fd).size;
    if (total !== head.length + len + h.size) return null;
    return { ...h, file, offset: head.length + len };
  } catch {
    return null;
  } finally {
    if (fd != null) fs.closeSync(fd);
  }
}

function hashPayload(u) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    fs.createReadStream(u.file, { start: u.offset, end: u.offset + u.size - 1 })
      .on('data', (d) => hash.update(d))
      .on('end', () => resolve(hash.digest('hex')))
      .on('error', reject);
  });
}

class Updater {
  constructor({ app, appId, appName, log = console.log, onAvailable = () => {} }) {
    this.app = app; // electron app
    this.appId = appId; // 'freetune' | 'freereel'
    this.appName = appName; // 'FreeTune' | 'FreeReel'
    this.version = global.__APP_VERSION__ || app.getVersion();
    this.log = log;
    this.onAvailable = onAvailable;
    this.enabled = app.isPackaged;
    this.found = null;
    this.dirs = [app.getPath('downloads'), app.getPath('desktop')].filter((d) => {
      try {
        return fs.statSync(d).isDirectory();
      } catch {
        return false;
      }
    });
  }

  // Look for the newest valid update file.
  async check() {
    const candidates = [];
    const pattern = new RegExp(`^${this.appName}[^\\\\/]*\\.update$`, 'i');
    for (const dir of this.dirs) {
      let names = [];
      try {
        names = fs.readdirSync(dir).filter((n) => pattern.test(n));
      } catch {
        continue;
      }
      for (const n of names) {
        const file = path.join(dir, n);
        const h = readHeader(file);
        if (!h || h.app !== this.appId) continue;
        if (cmpVersion(h.version, this.version) <= 0) {
          // Already installed: tidy it out of the Downloads folder.
          try {
            fs.unlinkSync(file);
          } catch {}
          continue;
        }
        candidates.push(h);
      }
    }
    // Newest first; a damaged copy is skipped in favour of the next good one.
    candidates.sort((a, b) => cmpVersion(b.version, a.version));
    let best = null;
    for (const c of candidates) {
      if ((await hashPayload(c).catch(() => null)) === c.sha256) {
        best = c;
        break;
      }
      this.log('updater: skipping damaged update file', c.file);
    }
    const changed = (best && best.file) !== (this.found && this.found.file);
    this.found = best;
    if (best && changed) {
      this.log('updater: found', this.appName, best.version);
      this.onAvailable(this.publicInfo());
    }
    return this.publicInfo();
  }

  // Check a file the user picked by hand (anywhere on the PC).
  async checkFile(file) {
    const h = readHeader(file);
    if (!h) throw new Error('That isn’t a valid update file.');
    if (h.app !== this.appId) throw new Error(`That update is for ${h.app === 'freetune' ? 'FreeTune' : 'FreeReel'}, not ${this.appName}.`);
    if (cmpVersion(h.version, this.version) <= 0) throw new Error(`${this.appName} ${this.version} is already installed, and that file is version ${h.version}.`);
    if ((await hashPayload(h)) !== h.sha256) throw new Error('That update file is damaged. Download it again.');
    this.found = h;
    return this.publicInfo();
  }

  publicInfo() {
    return this.found ? { version: this.found.version, notes: this.found.notes || '', current: this.version } : null;
  }

  watch() {
    if (!this.enabled) return;
    this.cleanup();
    this.check().catch(() => {});
    let t;
    for (const dir of this.dirs) {
      try {
        fs.watch(dir, () => {
          clearTimeout(t);
          t = setTimeout(() => this.check().catch(() => {}), 1500);
        });
      } catch {
        /* folder can't be watched; the timer below still catches updates */
      }
    }
    setInterval(() => this.check().catch(() => {}), 5 * 60 * 1000).unref();
  }

  // Save the new version next to the installed one (nothing in use is touched), then
  // restart. The startup loader (boot.js) runs the newest version it finds.
  async apply() {
    if (!this.enabled) throw new Error('Updates only work in the installed app.');
    const u = this.found;
    if (!u) throw new Error('No update is ready. Check that the .update file is still in Downloads.');
    if ((await hashPayload(u)) !== u.sha256) throw new Error('The update file changed or is damaged. Download it again.');
    const res = process.resourcesPath;
    const target = path.join(res, `app-${u.version}.asar`);
    const tmp = target + '.part';
    await new Promise((resolve, reject) => {
      fs.createReadStream(u.file, { start: u.offset, end: u.offset + u.size - 1 })
        .pipe(fs.createWriteStream(tmp))
        .on('finish', resolve)
        .on('error', reject);
    });
    const written = crypto.createHash('sha256').update(fs.readFileSync(tmp)).digest('hex');
    if (written !== u.sha256) {
      fs.rmSync(tmp, { force: true });
      throw new Error('The update didn’t save correctly. Try again.');
    }
    fs.rmSync(target, { force: true });
    fs.renameSync(tmp, target);
    try {
      fs.unlinkSync(u.file);
    } catch {}
    this.cleanup(u.version);
    this.log('updater: installed', u.version, '- restarting');
    this.found = null;
    this.app.relaunch();
    return true;
  }

  // Remove old saved versions, keeping the running one and the newest.
  cleanup(newest = this.version) {
    if (!this.enabled) return;
    try {
      const res = process.resourcesPath;
      for (const n of fs.readdirSync(res)) {
        const m = /^app-(\d+\.\d+\.\d+)\.asar(\.part)?$/.exec(n);
        if (!m) continue;
        if (!m[2] && (m[1] === this.version || m[1] === newest)) continue;
        try {
          fs.rmSync(path.join(res, n), { force: true });
        } catch {
          /* in use; try again next time */
        }
      }
    } catch {}
  }
}

module.exports = { Updater, readHeader, cmpVersion, signedText, MAGIC };
