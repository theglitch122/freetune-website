// YouTube data, fetched without any Google account, cookies or saved identifiers.
// Uses YouTube's own web API ("InnerTube") the way the website does, plus the public
// per-channel RSS feeds for subscriptions. Every request starts from a blank slate, so
// YouTube can't build a profile of you from FreeReel.

const API = 'https://www.youtube.com/youtubei/v1/';
const CLIENT = { clientName: 'WEB', clientVersion: '2.20250930.01.00', hl: 'en', gl: 'US' };
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36';
const TIMEOUT_MS = 15000;

async function req(url, opts = {}) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      ...opts,
      signal: ctrl.signal,
      redirect: opts.redirect || 'follow',
      headers: { 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9', ...(opts.headers || {}) },
    });
    return res;
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('YouTube took too long to respond');
    throw new Error('Can’t reach YouTube. Check your internet connection.');
  } finally {
    clearTimeout(t);
  }
}

async function innertube(endpoint, body) {
  const res = await req(`${API}${endpoint}?prettyPrint=false`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Origin: 'https://www.youtube.com',
      Referer: 'https://www.youtube.com/',
      'X-YouTube-Client-Name': '1',
      'X-YouTube-Client-Version': CLIENT.clientVersion,
    },
    body: JSON.stringify({ context: { client: CLIENT, user: { lockedSafetyMode: false } }, ...body }),
  });
  if (!res.ok) throw new Error(`YouTube returned an error (${res.status})`);
  return res.json();
}

// ── generic helpers ────────────────────────────────────────────────────────────
const text = (x) => {
  if (!x) return '';
  if (typeof x === 'string') return x;
  if (x.simpleText) return x.simpleText;
  if (x.content) return x.content;
  if (Array.isArray(x.runs)) return x.runs.map((r) => r.text).join('');
  return '';
};

function walk(node, visit, depth = 0) {
  if (!node || typeof node !== 'object' || depth > 40) return;
  if (Array.isArray(node)) {
    for (const n of node) walk(n, visit, depth + 1);
    return;
  }
  if (visit(node) === false) return; // stop descending
  for (const k in node) walk(node[k], visit, depth + 1);
}

function bestThumb(list, want = 480) {
  if (!Array.isArray(list) || !list.length) return null;
  const sorted = list.filter((t) => t && t.url).sort((a, b) => (a.width || 0) - (b.width || 0));
  const pick = sorted.find((t) => (t.width || 0) >= want) || sorted[sorted.length - 1];
  if (!pick) return null;
  return pick.url.startsWith('//') ? 'https:' + pick.url : pick.url;
}

const videoThumb = (id) => `https://i.ytimg.com/vi/${id}/mqdefault.jpg`;

function parseDuration(s) {
  const m = /^(?:(\d+):)?(\d{1,2}):(\d{2})$/.exec(String(s || '').trim());
  if (!m) return null;
  return Number(m[1] || 0) * 3600 + Number(m[2]) * 60 + Number(m[3]);
}

function parseCount(s) {
  const m = /([\d.,]+)\s*([KMB])?/i.exec(String(s || '').replace(/\s+views?.*/i, ''));
  if (!m) return null;
  let n = Number(m[1].replace(/,/g, ''));
  const mult = { k: 1e3, m: 1e6, b: 1e9 }[(m[2] || '').toLowerCase()] || 1;
  n *= mult;
  return Number.isFinite(n) ? Math.round(n) : null;
}

// ── video item parsing: handles every shape YouTube currently uses ─────────────
function fromVideoRenderer(v) {
  if (!v.videoId) return null;
  const owner = (v.ownerText || v.shortBylineText || v.longBylineText || {}).runs || [];
  const ch = owner[0] || {};
  const be = ch.navigationEndpoint && ch.navigationEndpoint.browseEndpoint;
  const lengthStr =
    text(v.lengthText) ||
    (((v.thumbnailOverlays || []).find((o) => o.thumbnailOverlayTimeStatusRenderer) || {}).thumbnailOverlayTimeStatusRenderer || {}).text;
  const overlayStyle = ((v.thumbnailOverlays || []).find((o) => o.thumbnailOverlayTimeStatusRenderer) || {}).thumbnailOverlayTimeStatusRenderer;
  const live = !!(overlayStyle && overlayStyle.style === 'LIVE') || (v.badges || []).some((b) => /live/i.test(JSON.stringify(b)));
  return {
    id: v.videoId,
    title: text(v.title) || text(v.headline),
    channel: ch.text || '',
    channelId: (be && be.browseId) || null,
    duration: parseDuration(text(lengthStr)),
    views: parseCount(text(v.viewCountText) || text(v.shortViewCountText)),
    published: text(v.publishedTimeText) || '',
    thumb: videoThumb(v.videoId),
    live,
  };
}

function fromLockup(l) {
  if (l.contentType && l.contentType !== 'LOCKUP_CONTENT_TYPE_VIDEO') return null;
  const id = l.contentId;
  if (!id || !/^[\w-]{11}$/.test(id)) return null;
  const meta = (l.metadata && l.metadata.lockupMetadataViewModel) || {};
  const title = text(meta.title);
  const rows = ((meta.metadata && meta.metadata.contentMetadataViewModel && meta.metadata.contentMetadataViewModel.metadataRows) || []).map((r) =>
    (r.metadataParts || []).map((p) => text(p.text))
  );
  let channel = '';
  let channelId = null;
  walk(meta, (n) => {
    if (n.browseEndpoint && /^UC/.test(n.browseEndpoint.browseId || '') && !channelId) channelId = n.browseEndpoint.browseId;
  });
  const flat = rows.flat();
  channel = (rows[0] && rows[0][0]) || '';
  const viewsPart = flat.find((p) => /views?|watching/i.test(p));
  const agoPart = flat.find((p) => /ago|streamed|premiere/i.test(p));
  let duration = null;
  let live = false;
  walk(l.contentImage, (n) => {
    if (n.thumbnailBadgeViewModel) {
      const t = text(n.thumbnailBadgeViewModel.text) || n.thumbnailBadgeViewModel.text;
      const d = parseDuration(t);
      if (d != null) duration = d;
      if (/live/i.test(String(t || '')) || n.thumbnailBadgeViewModel.badgeStyle === 'THUMBNAIL_OVERLAY_BADGE_STYLE_LIVE') live = true;
    }
  });
  return {
    id,
    title,
    channel,
    channelId,
    duration,
    views: parseCount(viewsPart),
    published: agoPart || '',
    thumb: videoThumb(id),
    live,
  };
}

function fromShort(s) {
  // shortsLockupViewModel / reelItemRenderer — kept only so callers can filter them out.
  const id =
    (s.onTap && s.onTap.innertubeCommand && s.onTap.innertubeCommand.reelWatchEndpoint && s.onTap.innertubeCommand.reelWatchEndpoint.videoId) ||
    s.videoId;
  return id ? { id, title: text(s.overlayMetadata && s.overlayMetadata.primaryText) || text(s.headline), short: true, thumb: videoThumb(id) } : null;
}

// Collect every video in any InnerTube response, in page order, without duplicates.
function collectVideos(json) {
  const out = [];
  const seen = new Set();
  walk(json, (n) => {
    let v = null;
    if (n.videoRenderer) v = fromVideoRenderer(n.videoRenderer);
    else if (n.compactVideoRenderer) v = fromVideoRenderer(n.compactVideoRenderer);
    else if (n.gridVideoRenderer) v = fromVideoRenderer(n.gridVideoRenderer);
    else if (n.playlistVideoRenderer) v = fromVideoRenderer(n.playlistVideoRenderer);
    else if (n.lockupViewModel) v = fromLockup(n.lockupViewModel);
    else if (n.shortsLockupViewModel) v = fromShort(n.shortsLockupViewModel);
    else if (n.reelItemRenderer) v = fromShort(n.reelItemRenderer);
    else return true;
    if (v && v.id && !seen.has(v.id)) {
      seen.add(v.id);
      out.push(v);
    }
    return false;
  });
  return out;
}

function collectChannels(json) {
  const out = [];
  walk(json, (n) => {
    const c = n.channelRenderer;
    if (!c) return true;
    out.push({
      id: c.channelId,
      name: text(c.title),
      avatar: bestThumb(c.thumbnail && c.thumbnail.thumbnails, 88),
      subscribers: text(c.videoCountText) || text(c.subscriberCountText) || '',
    });
    return false;
  });
  return out.filter((c) => c.id && c.name);
}

function continuationToken(json) {
  let token = null;
  walk(json, (n) => {
    if (token) return false;
    const c = n.continuationCommand || (n.continuationEndpoint && n.continuationEndpoint.continuationCommand);
    if (c && c.token) token = c.token;
    if (n.nextContinuationData && n.nextContinuationData.continuation) token = n.nextContinuationData.continuation;
    return true;
  });
  return token;
}

// ── public API ─────────────────────────────────────────────────────────────────
const SEARCH_VIDEOS_ONLY = 'EgIQAQ%3D%3D';

async function search(query, { continuation } = {}) {
  const [json, all] = continuation
    ? [await innertube('search', { continuation }), null]
    : await Promise.all([
        innertube('search', { query, params: decodeURIComponent(SEARCH_VIDEOS_ONLY) }),
        innertube('search', { query }).catch(() => null), // unfiltered, to find matching channels
      ]);
  return {
    videos: collectVideos(json).filter((v) => !v.short),
    channels: continuation || !all ? [] : collectChannels(all).slice(0, 3),
    continuation: continuationToken(json),
  };
}

// Related videos + basic details for the watch page.
async function next(videoId) {
  const json = await innertube('next', { videoId });
  let title = '';
  let channel = '';
  let channelId = null;
  let avatar = null;
  let subscribers = '';
  walk(json, (n) => {
    if (n.videoPrimaryInfoRenderer) title = text(n.videoPrimaryInfoRenderer.title);
    if (n.videoOwnerRenderer) {
      const o = n.videoOwnerRenderer;
      channel = text(o.title);
      const be = o.navigationEndpoint && o.navigationEndpoint.browseEndpoint;
      channelId = (be && be.browseId) || channelId;
      avatar = bestThumb(o.thumbnail && o.thumbnail.thumbnails, 88);
      subscribers = text(o.subscriberCountText);
      return false;
    }
    return true;
  });
  // Related videos live in the secondary column; skip the main video itself.
  let secondary = null;
  walk(json, (n) => {
    if (n.secondaryResults) {
      secondary = n.secondaryResults;
      return false;
    }
    return true;
  });
  const related = collectVideos(secondary || {}).filter((v) => v.id !== videoId && !v.short);
  return { title, channel, channelId, avatar, subscribers, related };
}

const CHANNEL_VIDEOS_TAB = 'EgZ2aWRlb3PyBgQKAjoA';

async function channel(channelId, { continuation } = {}) {
  if (continuation) {
    const json = await innertube('browse', { continuation });
    return { videos: collectVideos(json).filter((v) => !v.short), continuation: continuationToken(json) };
  }
  const json = await innertube('browse', { browseId: channelId, params: CHANNEL_VIDEOS_TAB });
  let meta = {};
  walk(json, (n) => {
    if (n.channelMetadataRenderer) {
      meta = n.channelMetadataRenderer;
      return false;
    }
    return true;
  });
  let banner = null;
  let subscribers = '';
  walk(json, (n) => {
    if (n.pageHeaderViewModel) {
      walk(n.pageHeaderViewModel, (m) => {
        if (m.imageBannerViewModel && !banner) banner = bestThumb(m.imageBannerViewModel.image && m.imageBannerViewModel.image.sources, 1200);
        if (m.metadataParts && !subscribers) {
          const p = m.metadataParts.map((x) => text(x.text)).find((t) => /subscriber/i.test(t));
          if (p) subscribers = p;
        }
      });
      return false;
    }
    return true;
  });
  const videos = collectVideos(json).filter((v) => !v.short).map((v) => ({ ...v, channel: v.channel || meta.title || '', channelId: channelId }));
  return {
    info: {
      id: meta.externalId || channelId,
      name: meta.title || '',
      description: meta.description || '',
      avatar: bestThumb(meta.avatar && meta.avatar.thumbnails, 176),
      banner,
      subscribers,
    },
    videos,
    continuation: continuationToken(json),
  };
}

// Turn a channel link, @handle or ID into a channel ID.
async function resolveChannel(input) {
  const s = String(input || '').trim();
  if (/^UC[\w-]{22}$/.test(s)) return s;
  let url = s;
  if (/^@[\w.-]+$/.test(s)) url = `https://www.youtube.com/${s}`;
  else if (!/^https?:\/\//.test(s)) url = `https://www.youtube.com/@${s.replace(/^@/, '')}`;
  const m = /\/channel\/(UC[\w-]{22})/.exec(url);
  if (m) return m[1];
  const json = await innertube('navigation/resolve_url', { url });
  const be = json && json.endpoint && json.endpoint.browseEndpoint;
  if (be && /^UC/.test(be.browseId || '')) return be.browseId;
  throw new Error('That channel couldn’t be found');
}

// Latest uploads of one channel from its public RSS feed (fast, no API quirks).
function decodeXml(s) {
  return String(s || '')
    .replace(/<!\[CDATA\[([\s\S]*?)]]>/g, '$1')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
}
function parseRss(xml, channelId) {
  const name = decodeXml((/<author>\s*<name>([\s\S]*?)<\/name>/.exec(xml) || [])[1] || '');
  const entries = [];
  for (const m of xml.matchAll(/<entry>([\s\S]*?)<\/entry>/g)) {
    const e = m[1];
    const get = (re) => decodeXml((re.exec(e) || [])[1] || '');
    const id = get(/<yt:videoId>([\w-]{11})<\/yt:videoId>/);
    if (!id) continue;
    const link = get(/<link[^>]*href="([^"]+)"/);
    entries.push({
      id,
      title: get(/<title>([\s\S]*?)<\/title>/),
      channel: name,
      channelId,
      publishedAt: Date.parse(get(/<published>([^<]+)<\/published>/)) || null,
      views: Number(get(/<media:statistics views="(\d+)"/)) || null,
      thumb: videoThumb(id),
      short: /\/shorts\//.test(link),
      duration: null,
    });
  }
  return { name, videos: entries };
}
async function channelFeed(channelId) {
  const res = await req(`https://www.youtube.com/feeds/videos.xml?channel_id=${encodeURIComponent(channelId)}`);
  if (res.status === 404) return { name: '', videos: [] };
  if (!res.ok) throw new Error(`Feed error ${res.status}`);
  return parseRss(await res.text(), channelId);
}

// YouTube serves /shorts/<id> directly for Shorts and redirects for normal videos.
async function isShort(id) {
  try {
    const res = await req(`https://www.youtube.com/shorts/${id}`, { method: 'HEAD', redirect: 'manual' });
    return res.status === 200;
  } catch {
    return false;
  }
}

// Google Takeout "subscriptions.csv": Channel Id,Channel Url,Channel Title
function parseTakeoutCsv(csv) {
  const rows = [];
  const lines = String(csv).replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim());
  const parseLine = (line) => {
    const out = [];
    let cur = '';
    let q = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (q) {
        if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; }
        else if (c === '"') q = false;
        else cur += c;
      } else if (c === '"') q = true;
      else if (c === ',') { out.push(cur); cur = ''; }
      else cur += c;
    }
    out.push(cur);
    return out;
  };
  for (const line of lines) {
    const cols = parseLine(line);
    const id = (cols.find((c) => /^UC[\w-]{22}$/.test(c.trim())) || '').trim();
    if (!id) continue; // header or junk
    const name = ([...cols].reverse().find((c) => c.trim() && c.trim() !== id && !/youtube\.com|^https?:/i.test(c.trim())) || '').trim();
    rows.push({ id, name });
  }
  return rows;
}

function agoToTime(s) {
  const m = /(\d+)\s*(second|minute|hour|day|week|month|year)/i.exec(String(s || ''));
  if (!m) return null;
  const sec = { second: 1, minute: 60, hour: 3600, day: 86400, week: 604800, month: 2592000, year: 31536000 }[m[2].toLowerCase()];
  return Date.now() - Number(m[1]) * sec * 1000;
}

module.exports = {
  search, next, channel, resolveChannel, channelFeed, isShort, parseTakeoutCsv, agoToTime,
  _: { collectVideos, collectChannels, continuationToken, parseRss, parseDuration, parseCount, fromLockup, text },
};
