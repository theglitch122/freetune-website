// Everything personal lives here, on your PC only: subscriptions, watch history,
// Watch later, and the "For you" picks built from them. Nothing is sent to Google:
// recommendations are worked out locally from the related videos of things you watched.

const yt = require('./yt');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function mapLimit(items, limit, fn) {
  const out = new Array(items.length);
  let i = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (i < items.length) {
      const idx = i++;
      try {
        out[idx] = await fn(items[idx], idx);
      } catch (e) {
        out[idx] = { error: e };
      }
    }
  });
  await Promise.all(workers);
  return out;
}

class Feed {
  constructor({ subs, history, later, cache, settings, log = console.log, isBlocked = () => false }) {
    this.isBlocked = isBlocked; // true while YouTube is pushing back: stay quiet
    this.subs = subs; // { [channelId]: { id, name, avatar, addedAt } }
    this.history = history; // { [videoId]: { ...video, position, watchedAt, count } }
    this.later = later; // { list: [video] }
    this.cache = cache; // { feeds: {}, related: {}, shorts: {} }
    this.settings = settings;
    this.log = log;
    if (!this.cache.get('feeds')) this.cache.set('feeds', {});
    if (!this.cache.get('related')) this.cache.set('related', {});
    if (!this.cache.get('shorts')) this.cache.set('shorts', {});
  }

  // ── subscriptions ──
  listSubs() {
    const feeds = this.cache.get('feeds') || {};
    return Object.values(this.subs.data)
      .map((s) => {
        const vids = (feeds[s.id] && feeds[s.id].videos) || [];
        const last = vids.reduce((m, v) => Math.max(m, v.publishedAt || 0), 0);
        return { ...s, lastUpload: last || null };
      })
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  isSubscribed(id) {
    return !!this.subs.get(id, null);
  }

  async subscribe(input, known = {}) {
    const id = /^UC[\w-]{22}$/.test(input) ? input : await yt.resolveChannel(input);
    let name = known.name;
    let avatar = known.avatar || null;
    if (!name || !avatar) {
      try {
        const c = await yt.channel(id);
        name = name || c.info.name;
        avatar = avatar || c.info.avatar;
      } catch {
        /* filled in later by fixNames() */
      }
    }
    const entry = { id, name: name || id, avatar, addedAt: Date.now() };
    this.subs.set(id, entry);
    return entry;
  }

  // Unsubscribe from several channels at once. Returns what was removed so it can be undone.
  unsubscribeMany(ids) {
    const removed = [];
    for (const id of ids) {
      const s = this.subs.get(id, null);
      if (!s) continue;
      removed.push(s);
      this.unsubscribe(id);
    }
    return removed;
  }

  restore(entries) {
    for (const s of entries || []) {
      if (!s || !/^UC[\w-]{22}$/.test(s.id)) continue;
      const { lastUpload, ...entry } = s;
      this.subs.set(s.id, entry);
    }
    return true;
  }

  unsubscribe(id) {
    this.subs.delete(id);
    const feeds = this.cache.get('feeds');
    delete feeds[id];
    this.cache.set('feeds', feeds);
  }

  importTakeout(csv) {
    const rows = yt.parseTakeoutCsv(csv);
    let added = 0;
    for (const r of rows) {
      if (!this.subs.get(r.id, null)) {
        this.subs.set(r.id, { id: r.id, name: r.name || r.id, avatar: null, addedAt: Date.now() });
        added++;
      }
    }
    return { found: rows.length, added };
  }

  // Channels saved without a proper name (or picture) get them looked up.
  // Each channel is tried at most once a week, so channels YouTube can't describe (deleted,
  // terminated) don't cause a burst of requests every time FreeReel starts.
  async fixNames() {
    if (this.isBlocked()) return 0;
    const week = 7 * 864e5;
    const todo = this.listSubs().filter((s) => (!s.name || /^UC[\w-]{22}$/.test(s.name) || !s.avatar) && !(s.fixTriedAt && Date.now() - s.fixTriedAt < week));
    let fixed = 0;
    await mapLimit(todo, 2, async (s) => {
      if (this.isBlocked()) return;
      const cur = this.subs.get(s.id, s);
      this.subs.set(s.id, { ...cur, fixTriedAt: Date.now() });
      const c = await yt.channel(s.id);
      if (c && c.info && c.info.name) {
        this.subs.set(s.id, { ...this.subs.get(s.id, s), name: c.info.name, avatar: c.info.avatar || s.avatar });
        fixed++;
      }
      await sleep(250);
    });
    return fixed;
  }

  setAvatar(id, avatar, name) {
    const s = this.subs.get(id, null);
    if (s && ((avatar && s.avatar !== avatar) || (name && s.name !== name))) {
      this.subs.set(id, { ...s, avatar: avatar || s.avatar, name: name || s.name });
    }
  }

  // New uploads from every subscription, newest first, Shorts filtered out.
  //
  // Gentle on YouTube on purpose (lots of requests from one connection is what gets it
  // flagged): busy channels are checked at most hourly, quiet ones a few times a day, at
  // most 120 channels per visit (stalest first), three at a time with a short pause, and
  // nothing at all while YouTube is pushing back.
  async subscriptionFeed({ force = false } = {}) {
    const subs = this.listSubs();
    const known = subs.filter((s) => { const c = this.cache.get('feeds')[s.id]; return c && c.at; }).length;
    const refresh = this._refresh(subs, force);
    // Most channels already known? Show them right away and let the check finish quietly
    // in the background (new uploads appear next time). Otherwise wait for it.
    const wait = force || known < subs.length * 0.8;
    let failed = 0;
    if (wait) failed = await refresh;
    else refresh.catch(() => {});
    const feeds = this.cache.get('feeds');
    let all = subs.flatMap((s) => ((feeds[s.id] && feeds[s.id].videos) || []).map((v) => ({ ...v, channel: v.channel || s.name })));
    all.sort((a, b) => (b.publishedAt || 0) - (a.publishedAt || 0));
    all = all.slice(0, 200);
    if (this.settings.get('hideShorts', true)) all = (await this._filterShorts(all, { wait })).slice(0, 150);
    return { videos: all, failed, total: subs.length };
  }

  // Checks the channels that are due, one batch at a time (see the note above).
  _refresh(subs, force) {
    if (this._refreshing) return this._refreshing;
    this._refreshing = (async () => {
      const feeds = this.cache.get('feeds');
      const now = Date.now();
      const DAY = 864e5;
      const maxAge = (c) => {
        if (force) return 10 * 60e3;
        const last = ((c && c.videos) || []).reduce((m, v) => Math.max(m, v.publishedAt || 0), 0);
        if (!last || now - last > 180 * DAY) return DAY;
        if (now - last > 14 * DAY) return 6 * 3600e3;
        return 3600e3;
      };
      const stale = this.isBlocked() || now < (this.pausedUntil || 0)
        ? []
        : subs
            .filter((s) => !feeds[s.id] || now - feeds[s.id].at >= maxAge(feeds[s.id]))
            .sort((a, b) => ((feeds[a.id] && feeds[a.id].at) || 0) - ((feeds[b.id] && feeds[b.id].at) || 0))
            .slice(0, force ? 200 : 120);
      let failed = 0;
      let refused = 0;
      await mapLimit(stale, 3, async (s) => {
        if (refused >= 3 || this.isBlocked()) return; // YouTube is pushing back: stop for now
        const c = feeds[s.id];
        try {
          let f = null;
          try {
            f = await yt.channelFeed(s.id);
          } catch (e) {
            if (/\b(403|429)\b/.test(e.message)) throw e; // don't pile on more requests
            f = null;
          }
          // Only when the public feed itself failed (an empty feed just means no uploads).
          if (!f) {
            // Backup: read the channel's Videos tab when its public feed is unavailable.
            const ch = await yt.channel(s.id);
            f = { name: ch.info.name, videos: ch.videos.slice(0, 15).map((v) => ({ ...v, channelId: s.id, channel: v.channel || ch.info.name, publishedAt: yt.agoToTime(v.published), published: '' })) };
          }
          feeds[s.id] = { at: Date.now(), videos: f.videos };
          if (f.name && f.name !== s.name) this.setAvatar(s.id, null, f.name);
        } catch (e) {
          failed++;
          if (/\b(403|429)\b/.test(e.message)) refused++;
          if (!c) feeds[s.id] = { at: 0, videos: [] };
        }
        await sleep(120);
      });
      if (refused >= 3) {
        this.pausedUntil = Date.now() + 30 * 60e3;
        this.log('feed: YouTube is refusing feed requests - pausing channel checks for 30 minutes');
      }
      // Merge into the latest saved copy (channels may have been removed meanwhile).
      const latest = this.cache.get('feeds');
      for (const s of stale) if (feeds[s.id] && this.subs.get(s.id, null)) latest[s.id] = feeds[s.id];
      this.cache.set('feeds', latest);
      return failed;
    })().finally(() => (this._refreshing = null));
    return this._refreshing;
  }

  async _filterShorts(videos, { wait = true } = {}) {
    const known = this.cache.get('shorts');
    const unknown = this.isBlocked() ? [] : videos.filter((v) => !v.short && !(v.id in known)).slice(0, 40);
    const check = async () => {
      await mapLimit(unknown, 3, async (v) => {
        known[v.id] = await yt.isShort(v.id);
        await sleep(100);
      });
      // keep the cache from growing forever
      const keys = Object.keys(known);
      if (keys.length > 5000) keys.slice(0, keys.length - 5000).forEach((k) => delete known[k]);
      this.cache.set('shorts', known);
    };
    if (wait) await check();
    else if (unknown.length && !this._shortsBusy) {
      this._shortsBusy = true;
      check().catch(() => {}).finally(() => (this._shortsBusy = false));
    }
    return videos.filter((v) => !v.short && !known[v.id]);
  }

  // ── history ──
  recordWatch(video, position, duration) {
    if (this.settings.get('pauseHistory', false)) return;
    const prev = this.history.get(video.id, null);
    this.history.set(video.id, {
      id: video.id,
      title: video.title,
      channel: video.channel,
      channelId: video.channelId,
      duration: duration || video.duration || (prev && prev.duration) || null,
      thumb: video.thumb,
      position: Math.max(0, Math.floor(position || 0)),
      watchedAt: Date.now(),
      count: (prev ? prev.count || 1 : 0) + (prev && Date.now() - prev.watchedAt < 3600e3 ? 0 : 1),
    });
    const keys = Object.keys(this.history.data);
    if (keys.length > 3000) {
      keys.sort((a, b) => this.history.data[a].watchedAt - this.history.data[b].watchedAt).slice(0, keys.length - 3000).forEach((k) => this.history.delete(k));
    }
  }

  listHistory() {
    return Object.values(this.history.data).sort((a, b) => b.watchedAt - a.watchedAt);
  }

  progress(id) {
    const h = this.history.get(id, null);
    return h ? { position: h.position, duration: h.duration } : null;
  }

  removeHistory(id) {
    this.history.delete(id);
  }

  clearHistory() {
    this.history.clear();
    this.cache.set('related', {});
  }

  // ── watch later ──
  listLater() {
    return this.later.get('list', []);
  }

  toggleLater(video) {
    const list = this.listLater();
    const i = list.findIndex((v) => v.id === video.id);
    if (i >= 0) list.splice(i, 1);
    else list.unshift({ id: video.id, title: video.title, channel: video.channel, channelId: video.channelId, duration: video.duration, thumb: video.thumb, addedAt: Date.now() });
    this.later.set('list', list);
    return i < 0;
  }

  // ── For you ──
  async related(videoId) {
    const rel = this.cache.get('related');
    const c = rel[videoId];
    if (c && Date.now() - c.at < 12 * 3600e3) return c.videos;
    if (this.isBlocked()) return c ? c.videos : []; // YouTube is pushing back: use what we have
    const r = await yt.next(videoId);
    rel[videoId] = { at: Date.now(), videos: r.related.slice(0, 20) };
    const keys = Object.keys(rel);
    if (keys.length > 300) keys.sort((a, b) => rel[a].at - rel[b].at).slice(0, keys.length - 300).forEach((k) => delete rel[k]);
    this.cache.set('related', rel);
    return rel[videoId].videos;
  }

  async forYou() {
    const hist = this.listHistory();
    // Seeds: recent videos you actually watched (more than a minute, or most of it).
    const seeds = hist.filter((h) => h.position >= 60 || (h.duration && h.position / h.duration > 0.5) || h.count > 1).slice(0, 12);
    if (!seeds.length) return { picks: [], because: [] };
    const results = await mapLimit(seeds, 4, (s) => this.related(s.id));
    const watched = new Set(hist.map((h) => h.id));
    const hideShorts = this.settings.get('hideShorts', true);
    const score = new Map();
    const because = [];
    results.forEach((vids, i) => {
      if (!Array.isArray(vids)) return;
      const seedWeight = 1 - i / (seeds.length + 4); // newer watches count more
      vids.forEach((v, rank) => {
        if (watched.has(v.id) || v.live) return;
        if (hideShorts && v.duration != null && v.duration <= 60) return;
        const cur = score.get(v.id) || { v, s: 0 };
        cur.s += seedWeight * (1 - rank / 25) + (this.isSubscribed(v.channelId) ? 0.35 : 0);
        score.set(v.id, cur);
      });
      if (i < 3) {
        const shelf = vids.filter((v) => !watched.has(v.id) && !v.live && !(hideShorts && v.duration != null && v.duration <= 60)).slice(0, 8);
        if (shelf.length >= 3) because.push({ seed: { id: seeds[i].id, title: seeds[i].title }, videos: shelf });
      }
    });
    // Rank, then keep at most two videos per channel so one channel can't take over.
    const perChannel = new Map();
    const picks = [];
    for (const { v } of [...score.values()].sort((a, b) => b.s - a.s)) {
      const k = v.channelId || v.channel;
      const n = perChannel.get(k) || 0;
      if (n >= 2) continue;
      perChannel.set(k, n + 1);
      picks.push(v);
      if (picks.length >= 36) break;
    }
    return { picks, because };
  }
}

module.exports = { Feed, mapLimit };
