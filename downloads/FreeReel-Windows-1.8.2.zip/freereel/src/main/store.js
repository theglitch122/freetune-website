// Tiny JSON-file persistence in the app's user-data folder.
// Everything FreeTune remembers lives here, on your own computer — nothing is uploaded.
const fs = require('fs');
const path = require('path');

class JsonStore {
  constructor(dir, name, defaults = {}) {
    this.file = path.join(dir, `${name}.json`);
    this.data = { ...defaults };
    try {
      if (fs.existsSync(this.file)) {
        this.data = { ...defaults, ...JSON.parse(fs.readFileSync(this.file, 'utf8')) };
      }
    } catch {
      // Corrupt file: start fresh rather than crash.
    }
    this._timer = null;
  }

  get(key, fallback) {
    return key in this.data ? this.data[key] : fallback;
  }

  set(key, value) {
    this.data[key] = value;
    this.saveSoon();
  }

  delete(key) {
    delete this.data[key];
    this.saveSoon();
  }

  clear() {
    this.data = {};
    this.saveNow();
  }

  saveSoon() {
    clearTimeout(this._timer);
    this._timer = setTimeout(() => this.saveNow(), 400);
  }

  saveNow() {
    clearTimeout(this._timer);
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(this.data));
      fs.renameSync(tmp, this.file);
    } catch (e) {
      console.error('store save failed', this.file, e.message);
    }
  }
}

module.exports = { JsonStore };
