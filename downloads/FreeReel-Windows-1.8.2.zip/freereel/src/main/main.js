const { app, BrowserWindow, ipcMain, shell, nativeTheme, Menu, dialog, session } = require('electron');
const path = require('path');
const fs = require('fs');
const { JsonStore } = require('./store');
const { YtDlp, pickFormats } = require('./ytdlp');
const { Library } = require('./library');
const { Feed } = require('./feed');
const { createServer } = require('./server');
const yt = require('./yt');
const { Updater } = require('./updater');

app.setAppUserModelId('com.freereel.app');
// Keep videos playing when FreeReel is minimized or covered. By default Chromium pauses
// muted videos that aren't visible, and FreeReel's picture stream is muted (sound plays
// separately), so without this, minimizing would stop the video.
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
app.commandLine.appendSwitch('disable-features', 'BackgroundVideoPauseOptimization,BackgroundVideoTrackOptimization');
if (!app.requestSingleInstanceLock()) {
  app.quit();
  process.exit(0);
}

const userData = app.getPath('userData');
const resourcesDir = app.isPackaged ? path.join(process.resourcesPath, 'resources') : path.join(__dirname, '..', '..', 'resources');

// ── log file (stays on this PC; Settings → Open log folder) ───────────────────
const logFile = path.join(userData, 'freereel.log');
try {
  fs.mkdirSync(userData, { recursive: true });
  if (fs.existsSync(logFile) && fs.statSync(logFile).size > 1_000_000) fs.renameSync(logFile, logFile + '.old');
} catch {}
function log(...args) {
  const line = `[${new Date().toISOString()}] ${args.map((a) => (typeof a === 'string' ? a : JSON.stringify(a))).join(' ')}\n`;
  process.stdout.write(line);
  try {
    fs.appendFileSync(logFile, line);
  } catch {}
}

// Auto quality: the highest quality whose bitrate fits comfortably in the measured
// connection speed. With no measurement yet, start at 720p (fast to start, looks good).
function autoHeight(heights, bitrates, bps, cap) {
  const ok = heights.filter((x) => x <= cap).sort((a, b) => b - a);
  if (!ok.length) return Math.min(...heights);
  if (!bps) return ok.find((x) => x <= 720) || ok[ok.length - 1];
  const fit = ok.find((x) => !bitrates[x] || bitrates[x] * 1000 * 1.6 + 160e3 <= bps);
  return fit || ok[ok.length - 1];
}

const DEFAULTS = { autoPip: true, audioLang: 'en', quality: 'auto', downloadQuality: 720, smallerDownloads: true, av1Smooth: false, hideShorts: true, autoplay: false, showSuggestions: true, pauseHistory: false, volume: 0.9, speed: 1 };
const settings = new JsonStore(userData, 'settings', { ...DEFAULTS, ytdlpUpdatedAt: 0 });
// 1.6.0 brought Auto quality: switch everyone to it once (they can pick a fixed one again).
if (!settings.get('autoQualityIntroduced', false)) {
  settings.set('quality', 'auto');
  settings.set('autoQualityIntroduced', true);
}
const stores = {
  library: new JsonStore(userData, 'library', {}),
  subs: new JsonStore(userData, 'subscriptions', {}),
  history: new JsonStore(userData, 'history', {}),
  later: new JsonStore(userData, 'watch-later', { list: [] }),
  cache: new JsonStore(userData, 'cache', {}),
};
let win = null;
const send = (ch, data) => win && !win.isDestroyed() && win.webContents.send(ch, data);

const ytdlp = new YtDlp({ binDir: path.join(userData, 'bin'), store: settings, log, onStatus: (s) => send('engine-status', s) });
const library = new Library({ dir: path.join(userData, 'Library'), store: stores.library, ytdlp, log, onChange: (it) => send('lib-change', it) });
const feed = new Feed({ ...stores, settings, log, isBlocked: () => ytdlp.blocked() });
let media = null;
const updater = new Updater({ app, appId: 'freereel', appName: 'FreeReel', log, onAvailable: (u) => send('update-available', u) });

function createWindow() {
  nativeTheme.themeSource = 'dark';
  win = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 940,
    minHeight: 600,
    backgroundColor: '#0f0f10',
    title: 'FreeReel',
    icon: path.join(resourcesDir, 'icon.png'),
    titleBarStyle: 'hidden',
    titleBarOverlay: { color: '#0f0f10', symbolColor: '#f1f1f1', height: 40 },
    show: false,
    webPreferences: {
      preload: path.join(__dirname, '..', 'preload.js'),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      spellcheck: false,
      backgroundThrottling: false,
    },
  });
  win.once('ready-to-show', () => {
    win.show();
    if (global.__bootOk) global.__bootOk(); // this version starts fine
  });
  // Pop the video out when FreeReel is minimized (if that setting is on), and back in on return.
  win.on('minimize', () => {
    if (settings.get('autoPip', true)) win.webContents.executeJavaScript('window.__autoPip && window.__autoPip()', true).catch(() => {});
  });
  const back = () => win && !win.isDestroyed() && win.webContents.executeJavaScript('window.__endAutoPip && window.__endAutoPip()', true).catch(() => {});
  win.on('restore', back);
  win.on('focus', back);
  win.on('closed', () => {
    win = null;
    quitCleanly();
  });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.webContents.on('console-message', (e, level, message, line, sourceId) => {
    const ev = e && typeof e === 'object' && e.message != null ? e : { level, message, lineNumber: line, sourceId };
    if (ev.level === 'error' || ev.level === 'warning' || ev.level >= 2) log(`window[${ev.level}]`, ev.message, `(${String(ev.sourceId || '').split(/[\\/]/).pop()}:${ev.lineNumber})`);
  });
  win.webContents.on('preload-error', (_e, p, err) => log('preload error', p, err && err.stack));
  win.webContents.on('render-process-gone', (_e, d) => log('window crashed', d.reason));
  win.webContents.on('before-input-event', (_e, input) => {
    if (input.type === 'keyDown' && (input.key === 'F12' || (input.control && input.shift && input.key.toLowerCase() === 'i'))) win.webContents.toggleDevTools();
  });
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
}

app.on('second-instance', () => {
  if (!win || win.isDestroyed()) return createWindow();
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
});

let quitting = false;
function quitCleanly() {
  if (quitting) return;
  quitting = true;
  try {
    Object.values(stores).forEach((s) => s.saveNow());
    settings.saveNow();
  } catch {}
  for (const w of BrowserWindow.getAllWindows()) {
    try {
      w.destroy();
    } catch {}
  }
  try {
    media && media.server.close();
  } catch {}
  app.quit();
  setTimeout(() => app.exit(0), 3000).unref();
}
app.on('window-all-closed', quitCleanly);
process.on('uncaughtException', (e) => {
  log('main error:', e && e.stack);
  if (quitting) app.exit(0);
});

// ── IPC ────────────────────────────────────────────────────────────────────────
function handle(channel, fn) {
  ipcMain.handle(channel, async (_e, ...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      log(`ipc ${channel} failed:`, e && e.message);
      return { ok: false, error: (e && e.message) || String(e) };
    }
  });
}

const isId = (id) => /^[\w-]{11}$/.test(String(id || ''));

function registerIpc() {
  handle('app:base', () => media.base);
  handle('app:version', () => global.__APP_VERSION__ || app.getVersion());
  // ── updates ──
  handle('update:check', () => updater.check());
  handle('update:pick', async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Choose an update file', filters: [{ name: 'FreeReel update', extensions: ['update'] }], properties: ['openFile'] });
    if (r.canceled || !r.filePaths[0]) return null;
    return updater.checkFile(r.filePaths[0]);
  });
  handle('update:apply', async () => {
    await updater.apply();
    setTimeout(() => quitCleanly(), 300);
    return true;
  });

  handle('app:openLogs', () => shell.showItemInFolder(logFile));
  handle('app:openLibraryFolder', () => shell.openPath(path.join(userData, 'Library')));

  handle('settings:all', () => {
    const out = {};
    for (const k of Object.keys(DEFAULTS)) out[k] = settings.get(k, DEFAULTS[k]);
    out.hasCookies = !!ytdlp.cookiesFile();
    return out;
  });
  handle('settings:set', (k, v) => {
    if (k === 'quality') {
      if (v === 'auto' || (Number.isFinite(v) && v >= 144 && v <= 4320)) settings.set(k, v);
    } else if (k in DEFAULTS && typeof v === typeof DEFAULTS[k]) settings.set(k, v);
    return true;
  });

  handle('yt:search', (q, cont) => yt.search(String(q || '').slice(0, 200), { continuation: cont }));
  handle('yt:channel', async (id, cont) => {
    const r = await yt.channel(id, { continuation: cont });
    if (r.info && feed.isSubscribed(id)) {
      const before = JSON.stringify(stores.subs.get(id, {}));
      feed.setAvatar(id, r.info.avatar, r.info.name);
      if (JSON.stringify(stores.subs.get(id, {})) !== before) send('subs-change', true);
    }
    return { ...r, subscribed: feed.isSubscribed(id) };
  });

  handle('net:bandwidth', () => (media ? media.bandwidth() : null));

  // Look a video's streams up ahead of time (hovering a thumbnail, or the up-next video)
  // so pressing play starts almost instantly. At most two lookups run at once.
  // Kept gentle on purpose: one at a time, at most one every 10 seconds, and none
  // at all for a while after YouTube shows its bot check.
  let prefetching = 0;
  let lastPrefetch = 0;
  handle('yt:prefetch', (id) => {
    if (!/^[\w-]{11}$/.test(String(id)) || prefetching >= 1 || ytdlp.blocked() || Date.now() - lastPrefetch < 10000 || library.filePath(id, 'video')) return false;
    prefetching++;
    lastPrefetch = Date.now();
    ytdlp.info(id).catch(() => {}).finally(() => prefetching--);
    return true;
  });

  // Fast part of the watch page: title, channel and suggestions.
  handle('yt:watch', async (id) => {
    if (!isId(id)) throw new Error('Not a valid video');
    const offline = library.get(id);
    const local = offline && offline.status === 'done' ? library.meta(id) : null;
    let r = null;
    try {
      r = await yt.next(id);
    } catch (e) {
      if (!local) throw e;
    }
    if (r && r.channelId) feed.setAvatar(r.channelId, r.avatar, r.channel);
    return {
      title: (r && r.title) || (local && local.title) || '',
      channel: (r && r.channel) || (local && local.channel) || '',
      channelId: (r && r.channelId) || (local && local.channelId) || null,
      avatar: r && r.avatar,
      subscribers: (r && r.subscribers) || '',
      related: r ? r.related.filter((v) => !(settings.get('hideShorts', true) && v.duration != null && v.duration <= 60)) : [],
      subscribed: feed.isSubscribed((r && r.channelId) || (local && local.channelId)),
      progress: feed.progress(id),
      offline: !!local,
      inLater: feed.listLater().some((v) => v.id === id),
    };
  });

  // Slower part: playable streams and full details. Downloaded videos play from disk.
  handle('yt:streams', async (id, height, langArg, capArg, fresh) => {
    if (!isId(id)) throw new Error('Not a valid video');
    if (fresh) {
      log('player: video', id, 'failed to play - looking its streams up again', typeof fresh === 'string' ? `(${fresh})` : '');
      ytdlp.invalidate(id);
    }
    const offline = library.get(id);
    if (offline && offline.status === 'done') {
      const m = library.meta(id) || {};
      return {
        offline: true,
        video: `${media.base}/local/${id}/video`,
        audio: offline.files.audio ? `${media.base}/local/${id}/audio` : null,
        poster: `${media.base}/local/${id}/thumb`,
        qualities: m.height ? [m.height] : [],
        height: m.height || null,
        duration: m.duration,
        description: m.description || '',
        chapters: m.chapters || [],
        uploadDate: m.uploadDate,
        title: m.title,
      };
    }
    const info = await ytdlp.info(id);
    if (info.is_live) throw new Error('Live streams aren’t supported in FreeReel yet. Watch it after it ends.');
    const pref = height != null ? height : settings.get('quality', 'auto');
    const auto = pref === 'auto';
    const cap = [2160, 1440, 1080, 720].find((x) => x <= (Number(capArg) || 1080)) || 1080;
    let want = auto ? cap : Number(pref) || 1080;
    const lang = String(langArg || settings.get('audioLang', 'en'));
    let p = pickFormats(info, want, { lang });
    const kbps = (f) => f.tbr || f.vbr || (f.filesize && info.duration ? (f.filesize * 8) / info.duration / 1000 : null);
    const bitrates = Object.fromEntries(p.qualities.map((q) => [q.height, Math.round(kbps(q) || 0)]));
    if (auto && p.video) {
      want = autoHeight(p.qualities.map((q) => q.height), bitrates, media.bandwidth(), cap);
      p = pickFormats(info, want, { lang });
    }
    if (!p.video && !p.fallback) throw new Error('No playable version of this video was found.');
    const h = p.video ? p.video.height : p.fallback.height;
    const availableAt = Math.max(0, ...[p.video, p.audio, p.fallback].filter(Boolean).map((f) => (f.available_at || 0) * 1000));
    if (availableAt > Date.now() + 1000) log('player: YouTube requires a', Math.ceil((availableAt - Date.now()) / 1000), 's wait before', id, 'can start');
    return {
      offline: false,
      video: p.video ? `${media.base}/stream/${id}/video?h=${h}` : `${media.base}/stream/${id}/muxed`,
      audio: p.video && p.audio ? `${media.base}/stream/${id}/audio?lang=${encodeURIComponent(p.audioLang || 'original')}` : null,
      audioTracks: p.audioTracks,
      audioLang: p.audioLang,
      fallback: p.fallback ? `${media.base}/stream/${id}/muxed` : null,
      availableAt,
      qualities: p.qualities.map((q) => q.height),
      bitrates,
      auto,
      cap,
      height: h,
      duration: info.duration,
      description: info.description || '',
      chapters: (info.chapters || []).map((c) => ({ start: c.start_time, title: c.title })),
      uploadDate: info.upload_date || null,
      views: info.view_count || null,
      likes: info.like_count || null,
      title: info.title,
    };
  });

  handle('feed:subs', (force) => feed.subscriptionFeed({ force: !!force }));
  handle('feed:forYou', () => feed.forYou());
  handle('subs:list', () => feed.listSubs());
  handle('subs:add', (input, known) => feed.subscribe(input, known || {}));
  handle('subs:remove', (id) => feed.unsubscribe(id));
  handle('subs:removeMany', (ids) => feed.unsubscribeMany(Array.isArray(ids) ? ids.slice(0, 5000) : []));
  handle('subs:restore', (entries) => feed.restore(entries));
  // Last resort for repeated bot checks: a cookies.txt exported from a spare Google
  // account. Kept in FreeReel's own folder and only sent to YouTube by the engine.
  handle('cookies:choose', async () => {
    const r = await dialog.showOpenDialog(win, {
      title: 'Choose a cookies.txt file (from a spare Google account)',
      filters: [{ name: 'Cookies file', extensions: ['txt'] }],
      properties: ['openFile'],
    });
    if (r.canceled || !r.filePaths[0]) return null;
    const text = fs.readFileSync(r.filePaths[0], 'utf8');
    if (!/^# (Netscape )?HTTP Cookie File/m.test(text) && !/\tTRUE\t|\tFALSE\t/.test(text)) throw new Error('That doesn’t look like a cookies.txt file. Export one with a “Get cookies.txt” style browser extension.');
    if (!/youtube\.com/.test(text)) throw new Error('That cookies file has no YouTube cookies in it. Export it while on youtube.com.');
    const dest = path.join(userData, 'cookies.txt');
    fs.writeFileSync(dest, text);
    settings.set('cookiesFile', dest);
    ytdlp.botUntil = 0;
    ytdlp.infoCache.clear();
    return true;
  });
  handle('cookies:clear', () => {
    const f = settings.get('cookiesFile', null);
    if (f) fs.rmSync(f, { force: true });
    settings.set('cookiesFile', null);
    ytdlp.infoCache.clear();
    return true;
  });

  handle('subs:import', async () => {
    const r = await dialog.showOpenDialog(win, {
      title: 'Choose your YouTube subscriptions file',
      filters: [{ name: 'Google Takeout subscriptions', extensions: ['csv'] }],
      properties: ['openFile'],
    });
    if (r.canceled || !r.filePaths[0]) return null;
    const csv = fs.readFileSync(r.filePaths[0], 'utf8');
    return feed.importTakeout(csv);
  });

  handle('history:list', () => feed.listHistory());
  handle('history:record', (video, pos, dur) => isId(video && video.id) && feed.recordWatch(video, pos, dur));
  handle('history:remove', (id) => feed.removeHistory(id));
  handle('history:clear', () => feed.clearHistory());
  handle('later:list', () => feed.listLater());
  handle('later:toggle', (video) => feed.toggleLater(video));

  handle('lib:list', () => library.list());
  handle('lib:add', (video, quality) => {
    if (!isId(video && video.id)) throw new Error('Not a valid video');
    return library.add(video, {
      quality: Number(quality) || settings.get('downloadQuality', 720),
      saver: settings.get('smallerDownloads', true),
      lang: settings.get('audioLang', 'en'),
      av1: settings.get('av1Smooth', false),
    });
  });
  handle('lib:remove', (id) => library.remove(id));
  handle('lib:retry', (id) => library.retry(id));
  handle('lib:cancel', (id) => library.cancel(id));
  handle('lib:bytes', () => library.totalBytes());

  handle('engine:status', () => ({ installed: ytdlp.installed() }));
  handle('engine:ensure', () => ytdlp.ensure().then(() => true));
  handle('engine:update', () => ytdlp.update());
}

app.whenReady().then(async () => {
  Menu.setApplicationMenu(null);
  log('FreeReel', global.__APP_VERSION__ || app.getVersion(), 'starting on', process.platform, process.getSystemVersion());

  // Privacy: the window may only load its own files and talk to FreeReel's local server.
  // Everything else — Google, ads, analytics, fonts, anything — is refused outright.
  const ses = session.defaultSession;
  ses.setPermissionRequestHandler((_wc, perm, cb) => cb(perm === 'fullscreen'));
  ses.webRequest.onBeforeRequest({ urls: ['<all_urls>'] }, (d, cb) => {
    const ok = d.url.startsWith('file:') || d.url.startsWith('devtools:') || d.url.startsWith('chrome-extension:') || /^http:\/\/127\.0\.0\.1:\d+\//.test(d.url) || d.url.startsWith('data:');
    cb({ cancel: !ok });
  });

  media = await createServer({ ytdlp, library, cacheDir: path.join(userData, 'thumb-cache'), log });
  registerIpc();
  createWindow();
  ytdlp.ensure().catch((e) => log('engine setup failed:', e.message));
  updater.watch();
  feed.fixNames().then((n) => { if (n) { log('subscriptions: filled in', n, 'channel names'); send('subs-change', true); } }).catch((e) => log('name fix failed:', e.message));
});
