// Offline library: downloads a video (picture + sound as two files, the same way
// YouTube serves them) plus its thumbnail and details, so it can be watched with no
// internet at all. Downloads queue up, run two at a time, survive restarts and resume
// where they stopped.

const fs = require('fs');
const path = require('path');
const { pickFormats } = require('./ytdlp');

const MAX_PARALLEL = 2;

class Library {
  constructor({ dir, store, ytdlp, log = console.log, onChange = () => {} }) {
    this.dir = dir;
    this.store = store; // { [id]: item }
    this.ytdlp = ytdlp;
    this.log = log;
    this.onChange = onChange;
    this.running = new Map(); // id -> AbortController
    fs.mkdirSync(dir, { recursive: true });
    // Anything that was mid-download when FreeReel closed goes back in the queue.
    for (const it of Object.values(this.store.data)) {
      if (it.status === 'downloading') it.status = 'queued';
      if (it.status === 'done' && !this._filesExist(it)) {
        it.status = 'error';
        it.error = 'The downloaded files are missing. Download it again.';
      }
    }
    this.store.saveSoon();
    setTimeout(() => this._pump(), 2000);
  }

  folder(id) {
    return path.join(this.dir, id);
  }

  _filesExist(it) {
    if (!it.files) return false;
    return ['video', 'audio'].every((k) => !it.files[k] || fs.existsSync(path.join(this.folder(it.id), it.files[k])));
  }

  list() {
    return Object.values(this.store.data).sort((a, b) => (b.addedAt || 0) - (a.addedAt || 0));
  }

  get(id) {
    return this.store.get(id, null);
  }

  _set(id, patch) {
    const it = { ...(this.store.get(id, {}) || {}), ...patch };
    this.store.set(id, it);
    this.onChange(it);
    return it;
  }

  add(video, { quality = 720, saver = true, av1 = false, lang = 'original' } = {}) {
    const existing = this.get(video.id);
    if (existing && (existing.status === 'done' || existing.status === 'downloading' || existing.status === 'queued')) return existing;
    const it = this._set(video.id, {
      id: video.id,
      title: video.title || existing?.title || '',
      channel: video.channel || '',
      channelId: video.channelId || null,
      duration: video.duration || null,
      quality,
      saver,
      av1,
      lang,
      status: 'queued',
      progress: 0,
      error: null,
      addedAt: Date.now(),
    });
    this._pump();
    return it;
  }

  retry(id) {
    const it = this.get(id);
    if (!it) return null;
    this._set(id, { status: 'queued', error: null });
    this._pump();
    return this.get(id);
  }

  cancel(id) {
    const ctrl = this.running.get(id);
    if (ctrl) ctrl.abort();
    this.remove(id);
  }

  remove(id) {
    const ctrl = this.running.get(id);
    if (ctrl) ctrl.abort();
    try {
      fs.rmSync(this.folder(id), { recursive: true, force: true });
    } catch (e) {
      this.log('library: remove failed', id, e.message);
    }
    this.store.delete(id);
    this.onChange({ id, removed: true });
  }

  totalBytes() {
    return this.list().reduce((s, it) => s + (it.bytes || 0), 0);
  }

  _pump() {
    if (this.running.size >= MAX_PARALLEL) return;
    const next = this.list()
      .filter((it) => it.status === 'queued' && !this.running.has(it.id))
      .sort((a, b) => (a.addedAt || 0) - (b.addedAt || 0))[0];
    if (!next) return;
    this._run(next.id).finally(() => {
      this.running.delete(next.id);
      this._pump();
    });
    this._pump();
  }

  async _run(id) {
    const ctrl = new AbortController();
    this.running.set(id, ctrl);
    const it = this.get(id);
    const dir = this.folder(id);
    fs.mkdirSync(dir, { recursive: true });
    this._set(id, { status: 'downloading', progress: 0, error: null, speed: 0 });
    try {
      const info = await this.ytdlp.info(id, { fresh: true });
      if (info.is_live) throw new Error('Live streams can’t be downloaded while they’re live.');
      const { video, audio, fallback } = pickFormats(info, it.quality || 720, { saver: it.saver !== false, av1: !!it.av1, lang: it.lang || 'original' });
      const parts = video && audio ? [['video', video], ['audio', audio]] : fallback ? [['video', fallback]] : [];
      if (!parts.length) throw new Error('No downloadable version of this video was found.');

      // Save the details first so the offline watch page has everything it needs.
      const meta = {
        id,
        title: info.title,
        channel: info.channel || info.uploader || it.channel,
        channelId: info.channel_id || it.channelId,
        description: info.description || '',
        duration: info.duration || it.duration,
        uploadDate: info.upload_date || null,
        chapters: (info.chapters || []).map((c) => ({ start: c.start_time, title: c.title })),
        height: parts[0][1].height || null,
        codec: String(parts[0][1].vcodec || '').split('.')[0],
      };
      fs.writeFileSync(path.join(dir, 'meta.json'), JSON.stringify(meta));
      this._set(id, { title: meta.title, channel: meta.channel, channelId: meta.channelId, duration: meta.duration, height: meta.height, codec: meta.codec });
      await this._saveThumb(id, dir);

      const sizes = parts.map(([, f]) => f.filesize || f.filesize_approx || 0);
      const total = sizes.reduce((a, b) => a + b, 0);
      const doneBytes = [0, 0];
      const files = {};
      let lastEmit = 0;
      for (let i = 0; i < parts.length; i++) {
        const [kind, f] = parts[i];
        const name = `${kind}.${f.ext}`;
        // YouTube sometimes refuses a link partway (HTTP 403). The download resumes, so just try again.
        for (let attempt = 0; ; attempt++) {
          try {
            await this.ytdlp.download({
          videoId: id,
          formatId: f.format_id,
          outFile: path.join(dir, name),
          signal: ctrl.signal,
          onProgress: ({ done, total: partTotal, speed }) => {
            doneBytes[i] = done;
            if (!sizes[i] && partTotal) sizes[i] = partTotal;
            const t = total || sizes.reduce((a, b) => a + b, 0);
            const progress = t ? Math.min(0.999, doneBytes.reduce((a, b) => a + b, 0) / t) : 0;
            const now = Date.now();
            if (now - lastEmit > 400) {
              lastEmit = now;
              this._set(id, { progress, speed });
            }
          },
            });
            break;
          } catch (e) {
            if (e.cancelled || attempt >= 2 || !/403|forbidden|timed out|reset|unable to download/i.test(e.message || '')) throw e;
            this.log('library: retrying', id, kind, '-', e.message);
            await new Promise((r) => setTimeout(r, 2000 * (attempt + 1)));
          }
        }
        files[kind] = name;
      }
      const bytes = Object.values(files).reduce((s, n) => {
        try {
          return s + fs.statSync(path.join(dir, n)).size;
        } catch {
          return s;
        }
      }, 0);
      this._set(id, { status: 'done', progress: 1, files, bytes, speed: 0, completedAt: Date.now() });
      this.log('library: downloaded', id, Math.round(bytes / 1e6) + ' MB');
    } catch (e) {
      if (e.cancelled) return;
      this.log('library: download failed', id, e.message);
      this._set(id, { status: 'error', error: e.message, speed: 0 });
    }
  }

  async _saveThumb(id, dir) {
    for (const q of ['maxresdefault', 'hq720', 'hqdefault']) {
      try {
        const res = await fetch(`https://i.ytimg.com/vi/${id}/${q}.jpg`);
        if (!res.ok) continue;
        const buf = Buffer.from(await res.arrayBuffer());
        if (buf.length < 2000) continue; // YouTube's grey "no thumbnail" placeholder
        fs.writeFileSync(path.join(dir, 'thumb.jpg'), buf);
        return;
      } catch {
        /* try next size */
      }
    }
  }

  meta(id) {
    try {
      return JSON.parse(fs.readFileSync(path.join(this.folder(id), 'meta.json'), 'utf8'));
    } catch {
      return null;
    }
  }

  filePath(id, kind) {
    const it = this.get(id);
    if (kind === 'thumb') {
      const p = path.join(this.folder(id), 'thumb.jpg');
      return fs.existsSync(p) ? p : null;
    }
    if (!it || it.status !== 'done' || !it.files || !it.files[kind]) return null;
    return path.join(this.folder(id), it.files[kind]);
  }
}

module.exports = { Library };
