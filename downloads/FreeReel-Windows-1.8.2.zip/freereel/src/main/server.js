// Local media server on 127.0.0.1 (unreachable from other computers), protected by a
// random per-launch key. It's the only thing the FreeReel window loads media from:
//   /stream/<id>/<video|audio|muxed>?h=1080  → relays YouTube's stream, with seeking
//   /local/<id>/<video|audio|thumb>          → plays a downloaded file, fully offline
//   /img?u=<url>                             → thumbnails, cached on disk
// Because the window never talks to Google directly, it can't be fingerprinted,
// cookied or tracked by YouTube's web code — there is none running.

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { pickFormats } = require('./ytdlp');
const { streamRequest } = require('./httpstream');

const IMG_HOSTS = /^(i\d?\.ytimg\.com|yt3\.ggpht\.com|yt3\.googleusercontent\.com|i\.ytimg\.com)$/;
const MIME = { mp4: 'video/mp4', m4a: 'audio/mp4', webm: 'video/webm', mkv: 'video/x-matroska', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp' };

function serveFile(req, res, file, kind) {
  let stat;
  try {
    stat = fs.statSync(file);
  } catch {
    res.writeHead(404).end();
    return;
  }
  const ext = path.extname(file).slice(1).toLowerCase();
  let type = MIME[ext] || 'application/octet-stream';
  if (kind === 'audio' && ext === 'webm') type = 'audio/webm';
  const range = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
  const headers = { 'Content-Type': type, 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store' };
  if (range && (range[1] || range[2])) {
    let start = range[1] ? Number(range[1]) : stat.size - Number(range[2]);
    let end = range[1] && range[2] ? Number(range[2]) : stat.size - 1;
    if (start >= stat.size || start > end) {
      res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` }).end();
      return;
    }
    end = Math.min(end, stat.size - 1);
    res.writeHead(206, { ...headers, 'Content-Range': `bytes ${start}-${end}/${stat.size}`, 'Content-Length': end - start + 1 });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file, { start, end }).on('error', () => res.destroy()).pipe(res);
  } else {
    res.writeHead(200, { ...headers, 'Content-Length': stat.size });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
  }
}

// YouTube's video servers slow a download to a crawl when it's fetched as one long
// open-ended request (which is what a <video> tag asks for). So the relay fetches
// small pieces instead: a 1 MB piece first so playback starts fast, then 8 MB pieces,
// always keeping the next piece already downloading. If a link expires or a
// connection drops mid-video, it quietly gets a fresh link and carries on from the
// exact byte it stopped at, so the player never notices.
const FIRST_PIECE = 1 << 20;
const PIECE = 8 << 20;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Connection speed, measured from real video pieces (time spent waiting on the
// player is left out). Auto quality uses it to pick what will play without buffering.
const meter = { bps: null, at: 0 };
function noteSpeed(bytes, ms) {
  if (bytes < 256 * 1024 || ms < 40) return;
  const bps = (bytes * 8 * 1000) / ms;
  meter.bps = meter.bps == null || Date.now() - meter.at > 10 * 60e3 ? bps : meter.bps * 0.6 + bps * 0.4;
  meter.at = Date.now();
}
const totalOf = (up) => {
  const m = /\/(\d+)\s*$/.exec(up.headers.get('content-range') || '');
  return m ? Number(m[1]) : null;
};

async function relay(req, res, getTarget, invalidate, log, rotate = () => {}) {
  const m = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
  const start = m && m[1] ? Number(m[1]) : 0;
  let end = m && m[2] ? Number(m[2]) : Infinity;
  if (m && !m[1] && m[2]) return passThrough(req, res, getTarget, invalidate, log); // "last N bytes" requests

  let closed = false;
  const controllers = new Set();
  res.on('close', () => {
    closed = true;
    for (const c of controllers) c.abort();
  });

  let target = null;
  let refused = 0;
  const open = async (from, to) => {
    let lastErr = null;
    for (let attempt = 0; attempt < 5; attempt++) {
      if (closed) throw new Error('closed');
      if (!target) target = await getTarget();
      if (!target) throw Object.assign(new Error('Not found'), { status: 404 });
      // YouTube makes players wait (as long as its pre-roll ad would run) before a new
      // link works; asking sooner gets refused. Wait it out like YouTube's own player.
      const wait = (target.availableAt || 0) - Date.now();
      if (wait > 0) {
        if (attempt === 0 && from === 0) log('server: waiting', Math.ceil(wait / 1000), 's before YouTube allows this stream');
        await sleep(Math.min(wait, 120000));
        if (closed) throw new Error('closed');
      }
      const headers = { ...(target.headers || {}) };
      delete headers['Accept-Encoding'];
      headers.Range = `bytes=${from}-${Number.isFinite(to) ? to : ''}`;
      const ac = new AbortController();
      controllers.add(ac);
      let up = null;
      try {
        up = await streamRequest(target.url, { headers, signal: ac.signal, family: target.family || 0 });
      } catch (e) {
        lastErr = e;
      }
      if (up && (up.status === 206 || (up.status === 200 && from === 0))) return { up, ac, total: up.status === 206 ? totalOf(up) : Number(up.headers.get('content-length')) || null };
      controllers.delete(ac);
      if (up) up.cancel();
      if (up && up.status === 416) throw Object.assign(new Error('Range not satisfiable'), { status: 416, total: totalOf(up) });
      if (closed) throw new Error('closed');
      if (up && (up.status === 403 || up.status === 410 || up.status === 404)) {
        log('server: upstream', up.status, '- refreshing stream link');
        refused++;
        if (refused === 2 && up.status === 403) rotate(); // a fresh link was refused too
        else invalidate();
        target = null;
      } else {
        lastErr = lastErr || new Error(`upstream ${up ? up.status : 'unreachable'}`);
        await sleep(300 * (attempt + 1));
      }
    }
    throw lastErr || new Error('Stream unavailable');
  };

  let cur;
  let curTo = Math.min(end, start + FIRST_PIECE - 1);
  try {
    cur = await open(start, curTo);
  } catch (e) {
    if (closed) return;
    if (e.status === 416) res.writeHead(416, e.total ? { 'Content-Range': `bytes */${e.total}` } : {}).end();
    else if (e.status === 404) res.writeHead(404).end();
    else res.writeHead(502, { 'Content-Type': 'text/plain' }).end(e.message || 'Stream unavailable');
    return;
  }
  const total = cur.total;
  if (total != null) end = Math.min(end, total - 1);
  curTo = Math.min(curTo, end);
  if (cur.up.status === 200) curTo = end; // the server sent the whole file at once
  const out = { 'Content-Type': cur.up.headers.get('content-type') || target.mime, 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store' };
  if (Number.isFinite(end)) out['Content-Length'] = end - start + 1;
  if (m && total != null) out['Content-Range'] = `bytes ${start}-${end}/${total}`;
  res.writeHead(m && total != null ? 206 : 200, out);
  if (req.method === 'HEAD') {
    cur.ac.abort();
    res.end();
    return;
  }

  const drain = () => new Promise((r) => {
    const done = () => { res.off('drain', done); res.off('close', done); r(); };
    res.on('drain', done);
    res.on('close', done);
  });
  let pos = start;
  let next = null;
  let empties = 0;
  while (!closed) {
    // keep the next piece downloading while this one plays out
    if (!next && curTo < end) {
      const range = [curTo + 1, Math.min(end, curTo + PIECE)];
      next = { range, p: open(range[0], range[1]) };
      next.p.catch(() => {});
    }
    let pieceBytes = 0;
    let busy = 0;
    let mark = Date.now();
    try {
      for await (const chunk of cur.up.body) {
        busy += Date.now() - mark;
        if (closed) break;
        const buf = Buffer.from(chunk);
        pieceBytes += buf.length;
        const room = curTo - pos + 1;
        const piece = buf.length > room ? buf.subarray(0, room) : buf;
        pos += piece.length;
        if (!res.write(piece)) await drain();
        mark = Date.now();
        if (pos > curTo) break;
      }
    } catch {
      /* connection dropped mid-piece: picked up below */
    }
    noteSpeed(pieceBytes, busy);
    empties = pieceBytes ? 0 : empties + 1;
    if (empties >= 3) break; // the server keeps sending nothing: stop rather than loop
    controllers.delete(cur.ac);
    if (closed) break;
    try {
      if (pos <= curTo) {
        cur = await open(pos, curTo); // finish this piece from where it stopped
        continue;
      }
      if (!next) break; // all done
      try {
        cur = await next.p;
      } catch (e) {
        if (e.status === 416) break;
        cur = await open(next.range[0], next.range[1]);
      }
      curTo = next.range[1];
      next = null;
    } catch (e) {
      if (!closed) log('server: stream gave up at', pos, '-', e.message);
      break;
    }
  }
  if (next) next.p.then((n) => n.ac.abort(), () => {});
  if (closed) return;
  if (pos > end || !Number.isFinite(end)) res.end();
  else res.destroy();
}

// Plain relay for unusual requests (e.g. "the last N bytes").
async function passThrough(req, res, getTarget, invalidate, log) {
  for (let attempt = 0; attempt < 2; attempt++) {
    let target;
    try {
      target = await getTarget();
    } catch (e) {
      res.writeHead(502, { 'Content-Type': 'text/plain' }).end(e.message);
      return;
    }
    if (!target) {
      res.writeHead(404).end();
      return;
    }
    const headers = { ...(target.headers || {}) };
    delete headers['Accept-Encoding'];
    if (req.headers.range) headers.Range = req.headers.range;
    const up = await streamRequest(target.url, { headers, family: target.family || 0 }).catch(() => null);
    if (up && (up.ok || up.status === 206)) {
      const out = { 'Content-Type': up.headers.get('content-type') || target.mime, 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store' };
      for (const h of ['content-length', 'content-range']) {
        const v = up.headers.get(h);
        if (v) out[h.replace(/(^|-)\w/g, (s) => s.toUpperCase())] = v;
      }
      res.writeHead(up.status, out);
      if (req.method === 'HEAD') {
        up.cancel();
        return res.end();
      }
      up.body.on('error', () => res.destroy());
      res.on('close', () => up.cancel());
      up.body.pipe(res);
      return;
    }
    if (up) up.cancel();
    if (up && up.status === 416) {
      res.writeHead(416).end();
      return;
    }
    log('server: upstream', up ? up.status : 'unreachable', '- refreshing stream link');
    invalidate();
  }
  res.writeHead(502, { 'Content-Type': 'text/plain' }).end('Stream unavailable');
}

function createServer({ ytdlp, library, cacheDir, log = console.log }) {
  const key = crypto.randomBytes(12).toString('hex');
  fs.mkdirSync(cacheDir, { recursive: true });

  const server = http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://x');
    const parts = u.pathname.split('/').filter(Boolean);
    if (parts[0] !== key) {
      res.writeHead(403).end();
      return;
    }
    const [, route, id, kind] = parts;
    try {
      if (route === 'stream' && /^[\w-]{11}$/.test(id) && /^(video|audio|muxed)$/.test(kind)) {
        const h = Math.min(4320, Math.max(144, Number(u.searchParams.get('h')) || 1080));
        return relay(
          req,
          res,
          async () => {
            const info = await ytdlp.info(id);
            const p = pickFormats(info, h, { lang: u.searchParams.get('lang') || 'original' });
            const f = kind === 'video' ? p.qualities.find((q) => q.height === h) || p.video : kind === 'audio' ? p.audio : p.fallback;
            if (!f) return null;
            return { url: f.url, headers: f.http_headers || info.http_headers, mime: kind === 'audio' ? 'audio/mp4' : 'video/mp4', family: info._family || 0, availableAt: (f.available_at || 0) * 1000 };
          },
          () => ytdlp.invalidate(id),
          log,
          () => ytdlp.nextStrategy()
        );
      }
      if (route === 'local' && /^[\w-]{11}$/.test(id) && /^(video|audio|thumb)$/.test(kind)) {
        const file = library.filePath(id, kind);
        if (!file) {
          res.writeHead(404).end();
          return;
        }
        return serveFile(req, res, file, kind);
      }
      if (route === 'img') {
        const src = u.searchParams.get('u') || '';
        let target;
        try {
          target = new URL(src);
        } catch {
          res.writeHead(400).end();
          return;
        }
        if (target.protocol !== 'https:' || !IMG_HOSTS.test(target.hostname)) {
          res.writeHead(403).end();
          return;
        }
        const file = path.join(cacheDir, crypto.createHash('sha1').update(target.href).digest('hex'));
        if (fs.existsSync(file)) {
          res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'max-age=604800' });
          fs.createReadStream(file).pipe(res);
          return;
        }
        const up = await fetch(target.href).catch(() => null);
        if (!up || !up.ok) {
          res.writeHead(up ? up.status : 502).end();
          return;
        }
        const buf = Buffer.from(await up.arrayBuffer());
        fs.writeFile(file, buf, () => {});
        res.writeHead(200, { 'Content-Type': up.headers.get('content-type') || 'image/jpeg', 'Cache-Control': 'max-age=604800' });
        res.end(buf);
        return;
      }
      res.writeHead(404).end();
    } catch (e) {
      log('server error', req.url, e.message);
      if (!res.headersSent) res.writeHead(500).end();
      else res.destroy();
    }
  });

  // Trim the thumbnail cache to ~300 MB on startup.
  try {
    const files = fs.readdirSync(cacheDir).map((f) => {
      const p = path.join(cacheDir, f);
      const s = fs.statSync(p);
      return { p, size: s.size, t: s.atimeMs };
    });
    let total = files.reduce((a, f) => a + f.size, 0);
    for (const f of files.sort((a, b) => a.t - b.t)) {
      if (total < 300e6) break;
      fs.rmSync(f.p, { force: true });
      total -= f.size;
    }
  } catch {
    /* cache trimming is best-effort */
  }

  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const base = `http://127.0.0.1:${server.address().port}/${key}`;
      log('server: ready');
      resolve({ server, base, bandwidth: () => (meter.bps && Date.now() - meter.at < 10 * 60e3 ? meter.bps : null) });
    });
  });
}

module.exports = { createServer, serveFile, noteSpeed, meter };
