'use strict';
/* FreeReel window. Talks to the rest of the app only through window.reel (preload.js).
   Never redeclare `reel` at the top level: it's a protected global. */

const R = window.reel;
const $ = (sel, root = document) => root.querySelector(sel);

function h(spec, attrs, ...kids) {
  const [tag, ...classes] = spec.split('.');
  const el = document.createElement(tag || 'div');
  if (classes.length) el.className = classes.join(' ');
  if (attrs && (typeof attrs !== 'object' || attrs instanceof Node || Array.isArray(attrs))) {
    kids.unshift(attrs);
    attrs = null;
  }
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'text') el.textContent = v;
    else if (k === 'html') el.innerHTML = v; // static icon markup only
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat(Infinity)) {
    if (k == null || k === false) continue;
    el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
  return el;
}

const ICON = {
  play: '<svg viewBox="0 0 24 24" class="filled"><path d="M8 5v14l11-7z"/></svg>',
  pause: '<svg viewBox="0 0 24 24" class="filled"><path d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>',
  more: '<svg viewBox="0 0 24 24" class="filled"><circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg>',
  down: '<svg viewBox="0 0 24 24"><path d="M12 3v12M7 10l5 5 5-5M4 20h16"/></svg>',
  check: '<svg viewBox="0 0 24 24"><path d="M5 12l5 5L20 7"/></svg>',
  clock: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  vol: '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor" stroke="none"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/></svg>',
  mute: '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor" stroke="none"/><path d="M17 9l5 6M22 9l-5 6"/></svg>',
  full: '<svg viewBox="0 0 24 24"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>',
  unfull: '<svg viewBox="0 0 24 24"><path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg>',
  pip: '<svg viewBox="0 0 24 24"><rect x="2.5" y="4.5" width="19" height="15" rx="2"/><rect x="11.5" y="11" width="8" height="6" rx="1" fill="currentColor" stroke="none"/></svg>',
  replay: '<svg viewBox="0 0 24 24"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>',
  plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
  trash: '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>',
  refresh: '<svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-2.3-5.7L20 8"/><path d="M20 3v5h-5"/></svg>',
};
const icon = (n) => h('span', { html: ICON[n], style: 'display:contents' });

const fmtTime = (s) => {
  if (!isFinite(s) || s < 0) s = 0;
  s = Math.floor(s);
  const hh = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = String(s % 60).padStart(2, '0');
  return hh ? `${hh}:${String(m).padStart(2, '0')}:${sec}` : `${m}:${sec}`;
};
const fmtNum = (n) => new Intl.NumberFormat('en', { notation: 'compact', maximumFractionDigits: 1 }).format(n);
const fmtBytes = (b) => (b >= 1e9 ? (b / 1e9).toFixed(1) + ' GB' : b >= 1e6 ? Math.round(b / 1e6) + ' MB' : Math.max(0, Math.round(b / 1e3)) + ' KB');
function ago(ts) {
  if (!ts) return '';
  const s = (Date.now() - ts) / 1000;
  const units = [[31536000, 'year'], [2592000, 'month'], [604800, 'week'], [86400, 'day'], [3600, 'hour'], [60, 'minute']];
  for (const [n, u] of units) if (s >= n) { const v = Math.floor(s / n); return `${v} ${u}${v > 1 ? 's' : ''} ago`; }
  return 'just now';
}
const uploadDate = (d) => (d && /^\d{8}$/.test(d) ? new Date(`${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6)}T12:00:00`).toLocaleDateString('en', { year: 'numeric', month: 'short', day: 'numeric' }) : '');

let toastTimer;
function toast(msg, isError = false) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.remove('has-action');
  t.classList.toggle('error', isError);
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), isError ? 5500 : 2600);
}

async function api(name, ...args) {
  const r = await R[name](...args);
  if (!r || !r.ok) throw new Error((r && r.error) || 'Something went wrong');
  return r.data;
}

// ── state ──────────────────────────────────────────────────────────────────────
const state = {
  base: '',
  settings: {},
  subs: [],
  lib: new Map(),
  hist: new Map(),
  later: new Set(),
};

const img = (url) => (url ? `${state.base}/img?u=${encodeURIComponent(url)}` : '');
function thumbFor(v) {
  const d = state.lib.get(v.id);
  if (d && d.status === 'done') return `${state.base}/local/${v.id}/thumb`;
  return img(v.thumb || `https://i.ytimg.com/vi/${v.id}/mqdefault.jpg`);
}

// ── menus & dialogs ────────────────────────────────────────────────────────────
function openMenu(x, y, items) {
  const m = $('#menu');
  m.replaceChildren(...items.filter(Boolean).map((it) => h('button', { role: 'menuitem', text: it.label, onclick: () => { closeMenu(); it.run(); } })));
  m.hidden = false;
  const r = m.getBoundingClientRect();
  m.style.left = Math.min(x, innerWidth - r.width - 8) + 'px';
  m.style.top = Math.min(y, innerHeight - r.height - 8) + 'px';
  m.querySelector('button')?.focus();
}
function closeMenu() {
  $('#menu').hidden = true;
}
document.addEventListener('mousedown', (e) => { if (!$('#menu').contains(e.target)) closeMenu(); });
document.addEventListener('scroll', closeMenu, true);

function ask({ title, body, placeholder, confirm }) {
  return new Promise((resolve) => {
    const d = $('#dialog');
    const input = h('input', { type: 'text', placeholder, 'aria-label': title });
    const form = h('form', { method: 'dialog' },
      h('h2', { text: title }), h('p', { text: body }), input,
      h('div.btns', h('button.pill', { type: 'button', text: 'Cancel', onclick: () => { d.close(); resolve(null); } }), h('button.pill.primary', { type: 'submit', text: confirm })));
    form.addEventListener('submit', (e) => { e.preventDefault(); d.close(); resolve(input.value.trim() || null); });
    d.replaceChildren(form);
    d.showModal();
    input.focus();
  });
}
function confirmBox({ title, body, confirm, danger }) {
  return new Promise((resolve) => {
    const d = $('#dialog');
    d.replaceChildren(h('form', { method: 'dialog' }, h('h2', { text: title }), h('p', { text: body }),
      h('div.btns', h('button.pill', { type: 'button', text: 'Cancel', onclick: () => { d.close(); resolve(false); } }),
        h(`button.pill${danger ? '.danger' : '.primary'}`, { type: 'button', text: confirm, onclick: () => { d.close(); resolve(true); } }))));
    d.showModal();
  });
}

// ── video actions ──────────────────────────────────────────────────────────────
async function download(v) {
  try {
    const it = await api('download', v);
    state.lib.set(it.id, it);
    updateDownloadUI(it);
    toast(it.status === 'done' ? 'Already downloaded' : `Downloading “${v.title || 'video'}”`);
  } catch (e) {
    toast(e.message, true);
  }
}
async function toggleLater(v) {
  try {
    const added = await api('toggleLater', v);
    if (added) state.later.add(v.id);
    else state.later.delete(v.id);
    toast(added ? 'Saved to Watch later' : 'Removed from Watch later');
    document.querySelectorAll(`[data-later="${v.id}"]`).forEach((b) => b.classList.toggle('on', added));
    if (location.hash === '#later' && !added) route();
  } catch (e) {
    toast(e.message, true);
  }
}
function videoMenu(v, e, extra = []) {
  const d = state.lib.get(v.id);
  openMenu(e.clientX, e.clientY, [
    { label: state.later.has(v.id) ? 'Remove from Watch later' : 'Save to Watch later', run: () => toggleLater(v) },
    !d ? { label: 'Download', run: () => download(v) } : d.status === 'done' ? { label: 'Delete download', run: () => removeDownload(v.id) } : null,
    v.channelId ? { label: `Go to ${v.channel || 'channel'}`, run: () => go(`channel/${v.channelId}`) } : null,
    ...extra,
  ]);
}

// ── cards ──────────────────────────────────────────────────────────────────────
function meta(v) {
  const parts = [];
  if (v.views != null) parts.push(`${fmtNum(v.views)} views`);
  if (v.published) parts.push(v.published);
  else if (v.publishedAt) parts.push(ago(v.publishedAt));
  return parts.join(', ');
}
function thumbBox(v) {
  const d = state.lib.get(v.id);
  const p = state.hist.get(v.id);
  const dur = v.duration || (p && p.duration);
  return h('div.thumb',
    h('img.fade', { src: thumbFor(v), alt: '', loading: 'lazy', decoding: 'async', onload: (e) => e.target.classList.add('ready'), onerror: (e) => { if (!e.target.dataset.f) { e.target.dataset.f = 1; e.target.src = img(`https://i.ytimg.com/vi/${v.id}/hqdefault.jpg`); } else e.target.classList.add('ready'); } }),
    v.live ? h('span.badge.live', { text: 'LIVE' }) : dur ? h('span.badge', { text: fmtTime(dur) }) : null,
    d && d.status === 'done' ? h('span.badge.offline', icon('check'), 'Offline') : null,
    p && dur && p.position > 10 ? h('div.watched', h('i', { style: { width: Math.min(100, (p.position / dur) * 100) + '%' } })) : null
  );
}
// Hovering a thumbnail for a moment starts looking its streams up, so it plays sooner.
let hoverTimer = null;
const prefetched = new Set();
function hoverPrefetch(id) {
  clearTimeout(hoverTimer);
  if (prefetched.has(id)) return;
  hoverTimer = setTimeout(() => {
    R.prefetch(id).then((r) => { if (r && r.ok && r.data) prefetched.add(id); }).catch(() => {});
  }, 900);
}

// Highest quality worth streaming on this screen (Auto never goes above it).
const screenCap = () => Math.round(Math.max(screen.width * 9 / 16, screen.height) * (window.devicePixelRatio || 1));

// Channel picture for a video: from your subscriptions when known, otherwise the
// channel's initial on a colour picked from its name (the same colour every time).
const subsById = () => (state._subsMap && state._subsMap.n === state.subs.length ? state._subsMap.m : (state._subsMap = { n: state.subs.length, m: new Map(state.subs.map((x) => [x.id, x])) }).m);
function avatarFor(v, cls = 'av') {
  const s = v.channelId && subsById().get(v.channelId);
  const url = v.avatar || (s && s.avatar);
  if (url) return h(`img.${cls}.fade`, { src: img(url), alt: '', loading: 'lazy', decoding: 'async', onload: (e) => e.target.classList.add('ready'), onerror: (e) => e.target.classList.add('ready') });
  const name = v.channel || (s && s.name) || '?';
  let hash = 0;
  for (const c of name) hash = (hash * 31 + c.codePointAt(0)) >>> 0;
  return h(`span.${cls}`, { text: name.trim().charAt(0).toUpperCase() || '?', style: { background: `hsl(${hash % 360} 32% 34%)` } });
}

function card(v, extraMenu) {
  const showChannel = v.channel && v.channelId;
  const chan = (child) => (v.channelId ? h('a', { href: `#channel/${v.channelId}`, onclick: (e) => e.stopPropagation(), 'aria-label': v.channel || 'Channel' }, child) : child);
  return h('a.card', { href: `#watch/${v.id}`, onmouseenter: () => hoverPrefetch(v.id), onmouseleave: () => clearTimeout(hoverTimer), oncontextmenu: (e) => { e.preventDefault(); videoMenu(v, e, extraMenu); } },
    thumbBox(v),
    h('div.card-body',
      chan(avatarFor(v)),
      h('div', { style: 'min-width:0' },
        h('div.t', { text: v.title, title: v.title }),
        h('div.s', showChannel ? h('a', { href: `#channel/${v.channelId}`, text: v.channel, onclick: (e) => e.stopPropagation() }) : v.channel || ''),
        meta(v) ? h('div.s', { text: meta(v) }) : null),
      h('button.icon-btn.menu-btn', { 'aria-label': 'More', onclick: (e) => { e.preventDefault(); e.stopPropagation(); videoMenu(v, e, extraMenu); } }, icon('more')))
  );
}
const grid = (vids, extraMenu) => h('div.grid', vids.map((v) => card(v, typeof extraMenu === 'function' ? extraMenu(v) : extraMenu)));
const shelf = (vids) => h('div.shelf', vids.map((v) => card(v)));
function skeletonGrid(n = 8) {
  return h('div.grid', Array.from({ length: n }, () => h('div',
    h('div.sk', { style: 'aspect-ratio:16/9' }),
    h('div', { style: 'display:grid;grid-template-columns:36px 1fr;gap:12px;margin-top:12px' },
      h('div.sk', { style: 'width:36px;height:36px;border-radius:50%' }),
      h('div', h('div.sk', { style: 'height:16px;width:90%;border-radius:6px' }), h('div.sk', { style: 'height:13px;margin-top:10px;width:55%;border-radius:6px' }))))));
}

// ── routing ────────────────────────────────────────────────────────────────────
const main = $('#main');
let renderToken = 0;
let currentPlayer = null;
let floatingPlayer = null; // a popped-out video still playing after you left its page
let autoPipped = false;

// Called by FreeReel when its window is minimized / restored (Settings → Pop out when minimized).
window.__autoPip = () => {
  const p = currentPlayer;
  if (!p || p.v.paused || document.pictureInPictureElement || !state.settings.autoPip) return;
  p.v.requestPictureInPicture().then(() => { autoPipped = true; }).catch(() => {});
};
window.__endAutoPip = () => {
  if (autoPipped && document.pictureInPictureElement && currentPlayer && document.pictureInPictureElement === currentPlayer.v) {
    document.exitPictureInPicture().catch(() => {});
  }
  autoPipped = false;
};
function go(r) {
  location.hash = r;
}
// Page changes crossfade (View Transitions), and the thumbnail you clicked grows into
// the player. Only on navigation: content arriving on the same page just fades in.
let navTransition = false;
let morphFrom = null;
const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)');
window.addEventListener('hashchange', () => { navTransition = true; route(); });
document.addEventListener('click', (e) => {
  const a = e.target.closest && e.target.closest('a[href^="#watch/"]');
  morphFrom = a ? a.querySelector('.thumb') : null;
}, true);
let swapSeq = 0;
function swapMain(node) {
  const mine = ++swapSeq;
  const swap = () => {
    // A transition's swap runs a frame later; if newer content arrived since, keep that.
    if (mine !== swapSeq) return;
    main.replaceChildren(node);
    main.style.scrollBehavior = 'auto';
    main.scrollTop = 0;
    main.style.scrollBehavior = '';
  };
  if (!navTransition) {
    node.classList.add('enter');
    swap();
    return;
  }
  navTransition = false;
  const from = morphFrom && morphFrom.isConnected ? morphFrom : null;
  morphFrom = null;
  if (!document.startViewTransition || reduceMotion.matches || document.hidden) {
    swap();
    return;
  }
  if (from) from.style.viewTransitionName = 'reel-hero';
  const t = document.startViewTransition(() => {
    if (from) from.style.viewTransitionName = '';
    swap();
    const to = from && node.querySelector('[data-morph]');
    if (to) to.style.viewTransitionName = 'reel-hero';
  });
  t.finished.finally(() => node.querySelectorAll('[data-morph]').forEach((el) => (el.style.viewTransitionName = ''))).catch(() => {});
}
$('#back').onclick = () => history.back();
$('#fwd').onclick = () => history.forward();

function setView(...nodes) {
  const v = h('div.view', nodes);
  swapMain(v);
  return v;
}
function errorView(title, err, retry) {
  return setView(h('div.empty', h('h2', { text: title }), h('p', { text: err.message }), h('button.pill', { text: 'Try again', onclick: retry })));
}

async function route() {
  closeMenu();
  const [nextName] = (location.hash.slice(1) || 'home').split('/');
  if (currentPlayer) {
    if (document.pictureInPictureElement === currentPlayer.v && nextName !== 'watch') {
      // Keep the popped-out video playing while you browse. Moving it (not removing it)
      // keeps it running.
      if (floatingPlayer) floatingPlayer.destroy();
      floatingPlayer = currentPlayer;
      $('#float-host').append(currentPlayer.el);
    } else {
      currentPlayer.destroy();
    }
    currentPlayer = null;
  }
  if (floatingPlayer && nextName === 'watch') {
    floatingPlayer.destroy();
    floatingPlayer = null;
  }
  document.body.classList.remove('lights-down');
  const [name, ...rest] = (location.hash.slice(1) || 'home').split('/');
  document.body.classList.toggle('on-watch', name === 'watch');
  document.body.classList.remove('guide-open');
  const arg = decodeURIComponent(rest.join('/'));
  document.querySelectorAll('[data-nav]').forEach((a) => a.classList.toggle('active', a.dataset.nav === name));
  document.querySelectorAll('#side-subs a').forEach((a) => a.classList.toggle('active', a.getAttribute('href') === location.hash));
  if (name !== 'search') $('#search-input').value = '';
  const token = ++renderToken;
  const live = () => token === renderToken;
  const views = { home: viewHome, subscriptions: viewSubs, library: viewLibrary, later: viewLater, history: viewHistory, settings: viewSettings, search: viewSearch, channel: viewChannel, watch: viewWatch };
  await (views[name] || viewHome)(arg, live);
}

// ── guide (left menu) ──────────────────────────────────────────────────────────
// Full menu on wide windows, a slim icon rail on narrow ones (or whenever you choose it),
// and out of the way on the watch page until you open it with the menu button.
function guidePref() {
  try { return localStorage.getItem('fr.guide') || 'auto'; } catch { return 'auto'; }
}
function applyGuide() {
  const pref = guidePref();
  document.body.classList.toggle('guide-mini', pref === 'mini' || (pref === 'auto' && innerWidth < 1240));
}
$('#guide-btn').onclick = () => {
  if (document.body.classList.contains('on-watch')) {
    document.body.classList.toggle('guide-open');
    return;
  }
  const mini = !document.body.classList.contains('guide-mini');
  try { localStorage.setItem('fr.guide', mini ? 'mini' : 'full'); } catch {}
  applyGuide();
};
addEventListener('resize', applyGuide);
applyGuide();

// ── home ───────────────────────────────────────────────────────────────────────
function welcome() {
  return h('div.welcome',
    h('section',
      h('h3', { text: 'Bring your subscriptions' }),
      h('ol',
        h('li', {}, 'Go to takeout.google.com in your browser and sign in.'),
        h('li', {}, 'Click “Deselect all”, then tick only “YouTube and YouTube Music”.'),
        h('li', {}, 'Click “All YouTube data included”, keep only “subscriptions”, and export.'),
        h('li', {}, 'Unzip the download and choose subscriptions.csv here.')
      ),
      h('button.pill.primary', { onclick: importSubs }, 'Choose subscriptions.csv')),
    h('section',
      h('h3', { text: 'Or start fresh' }),
      h('p', { text: 'Search for anything, or add channels one at a time. FreeReel learns what you like from what you watch, and keeps it on this PC.' }),
      h('button.pill', { onclick: addChannel }, icon('plus'), 'Add a channel'))
  );
}

// Home: chips across the top (like YouTube) switch between your sections. "All" shows
// a little of each; picking one shows more of it.
let homeChip = 'all';
async function viewHome(_a, live) {
  setView(h('div', { style: 'height:44px' }), skeletonGrid(12));
  const [fy, sf, hist] = await Promise.all([
    api('forYou').catch(() => ({ picks: [], because: [] })),
    state.subs.length ? api('subsFeed').catch((e) => ({ videos: [], error: e })) : { videos: [] },
    api('history').catch(() => []),
  ]);
  if (!live()) return;
  hist.forEach((x) => state.hist.set(x.id, x));
  const v = setView();
  if (!state.subs.length && !hist.length) {
    v.append(h('h1', { text: 'Welcome to FreeReel' }), h('p.lede', { text: 'Private YouTube: no ads, no Google account, no tracking. Your subscriptions, history and downloads live only on this PC.' }), welcome());
    return;
  }
  const cont = hist.filter((x) => x.duration && x.position > 30 && x.position < x.duration * 0.92);
  const sections = [];
  if (sf.videos.length) {
    sections.push({ key: 'subs', label: 'New from your channels', render: (full) => [h('h2', {}, 'New from your channels', h('a.more', { href: '#subscriptions', text: 'See all' })), grid(sf.videos.slice(0, full ? 48 : 8))] });
  }
  if (cont.length) sections.push({ key: 'continue', label: 'Continue watching', render: (full) => [h('h2', { text: 'Continue watching' }), full ? grid(cont.slice(0, 48)) : shelf(cont.slice(0, 10))] });
  if (fy.picks.length || fy.because.length) {
    sections.push({ key: 'foryou', label: 'For you', render: (full) => [
      fy.picks.length ? [h('h2', { text: 'For you' }), grid(fy.picks.slice(0, full ? 36 : 12))] : null,
      ...fy.because.slice(0, full ? 3 : 2).map((b) => [h('h2', { text: `Because you watched “${b.seed.title}”` }), shelf(b.videos)]),
    ] });
  }
  if (!sections.length) {
    v.append(h('p.lede', { text: 'Watch a few videos and FreeReel will suggest more like them here.' }), welcome());
    return;
  }
  if (!sections.some((x) => x.key === homeChip)) homeChip = 'all';
  const body = h('div');
  const chips = h('div.chips', { role: 'toolbar', 'aria-label': 'Show' });
  const paint = () => {
    chips.querySelectorAll('.chip').forEach((c) => c.setAttribute('aria-pressed', String(c.dataset.k === homeChip)));
    const shown = homeChip === 'all' ? sections : sections.filter((x) => x.key === homeChip);
    const fresh = h('div.enter-soft', shown.map((x) => x.render(homeChip !== 'all')));
    body.replaceChildren(fresh);
  };
  chips.append(...[{ key: 'all', label: 'All' }, ...sections].map((x) =>
    h('button.chip', { dataset: { k: x.key }, text: x.label, onclick: () => {
      if (homeChip === x.key) return;
      homeChip = x.key;
      main.scrollTo({ top: 0 });
      paint();
    } })));
  v.append(chips, body);
  paint();
}

// ── subscriptions ──────────────────────────────────────────────────────────────
async function importSubs() {
  try {
    const r = await api('importSubs');
    if (!r) return;
    if (!r.found) return toast('No channels found in that file. Choose subscriptions.csv from your Takeout download.', true);
    toast(`Imported ${r.added} channel${r.added === 1 ? '' : 's'}${r.found > r.added ? ` (${r.found - r.added} already added)` : ''}`);
    await loadSubs();
    route();
  } catch (e) {
    toast(e.message, true);
  }
}
async function addChannel() {
  const input = await ask({ title: 'Add a channel', body: 'Paste a channel link or its @handle.', placeholder: '@channelname or https://www.youtube.com/@…', confirm: 'Add channel' });
  if (!input) return;
  try {
    const s = await api('subscribe', input);
    toast(`Subscribed to ${s.name}`);
    await loadSubs();
    route();
  } catch (e) {
    toast(e.message, true);
  }
}
async function setSubscribed(info, on) {
  try {
    if (on) await api('subscribe', info.id, { name: info.name, avatar: info.avatar });
    else await api('unsubscribe', info.id);
    toast(on ? `Subscribed to ${info.name}` : `Unsubscribed from ${info.name}`);
    await loadSubs();
    return on;
  } catch (e) {
    toast(e.message, true);
    return !on;
  }
}
function subscribeButton(info, subscribed) {
  const b = h('button.pill', { onclick: async () => {
    b.disabled = true;
    subscribed = await setSubscribed(info, !subscribed);
    paint();
    b.disabled = false;
  } });
  const paint = () => {
    b.className = subscribed ? 'pill on' : 'pill primary';
    b.replaceChildren(subscribed ? icon('check') : icon('plus'), subscribed ? 'Subscribed' : 'Subscribe');
  };
  paint();
  return b;
}

async function viewSubs(arg, live) {
  if (arg === 'manage') return viewManageSubs(live);
  if (!state.subs.length) {
    setView(h('h1', { text: 'Subscriptions' }), h('p.lede', { text: 'You haven’t subscribed to any channels yet.' }), welcome());
    return;
  }
  const head = () => h('div', { style: 'display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:22px' },
    h('h1', { text: 'Subscriptions', style: 'margin:0 auto 0 0' }),
    h('button.pill', { onclick: () => loadFeed(true) }, icon('refresh'), 'Refresh'),
    h('a.pill', { href: '#subscriptions/manage' }, `Manage ${state.subs.length} channels`));
  const loadFeed = async (force) => {
    setView(head(), skeletonGrid(12));
    try {
      const r = await api('subsFeed', force);
      if (!live()) return;
      const v = setView(head());
      if (r.failed) v.append(h('p.lede', { text: `${r.failed} channel${r.failed === 1 ? '' : 's'} didn’t load. They’ll be tried again next time.` }));
      v.append(r.videos.length ? grid(r.videos) : h('p.lede', { text: 'No recent videos from your channels.' }));
    } catch (e) {
      if (live()) errorView('Your subscriptions didn’t load', e, () => loadFeed(true));
    }
  };
  loadFeed(false);
}

// Manage channels: tick several (or all), then unsubscribe in one go. Undo for 10 seconds.
function viewManageSubs() {
  const selected = new Set();
  let filter = '';
  let sort = 'name';
  let lastClicked = null;
  let visible = [];

  const search = h('input', { type: 'search', placeholder: 'Filter channels', 'aria-label': 'Filter channels', class: 'mg-search',
    oninput: () => { filter = search.value.trim().toLowerCase(); paint(); } });
  const sortSel = h('select', { 'aria-label': 'Sort channels', onchange: () => { sort = sortSel.value; paint(); } },
    h('option', { value: 'name', text: 'A to Z' }),
    h('option', { value: 'stale', text: 'Least recent upload first' }),
    h('option', { value: 'recent', text: 'Most recent upload first' }));
  const all = h('input', { type: 'checkbox', 'aria-label': 'Select all shown', onchange: () => {
    visible.forEach((s) => (all.checked ? selected.add(s.id) : selected.delete(s.id)));
    paint();
  } });
  const count = h('span.mg-count');
  const removeBtn = h('button.pill.danger', { onclick: removeSelected });
  const clearBtn = h('button.pill', { text: 'Clear selection', onclick: () => { selected.clear(); paint(); } });
  const list = h('div.mg-list', { role: 'list' });

  function lastLabel(s) {
    if (!s.lastUpload) return 'No recent uploads checked yet';
    return `Last upload ${ago(s.lastUpload)}`;
  }
  function row(s, i) {
    const box = h('input', { type: 'checkbox', 'aria-label': `Select ${s.name}`, tabindex: '-1' });
    box.checked = selected.has(s.id);
    const el = h(`div.mg-row${selected.has(s.id) ? '.sel' : ''}`, { role: 'listitem', tabindex: '0',
      onclick: (e) => toggle(s, i, e.shiftKey),
      onkeydown: (e) => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); toggle(s, i, e.shiftKey); } } },
      box,
      s.avatar ? h('img', { src: img(s.avatar), alt: '' }) : h('span.ph', { text: (s.name || '?')[0].toUpperCase() }),
      h('div.mg-text', h('a', { href: `#channel/${s.id}`, text: s.name, onclick: (e) => e.stopPropagation() }), h('small', { text: lastLabel(s) })));
    return el;
  }
  // Shift-click selects everything between the last click and this one.
  function toggle(s, i, range) {
    const on = !selected.has(s.id);
    if (range && lastClicked != null) {
      const [a, b] = [Math.min(lastClicked, i), Math.max(lastClicked, i)];
      for (let k = a; k <= b; k++) on ? selected.add(visible[k].id) : selected.delete(visible[k].id);
    } else on ? selected.add(s.id) : selected.delete(s.id);
    lastClicked = i;
    paint(true);
  }
  function paint(keepScroll) {
    const top = main.scrollTop;
    visible = state.subs.filter((s) => !filter || (s.name || '').toLowerCase().includes(filter));
    if (sort === 'stale') visible.sort((a, b) => (a.lastUpload || 0) - (b.lastUpload || 0));
    if (sort === 'recent') visible.sort((a, b) => (b.lastUpload || 0) - (a.lastUpload || 0));
    for (const id of [...selected]) if (!state.subs.some((s) => s.id === id)) selected.delete(id);
    list.replaceChildren(...visible.map(row));
    if (!visible.length) list.append(h('p.lede', { text: state.subs.length ? 'No channels match that filter.' : 'You aren’t subscribed to any channels.' }));
    const shownSel = visible.filter((s) => selected.has(s.id)).length;
    all.checked = visible.length > 0 && shownSel === visible.length;
    all.indeterminate = shownSel > 0 && shownSel < visible.length;
    const n = selected.size;
    count.textContent = n ? `${n} selected` : `${state.subs.length} channel${state.subs.length === 1 ? '' : 's'}`;
    removeBtn.textContent = n ? `Unsubscribe from ${n}` : 'Unsubscribe';
    removeBtn.disabled = !n;
    clearBtn.hidden = !n;
    if (keepScroll) main.scrollTop = top;
  }
  async function removeSelected() {
    const ids = [...selected];
    if (!ids.length) return;
    const names = state.subs.filter((s) => selected.has(s.id)).map((s) => s.name);
    const preview = names.slice(0, 4).join(', ') + (names.length > 4 ? ` and ${names.length - 4} more` : '');
    const ok = await confirmBox({ title: `Unsubscribe from ${ids.length} channel${ids.length === 1 ? '' : 's'}?`, body: `${preview}. You can undo this for a few seconds afterwards.`, confirm: `Unsubscribe from ${ids.length}`, danger: true });
    if (!ok) return;
    try {
      const removed = await api('unsubscribeMany', ids);
      selected.clear();
      await loadSubs();
      paint();
      undoToast(`Unsubscribed from ${removed.length} channel${removed.length === 1 ? '' : 's'}`, async () => {
        await api('restoreSubs', removed);
        await loadSubs();
        if (location.hash === '#subscriptions/manage') paint();
        toast(`Restored ${removed.length} channel${removed.length === 1 ? '' : 's'}`);
      });
    } catch (e) {
      toast(e.message, true);
    }
  }

  paint();
  setView(
    h('div', { style: 'display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:18px' },
      h('h1', { text: 'Your channels', style: 'margin:0 auto 0 0' }),
      h('button.pill', { onclick: addChannel }, icon('plus'), 'Add a channel'),
      h('button.pill', { onclick: importSubs }, 'Import from Takeout')),
    h('div.mg-bar', h('label.mg-all', all, 'Select all'), search, sortSel, h('span.mg-spacer'), count, clearBtn, removeBtn),
    h('p.mg-hint', { text: 'Click channels to select them. Shift-click to select a range. Sort by least recent upload to find channels that have gone quiet.' }),
    list);
  search.focus();
}

// A toast with an Undo button that stays for 10 seconds.
function undoToast(text, onUndo) {
  const t = $('#toast');
  clearTimeout(toastTimer);
  t.classList.remove('error');
  t.replaceChildren(h('span', { text }), h('button.undo', { text: 'Undo', onclick: () => { t.classList.remove('show'); onUndo(); } }));
  t.classList.add('show', 'has-action');
  toastTimer = setTimeout(() => t.classList.remove('show', 'has-action'), 10000);
}

async function loadSubs() {
  try {
    state.subs = await api('subs');
  } catch {
    state.subs = [];
  }
  const box = $('#side-subs');
  if (!state.subs.length) {
    box.replaceChildren(h('p.hint', { text: 'Channels you subscribe to show up here.' }));
    return;
  }
  box.replaceChildren(...state.subs.map((s) =>
    h('a', { href: `#channel/${s.id}`, title: s.name },
      s.avatar ? h('img.fade', { src: img(s.avatar), alt: '', loading: 'lazy', decoding: 'async', onload: (e) => e.target.classList.add('ready'), onerror: (e) => e.target.classList.add('ready') }) : h('span.ph', { text: (s.name || '?')[0].toUpperCase() }),
      h('span', { text: s.name }))));
}

// ── downloads ──────────────────────────────────────────────────────────────────
async function removeDownload(id) {
  const it = state.lib.get(id);
  const ok = await confirmBox({ title: 'Delete this download?', body: `“${(it && it.title) || 'This video'}” will be removed from this PC. You can still stream it.`, confirm: 'Delete', danger: true });
  if (!ok) return;
  await api('removeDownload', id).catch((e) => toast(e.message, true));
}
function dlStatusText(it) {
  if (it.status === 'done') return `${it.height ? it.height + 'p, ' : ''}${fmtBytes(it.bytes || 0)}`;
  if (it.status === 'queued') return 'Waiting to download';
  if (it.status === 'downloading') return `${Math.round((it.progress || 0) * 100)}%${it.speed ? `, ${fmtBytes(it.speed)}/s` : ''}`;
  return 'Download failed';
}
function dlRow(it) {
  return h('div.dl-item', { dataset: { dl: it.id } },
    h('a', { href: `#watch/${it.id}` }, thumbBox({ ...it, thumb: `https://i.ytimg.com/vi/${it.id}/mqdefault.jpg` })),
    h('div', { style: 'min-width:0' },
      h('a', { href: `#watch/${it.id}` }, h('div.t', { text: it.title || it.id })),
      h('div.s', { text: [it.channel, dlStatusText(it)].filter(Boolean).join(', ') }),
      it.status === 'downloading' || it.status === 'queued' ? h('div.bar', h('i', { style: { width: Math.round((it.progress || 0) * 100) + '%' } })) : null,
      it.status === 'error' ? h('div.err', { text: it.error || 'Something went wrong' }) : null),
    h('div.acts',
      it.status === 'done' ? h('a.pill.primary', { href: `#watch/${it.id}` }, icon('play'), 'Watch') : null,
      it.status === 'error' ? h('button.pill', { text: 'Try again', onclick: () => api('retryDownload', it.id) }) : null,
      it.status === 'downloading' || it.status === 'queued'
        ? h('button.pill', { text: 'Cancel', onclick: () => api('cancelDownload', it.id) })
        : h('button.icon-btn', { 'aria-label': 'Delete download', title: 'Delete download', onclick: () => removeDownload(it.id) }, icon('trash'))));
}
async function viewLibrary(_a, live) {
  const items = await api('library').catch(() => []);
  if (!live()) return;
  items.forEach((it) => state.lib.set(it.id, it));
  const done = items.filter((i) => i.status === 'done');
  const bytes = done.reduce((s, i) => s + (i.bytes || 0), 0);
  setView(
    h('h1', { text: 'Downloads' }),
    h('div.dl-summary',
      h('span', { text: items.length ? `${done.length} video${done.length === 1 ? '' : 's'} ready offline, ${fmtBytes(bytes)} on this PC` : '' }),
      items.length ? h('button.pill', { text: 'Open folder', onclick: () => api('openLibraryFolder') }) : null),
    items.length
      ? h('div.dl-list', items.map(dlRow))
      : h('div.empty', h('h2', { text: 'Nothing downloaded yet' }), h('p', { text: 'Use Download on any video to keep it on this PC. Downloaded videos play with no internet, no buffering and nothing sent to YouTube.' })));
}
function updateDownloadUI(it) {
  if (it.removed) state.lib.delete(it.id);
  else state.lib.set(it.id, it);
  const active = [...state.lib.values()].filter((x) => x.status === 'downloading' || x.status === 'queued').length;
  const c = $('#dl-count');
  c.hidden = !active;
  c.textContent = active;
  const row = document.querySelector(`[data-dl="${it.id}"]`);
  if (row && location.hash === '#library') it.removed ? row.remove() : row.replaceWith(dlRow(it));
  document.querySelectorAll(`[data-dlbtn="${it.id}"]`).forEach((b) => paintDownloadButton(b, it.removed ? null : it));
}

// ── watch later & history ──────────────────────────────────────────────────────
async function viewLater(_a, live) {
  const list = await api('later').catch(() => []);
  if (!live()) return;
  state.later = new Set(list.map((v) => v.id));
  setView(h('h1', { text: 'Watch later' }),
    list.length ? grid(list) : h('div.empty', h('h2', { text: 'Nothing saved yet' }), h('p', { text: 'Right-click any video, or use the clock button on a video page, to save it for later.' })));
}
async function viewHistory(_a, live) {
  const list = await api('history').catch(() => []);
  if (!live()) return;
  list.forEach((x) => state.hist.set(x.id, x));
  const paused = state.settings.pauseHistory;
  setView(
    h('div', { style: 'display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px' },
      h('h1', { text: 'History', style: 'margin:0 auto 0 0' }),
      list.length ? h('button.pill', { text: 'Clear all history', onclick: async () => {
        if (await confirmBox({ title: 'Clear all history?', body: 'This also resets your For you picks. It can’t be undone.', confirm: 'Clear history', danger: true })) {
          await api('clearHistory');
          state.hist.clear();
          route();
        }
      } }) : null),
    h('p.lede', { text: paused ? 'History is paused in Settings, so new videos aren’t being added.' : 'Stored only on this PC. It powers Continue watching and For you.' }),
    list.length ? grid(list.map((x) => ({ ...x, published: `Watched ${ago(x.watchedAt)}` })), (v) => [{ label: 'Remove from history', run: async () => { await api('removeHistory', v.id); state.hist.delete(v.id); route(); } }])
      : h('div.empty', h('h2', { text: 'No history yet' }), h('p', { text: 'Videos you watch appear here.' })));
}

// ── search ─────────────────────────────────────────────────────────────────────
function resultRow(v) {
  return h('a.result', { href: `#watch/${v.id}`, oncontextmenu: (e) => { e.preventDefault(); videoMenu(v, e); } },
    thumbBox(v),
    h('div', { style: 'min-width:0' }, h('div.t', { text: v.title }), h('div.s', { text: meta(v) }),
      h('div.by', avatarFor(v), v.channelId ? h('a', { href: `#channel/${v.channelId}`, text: v.channel, onclick: (e) => e.stopPropagation() }) : v.channel)));
}
async function viewSearch(q, live) {
  const input = $('#search-input');
  if (input.value !== q) input.value = q;
  if (!q) {
    setView(h('div.empty', h('h2', { text: 'Search YouTube privately' }), h('p', { text: 'Searches go straight to YouTube with no account, cookies or history attached.' })));
    input.focus();
    return;
  }
  setView(h('div.results', Array.from({ length: 6 }, () => h('div.result', h('div.sk', { style: 'aspect-ratio:16/9' }), h('div', h('div.sk', { style: 'height:18px;width:80%' }), h('div.sk', { style: 'height:12px;width:40%;margin-top:10px' }))))));
  try {
    const r = await api('search', q);
    if (!live()) return;
    const list = h('div.results', r.videos.map(resultRow));
    let cont = r.continuation;
    const more = h('button.pill.load-more', { text: 'Show more', hidden: !cont, onclick: async () => {
      more.disabled = true;
      try {
        const n = await api('search', q, cont);
        n.videos.forEach((v) => list.append(resultRow(v)));
        cont = n.continuation;
        more.hidden = !cont || !n.videos.length;
      } catch (e) {
        toast(e.message, true);
      }
      more.disabled = false;
    } });
    setView(
      r.channels.length ? h('div.channel-row', r.channels.map((c) => h('a.chip-channel', { href: `#channel/${c.id}` },
        c.avatar ? h('img', { src: img(c.avatar), alt: '' }) : h('div.ph'), h('div', h('b', { text: c.name }), h('small', { text: c.subscribers }))))) : null,
      r.videos.length ? list : h('div.empty', h('h2', { text: `No results for “${q}”` }), h('p', { text: 'Try different words.' })),
      more);
  } catch (e) {
    if (live()) errorView('Search didn’t work', e, route);
  }
}

// ── channel ────────────────────────────────────────────────────────────────────
async function viewChannel(id, live) {
  setView(h('div.banner.sk'), skeletonGrid(8));
  try {
    const r = await api('channel', id);
    if (!live()) return;
    const i = r.info;
    const g = grid(r.videos);
    g.classList.add('own'); // the channel's own page: no avatar or name on every card
    let cont = r.continuation;
    const more = h('button.pill.load-more', { text: 'Show more', hidden: !cont, onclick: async () => {
      more.disabled = true;
      try {
        const n = await api('channel', id, cont);
        n.videos.forEach((v) => g.append(card({ ...v, channel: v.channel || i.name, channelId: id })));
        cont = n.continuation;
        more.hidden = !cont || !n.videos.length;
      } catch (e) {
        toast(e.message, true);
      }
      more.disabled = false;
    } });
    setView(
      i.banner ? h('div.banner', { style: { backgroundImage: `url("${img(i.banner)}")` } }) : null,
      h('div.ch-head',
        i.avatar ? h('img', { src: img(i.avatar), alt: '' }) : h('div.ph'),
        h('div.grow', h('h1', { text: i.name }), h('p', { text: [i.subscribers, i.description].filter(Boolean).join(' — ') })),
        subscribeButton(i, r.subscribed)),
      r.videos.length ? g : h('p.lede', { text: 'This channel has no videos.' }),
      more);
  } catch (e) {
    if (live()) errorView('This channel didn’t load', e, route);
  }
}

// ── player ─────────────────────────────────────────────────────────────────────
// YouTube sends HD picture and sound as two separate streams. The player plays the
// picture in a <video> and the sound in an <audio>, keeping them locked together.
class Player {
  constructor({ video, onEnded, onProgress, refetch }) {
    this.meta = video;
    this.refetch = refetch;
    this.recoverStep = 0;
    this.onEnded = onEnded;
    this.onProgress = onProgress;
    this.el = h('div.player.loading', { tabindex: '0' });
    this.v = h('video', { playsinline: true, preload: 'auto' });
    this.a = null;
    this.chapters = [];
    this.qualities = [];
    this.height = null;
    this.usingFallback = false;
    this.destroyed = false;
    this.lastSave = 0;
    this.poster = h('img.poster', { src: img(`https://i.ytimg.com/vi/${video.id}/hqdefault.jpg`), alt: '' });
    this.center = h('div.center', h('div.spinner'), h('button.big-play', { 'aria-label': 'Play', onclick: () => this.play() }, icon('play')));
    this.waitNote = h('div.wait-note');
    this.center.append(this.waitNote);
    this._centerKids = [...this.center.childNodes];
    this._buildControls();
    this.el.append(this.v, this.poster, this.center, this.controls);
    this._wire();
  }

  _buildControls() {
    this.done = h('div.done');
    this.buf = h('div.buf');
    this.knob = h('div.knob');
    this.tip = h('div.tip');
    this.marks = h('div');
    this.scrub = h('div.scrub', h('div.track', this.buf, this.done, this.marks), this.knob, this.tip);
    this.btnPlay = h('button.icon-btn', { 'aria-label': 'Play (K)', onclick: () => this.toggle() }, icon('play'));
    this.btnMute = h('button.icon-btn', { 'aria-label': 'Mute (M)', onclick: () => this.setMuted(!this.muted) }, icon('vol'));
    this.vol = h('input', { type: 'range', min: '0', max: '1', step: '0.02', 'aria-label': 'Volume', oninput: () => this.setVolume(Number(this.vol.value)) });
    this.time = h('span.time', { text: '0:00 / 0:00' });
    this.chap = h('span.chap');
    this.btnSpeed = h('button.txt', { 'aria-label': 'Playback speed', onclick: (e) => { e.stopPropagation(); this._popup('speed'); } }, '1x');
    this.btnQuality = h('button.txt', { 'aria-label': 'Quality', onclick: (e) => { e.stopPropagation(); this._popup('quality'); } }, 'Auto');
    this.btnAudio = h('button.txt', { 'aria-label': 'Audio language', title: 'Audio language', hidden: true, onclick: (e) => { e.stopPropagation(); this._popup('audio'); } }, 'Audio');
    this.btnFull = h('button.icon-btn', { 'aria-label': 'Full screen (F)', onclick: () => this.fullscreen() }, icon('full'));
    this.btnPip = h('button.icon-btn', { 'aria-label': 'Pop out (P)', title: 'Pop out: keeps playing on top of other windows (P)', hidden: !document.pictureInPictureEnabled, onclick: () => this.pip() }, icon('pip'));
    this.controls = h('div.controls', { onclick: (e) => e.stopPropagation(), ondblclick: (e) => e.stopPropagation() },
      this.scrub,
      h('div.ctl-row', this.btnPlay, this.btnMute, this.vol, this.time, this.chap, h('span.spacer'), this.btnAudio, this.btnSpeed, this.btnQuality, this.btnPip, this.btnFull));
  }

  _wire() {
    const v = this.v;
    v.addEventListener('click', () => this.toggle());
    v.addEventListener('dblclick', () => this.fullscreen());
    v.addEventListener('enterpictureinpicture', () => {
      this.el.classList.add('popped');
      document.body.classList.remove('lights-down');
    });
    v.addEventListener('leavepictureinpicture', () => {
      this.el.classList.remove('popped');
      autoPipped = false;
      // A video that kept playing in the pop-out after you left its page ends here.
      if (floatingPlayer === this) {
        floatingPlayer = null;
        this.destroy();
      }
    });
    v.addEventListener('play', () => {
      this._wake && this._wake();
      this.el.classList.add('started', 'playing');
      this.poster.remove();
      this.btnPlay.replaceChildren(icon('pause'));
      if (this.a) this.a.play().catch(() => {});
      navigator.mediaSession.playbackState = 'playing';
    });
    v.addEventListener('pause', () => {
      this.el.classList.remove('playing');
      this.btnPlay.replaceChildren(icon('play'));
      if (this._resumeOnAudio) return; // paused only to let the sound catch up
      if (this.a) this.a.pause();
      document.body.classList.remove('lights-down');
      navigator.mediaSession.playbackState = 'paused';
      this._save(true);
    });
    v.addEventListener('seeking', () => { if (this.a && Math.abs(this.a.currentTime - v.currentTime) > 0.05) this.a.currentTime = v.currentTime; });
    v.addEventListener('ratechange', () => { if (this.a) this.a.playbackRate = v.playbackRate; this.btnSpeed.textContent = v.playbackRate + 'x'; });
    v.addEventListener('waiting', () => { this.el.classList.add('loading'); if (this.a) this.a.pause(); this._noteStall(); });
    v.addEventListener('seeking', () => { this._seekAt = Date.now(); });
    v.addEventListener('playing', () => {
      this.el.classList.remove('loading');
      if (!this.a) return;
      if (Math.abs(this.a.currentTime - v.currentTime) > 0.3) this.a.currentTime = v.currentTime;
      this.a.play().catch(() => {});
    });
    v.addEventListener('canplay', () => this.el.classList.remove('loading'));
    v.addEventListener('timeupdate', () => this._tick());
    v.addEventListener('progress', () => this._paintBuffer());
    v.addEventListener('ended', () => { this._save(true); if (this.a) this.a.pause(); this.onEnded && this.onEnded(); });
    v.addEventListener('error', () => this._onError('video'));

    // scrubbing
    const pos = (e) => {
      const r = this.scrub.getBoundingClientRect();
      return Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    };
    this.scrub.addEventListener('pointermove', (e) => {
      const p = pos(e);
      const t = p * this.duration();
      const c = this._chapterAt(t);
      this.tip.textContent = fmtTime(t) + (c ? `  ${c.title}` : '');
      this.tip.style.left = p * 100 + '%';
      if (this.scrub.classList.contains('drag')) this._showAt(p);
    });
    this.scrub.addEventListener('pointerdown', (e) => {
      this.scrub.setPointerCapture(e.pointerId);
      this.scrub.classList.add('drag');
      this._showAt(pos(e));
    });
    this.scrub.addEventListener('pointerup', (e) => {
      this.scrub.classList.remove('drag');
      this.seek(pos(e) * this.duration());
    });

    // auto-hide controls & lights down
    let idleTimer;
    const wake = () => {
      this.el.classList.remove('idle');
      document.body.classList.remove('lights-down');
      clearTimeout(idleTimer);
      idleTimer = setTimeout(() => {
        if (!this.v.paused) {
          this.el.classList.add('idle');
          // Dim the room only for the video on screen, not one playing in the pop-out.
          if (currentPlayer === this && document.pictureInPictureElement !== this.v) document.body.classList.add('lights-down');
        }
      }, 2600);
    };
    this._wake = wake;
    document.addEventListener('mousemove', this._docMove = wake);
    document.addEventListener('fullscreenchange', this._fs = () => this.btnFull.replaceChildren(icon(document.fullscreenElement ? 'unfull' : 'full')));
    document.addEventListener('click', this._closePop = () => this._popup(null));

    this.autoTimer = setInterval(() => this._autoTick(), 4000);

    // drift correction between picture and sound
    this.syncTimer = setInterval(() => {
      if (this._resumeOnAudio) this._resumeFromStall();
      if (!this.a || this.v.paused || this.v.seeking) return;
      const d = this.a.currentTime - this.v.currentTime;
      if (Math.abs(d) > 0.3) this.a.currentTime = this.v.currentTime;
      else this.a.playbackRate = this.v.playbackRate * (Math.abs(d) > 0.04 ? 1 - Math.max(-0.05, Math.min(0.05, d)) : 1);
    }, 250);
  }

  _attachAudio(src) {
    if (this.a) { this.a.pause(); this.a.removeAttribute('src'); this.a.load(); }
    this.a = null;
    if (!src) { this.v.muted = this.muted; this._applyVolume(); return; }
    const a = h('audio', { preload: 'auto' });
    a.src = src;
    // If the sound runs out of buffer, hold the picture until the sound is ready again.
    a.addEventListener('waiting', () => {
      if (!this.v.paused) {
        this._resumeOnAudio = true;
        this.v.pause();
        this.el.classList.add('loading');
      }
    });
    const resume = () => this._resumeFromStall();
    a.addEventListener('canplay', resume);
    a.addEventListener('canplaythrough', resume);
    a.addEventListener('seeked', resume);
    a.addEventListener('error', () => this._onError('audio'));
    this.a = a;
    this.v.muted = true;
    this._applyVolume();
  }

  _resumeFromStall() {
    if (!this._resumeOnAudio || !this.a || this.a.readyState < 3) return;
    this._resumeOnAudio = false;
    this.el.classList.remove('loading');
    if (Math.abs(this.a.currentTime - this.v.currentTime) > 0.3) this.a.currentTime = this.v.currentTime;
    this.v.play().catch(() => {});
  }

  load(s, startAt = 0) {
    this.streams = s;
    this.chapters = s.chapters || [];
    this.qualities = s.qualities || [];
    this.height = s.height;
    this.marks.replaceChildren(...this.chapters.filter((c) => c.start > 0).map((c) => h('div.mark', { style: { left: (c.start / (s.duration || this.meta.duration || 1)) * 100 + '%' } })));
    this.auto = !!s.auto;
    this.bitrates = s.bitrates || {};
    this.cap = s.cap || 1080;
    this._switchedAt = Date.now();
    this._paintQuality();
    this.btnQuality.hidden = s.offline || this.qualities.length < 2;
    this.audioTracks = s.audioTracks || [];
    this.audioLang = s.audioLang;
    this._paintAudioBtn();
    if (s.poster) this.poster.src = s.poster;
    this.setVolume(state.settings.volume ?? 0.9, false);
    this.v.playbackRate = state.settings.speed || 1;
    this._whenAvailable(s, () => this._setSources(s.video, s.audio, startAt));
  }

  // YouTube holds new streams back for as long as its pre-roll ad would run (videos
  // with ads only). FreeReel shows no ad: it waits the same time, then starts.
  _whenAvailable(s, go) {
    clearInterval(this._waitTimer);
    const left = () => Math.ceil(((s.availableAt || 0) - Date.now()) / 1000);
    if (left() <= 0) {
      this.waitNote.textContent = '';
      return go();
    }
    this.el.classList.add('loading');
    const paint = () => {
      const n = left();
      if (this.destroyed) return clearInterval(this._waitTimer);
      if (n > 0) {
        this.waitNote.textContent = `YouTube makes this video wait ${n}s before it can start`;
        return;
      }
      clearInterval(this._waitTimer);
      this.waitNote.textContent = '';
      go();
    };
    paint();
    this._waitTimer = setInterval(paint, 250);
  }

  _setSources(video, audio, startAt, autoplay = true) {
    this._startAt = startAt;
    this.el.classList.add('loading');
    this._attachAudio(audio);
    this.v.src = video;
    const go = () => {
      if (startAt > 0) this.v.currentTime = startAt;
      if (this.a) this.a.currentTime = startAt;
      if (autoplay) this.play();
    };
    this.v.addEventListener('loadedmetadata', go, { once: true });
  }

  play() {
    const p = this.v.play();
    if (p) p.catch((e) => { if (e.name !== 'AbortError') this.el.classList.remove('loading'); });
    this._wake && this._wake();
  }
  toggle() {
    if (this._resumeOnAudio) { this._resumeOnAudio = false; this.el.classList.remove('loading'); if (this.a) this.a.pause(); return; }
    this.v.paused ? this.play() : this.v.pause();
  }
  seek(t) {
    this.v.currentTime = Math.max(0, Math.min(this.duration() - 0.2, t));
    this._tick();
  }
  duration() {
    return isFinite(this.v.duration) && this.v.duration > 0 ? this.v.duration : this.streams?.duration || this.meta.duration || 0;
  }
  _applyVolume() {
    const target = this.a || this.v;
    target.volume = this.volume ?? 0.9;
    target.muted = !!this.muted;
    if (this.a) this.v.muted = true;
  }
  setVolume(x, save = true) {
    this.volume = Math.max(0, Math.min(1, x));
    this.muted = this.volume === 0;
    this.vol.value = this.volume;
    this._applyVolume();
    this.btnMute.replaceChildren(icon(this.muted ? 'mute' : 'vol'));
    if (save) { state.settings.volume = this.volume; R.setSetting('volume', this.volume); }
  }
  setMuted(m) {
    this.muted = m;
    if (!m && !this.volume) this.volume = 0.6;
    this.vol.value = m ? 0 : this.volume;
    this._applyVolume();
    this.btnMute.replaceChildren(icon(m ? 'mute' : 'vol'));
  }
  setSpeed(r) {
    this.v.playbackRate = r;
    state.settings.speed = r;
    R.setSetting('speed', r);
  }
  async pip() {
    try {
      if (document.pictureInPictureElement === this.v) await document.exitPictureInPicture();
      else await this.v.requestPictureInPicture();
    } catch (e) {
      toast('This video can’t pop out yet. Try again once it’s playing.', true);
    }
  }
  fullscreen() {
    if (document.fullscreenElement) document.exitFullscreen();
    else this.el.requestFullscreen().catch(() => {});
  }
  // Keeps buffering mid-video (not just after a seek)? Drop one quality step so it plays smoothly.
  _noteStall() {
    if (!this.streams || this.streams.offline || this.usingFallback || this.v.currentTime < 2) return;
    if (Date.now() - (this._seekAt || 0) < 2500) return;
    const now = Date.now();
    this._stalls = (this._stalls || []).filter((t) => now - t < 45000);
    this._stalls.push(now);
    if (this._stalls.length < (this.auto ? 2 : 3)) return;
    const lower = this.qualities.filter((q) => q < this.height).sort((a, b) => b - a)[0];
    if (!lower || lower < 360) return;
    this._stalls = [];
    const wasAuto = this.auto;
    this.setQuality(lower, { auto: true });
    if (!wasAuto) toast(`Your connection is struggling, so this video switched to Auto quality (${lower}p) to stop buffering.`);
  }
  _paintQuality() {
    const q = this.height ? `${this.height}p` : '';
    this.btnQuality.textContent = this.auto ? `Auto${q ? ' · ' + q : ''}` : q || 'Auto';
  }
  // Seconds of video already downloaded ahead of the playhead.
  _bufferAhead() {
    const v = this.v;
    for (let i = 0; i < v.buffered.length; i++) {
      if (v.buffered.start(i) <= v.currentTime + 0.3 && v.buffered.end(i) >= v.currentTime) {
        const end = v.buffered.end(i);
        return end >= (v.duration || Infinity) - 1 ? Infinity : end - v.currentTime;
      }
    }
    return 0;
  }
  _fits(q, bps) {
    const kb = this.bitrates[q];
    return !kb || kb * 1000 * 1.6 + 160e3 <= bps;
  }
  // Auto quality: every few seconds, step down before it runs dry, or up when there's room.
  async _autoTick() {
    if (!this.auto || !this.streams || this.streams.offline || this.usingFallback || this.v.paused || this.v.seeking || this._busySwitch) return;
    const bps = await api('bandwidth').catch(() => null);
    if (!bps || !this.auto) return;
    const ahead = this._bufferAhead();
    const cur = this.height;
    const kb = this.bitrates[cur];
    if (ahead < 5 && kb && kb * 1000 * 1.1 > bps) {
      const lower = this.qualities.filter((q) => q < cur && this._fits(q, bps)).sort((a, b) => b - a)[0] || this.qualities.filter((q) => q < cur && q >= 360).sort((a, b) => b - a)[0];
      if (lower) return this.setQuality(lower, { auto: true });
    }
    if (Date.now() - this._switchedAt > 30000 && ahead > 25) {
      const up = this.qualities.filter((q) => q > cur && q <= this.cap).sort((a, b) => a - b)[0];
      if (up && this._fits(up, bps)) this.setQuality(up, { auto: true });
    }
  }
  async setQuality(hgt, { auto = false } = {}) {
    this.auto = auto;
    this._switchedAt = Date.now();
    if (hgt === this.height) { this._paintQuality(); return; }
    const t = this.v.currentTime;
    const playing = !this.v.paused;
    this.height = hgt;
    this._paintQuality();
    this._busySwitch = true;
    this.v.addEventListener('canplay', () => { this._busySwitch = false; }, { once: true });
    setTimeout(() => { this._busySwitch = false; }, 10000);
    this._setSources(`${this.streams.video.replace(/\?h=\d+/, '')}?h=${hgt}`, this.streams.audio, t, playing);
  }
  _paintAudioBtn() {
    const t = this.audioTracks.find((x) => x.lang === this.audioLang);
    this.btnAudio.hidden = this.usingFallback || this.audioTracks.length < 2;
    this.btnAudio.textContent = t ? (t.lang.split('-')[0] || 'Audio').toUpperCase() : 'Audio';
  }
  setAudioLang(lang) {
    if (!this.streams.audio || lang === this.audioLang) return;
    this.audioLang = lang;
    this.streams.audio = this.streams.audio.replace(/([?&]lang=)[^&]*/, `$1${encodeURIComponent(lang)}`);
    const t = this.v.currentTime;
    const playing = !this.v.paused;
    this._attachAudio(this.streams.audio);
    this.a.addEventListener('loadedmetadata', () => {
      this.a.currentTime = t;
      if (playing) this.a.play().catch(() => {});
    }, { once: true });
    this._paintAudioBtn();
    const tr = this.audioTracks.find((x) => x.lang === lang);
    toast(`Audio: ${tr ? tr.label : lang}${tr && tr.original ? ' (original)' : ''}`);
  }
  _popup(kind) {
    this.el.querySelector('.popup')?.remove();
    if (!kind || this._openPop === kind) { this._openPop = null; return; }
    this._openPop = kind;
    const items = kind === 'audio'
      ? this.audioTracks.map((t) => h(`button${t.lang === this.audioLang ? '.sel' : ''}`, { onclick: () => { this.setAudioLang(t.lang); this._popup(null); } }, h('span', { text: t.label }), t.original ? h('span.tag', { text: 'Original' }) : null))
      : kind === 'speed'
      ? [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map((r) => h(`button${r === this.v.playbackRate ? '.sel' : ''}`, { onclick: () => { this.setSpeed(r); this._popup(null); } }, r === 1 ? 'Normal' : r + 'x'))
      : [h(`button${this.auto ? '.sel' : ''}`, { onclick: () => { this._popup(null); this.auto = true; this._switchedAt = 0; this._paintQuality(); this._autoTick(); toast('Auto quality: picks the best your connection can play smoothly'); } }, h('span', { text: 'Auto' }), h('span.tag', { text: this.auto && this.height ? `${this.height}p` : '' })),
        ...this.qualities.map((q) => h(`button${!this.auto && q === this.height ? '.sel' : ''}`, { onclick: () => { this.setQuality(q); this._popup(null); } }, h('span', { text: `${q}p` }), h('span.tag', { text: q >= 2160 ? '4K' : q >= 1440 ? 'QHD' : q >= 720 ? 'HD' : '' })))];
    this.el.append(h('div.popup', { onclick: (e) => e.stopPropagation() }, h('h4', { text: kind === 'speed' ? 'Speed' : kind === 'audio' ? 'Audio language' : 'Quality' }), items));
  }
  // A stream failed. Before showing an error, work down a ladder: fresh links, a lower
  // quality, then the combined picture-and-sound stream. Each step is written to the log.
  _onError(which) {
    if (this.destroyed || !this.v.getAttribute('src') || this._recovering) return;
    const el = which === 'audio' ? this.a : this.v;
    const err = el && el.error;
    const why = err ? `code ${err.code}${err.message ? `: ${err.message}` : ''}` : 'unknown';
    console.warn(`player: ${which} stream failed (${why}) at ${Math.round(this.v.currentTime)}s, ${this.usingFallback ? 'combined' : `${this.height}p`}, step ${this.recoverStep}`);
    this._recover(which, why);
  }
  async _recover(which, why) {
    const t = this.v.currentTime || this._startAt || 0;
    const step = this.recoverStep++;
    const lower = this.qualities.filter((q) => q < (this.height || 1080)).sort((a, b) => b - a);
    const plan = [];
    if (this.refetch && !this.streams.offline) {
      plan.push({ fresh: true, height: this.auto ? null : this.height }); // fresh links, same quality
      if (lower.length) plan.push({ fresh: true, height: lower.find((q) => q <= 720) || lower[0] }); // a lower, more common quality
    }
    const s = plan[step];
    if (s) {
      this._recovering = true;
      this.el.classList.add('loading');
      try {
        const next = await this.refetch(s.height, `${which}: ${why}`);
        if (this.destroyed) return;
        this.usingFallback = false;
        this.streams = next;
        this.height = next.height;
        this.qualities = next.qualities || this.qualities;
        this.auto = s.height == null ? !!next.auto : false;
        this.audioTracks = next.audioTracks || [];
        this.audioLang = next.audioLang;
        this.btnQuality.hidden = this.qualities.length < 2;
        this._paintQuality();
        this._paintAudioBtn();
        this._whenAvailable(next, () => this._setSources(next.video, next.audio, t));
      } catch (e) {
        if (this.destroyed) return;
        this.showMessage(e.message, () => this.retryFromStart());
      } finally {
        this._recovering = false;
      }
      return;
    }
    if (!this.usingFallback && this.streams && this.streams.fallback) {
      this.usingFallback = true;
      console.warn('player: switching to the combined stream');
      this.btnQuality.hidden = true;
      this.audioTracks = [];
      this._paintAudioBtn();
      this._setSources(this.streams.fallback, null, t);
      return;
    }
    this.showMessage(which === 'audio' ? 'The sound for this video didn’t load.' : 'This video didn’t load.', () => this.retryFromStart());
  }
  retryFromStart() {
    if (!this.refetch) return location.reload();
    this.recoverStep = 0;
    this.center.replaceChildren(...this._centerKids);
    this._recover('video', 'tried again');
  }
  showMessage(text, retry) {
    this.el.classList.remove('loading');
    this.center.replaceChildren(h('div.msg', h('p', { text }), retry ? h('button.pill.primary', { text: 'Try again', onclick: retry }) : null));
  }
  _chapterAt(t) {
    let c = null;
    for (const ch of this.chapters) if (ch.start <= t) c = ch;
    return c;
  }
  _showAt(p) {
    this.done.style.width = p * 100 + '%';
    this.knob.style.left = p * 100 + '%';
  }
  _paintBuffer() {
    const b = this.v.buffered;
    const d = this.duration();
    if (!b.length || !d) return;
    let end = 0;
    for (let i = 0; i < b.length; i++) if (b.start(i) <= this.v.currentTime + 1) end = Math.max(end, b.end(i));
    this.buf.style.width = (end / d) * 100 + '%';
  }
  _tick() {
    const d = this.duration();
    const t = this.v.currentTime;
    if (!this.scrub.classList.contains('drag')) this._showAt(d ? t / d : 0);
    this.time.textContent = `${fmtTime(t)} / ${fmtTime(d)}`;
    const c = this._chapterAt(t);
    const label = c ? c.title : '';
    if (this.chap.textContent !== label) {
      this.chap.textContent = label;
      document.querySelectorAll('.chapter').forEach((el) => el.classList.toggle('current', Number(el.dataset.t) === (c && c.start)));
    }
    this._paintBuffer();
    if (Date.now() - this.lastSave > 10000) this._save();
    if (d && 'setPositionState' in navigator.mediaSession) {
      try { navigator.mediaSession.setPositionState({ duration: d, position: Math.min(t, d), playbackRate: this.v.playbackRate }); } catch {}
    }
  }
  _save(force) {
    if (!this.el.classList.contains('started')) return;
    this.lastSave = Date.now();
    this.onProgress && this.onProgress(this.v.currentTime, this.duration(), force);
  }
  key(e) {
    const k = e.key.toLowerCase();
    const map = {
      ' ': () => this.toggle(), k: () => this.toggle(),
      j: () => this.seek(this.v.currentTime - 10), l: () => this.seek(this.v.currentTime + 10),
      arrowleft: () => this.seek(this.v.currentTime - 5), arrowright: () => this.seek(this.v.currentTime + 5),
      arrowup: () => this.setVolume((this.volume || 0) + 0.05), arrowdown: () => this.setVolume((this.volume || 0) - 0.05),
      f: () => this.fullscreen(), m: () => this.setMuted(!this.muted), p: () => this.pip(),
      home: () => this.seek(0), end: () => this.seek(this.duration()),
    };
    if (/^[0-9]$/.test(k)) map[k] = () => this.seek((Number(k) / 10) * this.duration());
    if (e.key === '>') map['>'] = () => this.setSpeed(Math.min(2, this.v.playbackRate + 0.25));
    if (e.key === '<') map['<'] = () => this.setSpeed(Math.max(0.25, this.v.playbackRate - 0.25));
    const fn = map[k] || map[e.key];
    if (fn) {
      e.preventDefault();
      fn();
      this._wake && this._wake();
    }
  }
  destroy() {
    this.destroyed = true;
    clearInterval(this._waitTimer);
    this._save(true);
    clearInterval(this.syncTimer);
    clearInterval(this.autoTimer);
    document.removeEventListener('mousemove', this._docMove);
    document.removeEventListener('fullscreenchange', this._fs);
    document.removeEventListener('click', this._closePop);
    if (document.pictureInPictureElement === this.v) document.exitPictureInPicture().catch(() => {});
    for (const m of [this.v, this.a]) if (m) { m.pause(); m.removeAttribute('src'); m.load(); }
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    document.body.classList.remove('lights-down');
  }
}

// ── watch page ─────────────────────────────────────────────────────────────────
function paintDownloadButton(b, it) {
  b.replaceChildren();
  b.className = 'pill dl-progress';
  if (!it) b.append(icon('down'), 'Download');
  else if (it.status === 'done') { b.classList.add('on'); b.append(icon('check'), 'Downloaded'); }
  else if (it.status === 'error') b.append(icon('refresh'), 'Retry download');
  else {
    b.append(h('span.fill', { style: { width: Math.round((it.progress || 0) * 100) + '%' } }), icon('down'), it.status === 'queued' ? 'Waiting…' : `Downloading ${Math.round((it.progress || 0) * 100)}%`);
  }
}
function linkify(text, onTime) {
  // Turn timestamps like 12:34 into links that seek; everything else stays plain text.
  const frag = document.createDocumentFragment();
  let last = 0;
  for (const m of text.matchAll(/(?<![\d:])(\d{1,2}:)?\d{1,2}:\d{2}(?![\d:])/g)) {
    frag.append(text.slice(last, m.index));
    const parts = m[0].split(':').map(Number);
    const secs = parts.reduce((a, b) => a * 60 + b, 0);
    frag.append(h('a.ts', { text: m[0], onclick: () => onTime(secs) }));
    last = m.index + m[0].length;
  }
  frag.append(text.slice(last));
  return frag;
}

// Ambient glow: a tiny, heavily blurred copy of the picture spills light behind the
// player. Two canvases crossfade so the colour drifts smoothly instead of jumping.
function ambientGlow(stage, posterUrl) {
  const W = 32, H = 18;
  const a = h('canvas.amb', { width: W, height: H, 'aria-hidden': 'true' });
  const b = h('canvas.amb', { width: W, height: H, 'aria-hidden': 'true' });
  stage.prepend(a, b);
  let front = a, back = b, timer = null, video = null;
  const draw = (src) => {
    try {
      const ctx = back.getContext('2d');
      ctx.drawImage(src, 0, 0, W, H);
      back.classList.add('on');
      front.classList.remove('on');
      [front, back] = [back, front];
    } catch {
      /* a picture that can't be drawn just keeps the last glow */
    }
  };
  const poster = new Image();
  poster.onload = () => draw(poster);
  poster.src = posterUrl;
  const tick = () => {
    if (!stage.isConnected) { clearInterval(timer); return; }
    if (video && video.readyState >= 2 && !video.paused && !document.hidden) draw(video);
  };
  return {
    follow(v) {
      video = v;
      clearInterval(timer);
      timer = setInterval(tick, 1100);
      v.addEventListener('seeked', () => { if (v.readyState >= 2) draw(v); });
    },
  };
}

async function viewWatch(id, live) {
  const known = { id };
  // The thumbnail you clicked grows into this box, then the real player takes its place.
  const posterUrl = thumbFor({ id, thumb: `https://i.ytimg.com/vi/${id}/hqdefault.jpg` });
  const playerHost = h('div.player.loading', { 'data-morph': '' },
    h('img.poster', { src: posterUrl, alt: '' }),
    h('div.center', h('div.spinner')));
  const stage = h('div.stage', playerHost);
  const mainCol = h('div.watch-main', stage, h('div.sk', { style: 'height:26px;width:70%;margin-top:18px' }), h('div.sk', { style: 'height:42px;width:40%;margin-top:14px' }));
  const sideCol = h('aside.side-next');
  const page = h('div.watch', mainCol, sideCol);
  swapMain(page);
  const glow = ambientGlow(stage, posterUrl);

  let w;
  try {
    w = await api('watch', id);
  } catch (e) {
    if (!live()) return;
    errorView('This video didn’t load', e, route);
    return;
  }
  if (!live()) return;
  const video = { id, title: w.title, channel: w.channel, channelId: w.channelId, thumb: `https://i.ytimg.com/vi/${id}/mqdefault.jpg` };
  Object.assign(known, video);
  document.title = `${w.title} – FreeReel`;
  if (w.inLater) state.later.add(id);

  const showSide = state.settings.showSuggestions && w.related.length;
  page.classList.toggle('no-side', !showSide);
  if (showSide) {
    sideCol.replaceChildren(h('h3', { text: 'Up next' }), ...w.related.slice(0, 20).map((v) =>
      h('a.mini', { href: `#watch/${v.id}`, oncontextmenu: (e) => { e.preventDefault(); videoMenu(v, e); } },
        thumbBox(v), h('div', h('div.t', { text: v.title }), h('div.s', { text: v.channel }), h('div.s', { text: meta(v) })))));
  }

  const player = new Player({
    video: known,
    refetch: (height, why) => api('streams', id, height == null ? state.settings.quality || 'auto' : height, undefined, screenCap(), why || true),
    onEnded: () => onEnded(),
    onProgress: (pos, dur) => {
      R.recordWatch(video, pos, dur);
      state.hist.set(id, { ...video, position: pos, duration: dur, watchedAt: Date.now() });
    },
  });
  currentPlayer = player;
  player.el.dataset.morph = ''; // in case the page appears after the player is ready
  playerHost.replaceWith(player.el);
  glow.follow(player.v);

  const dlBtn = h('button.pill', { dataset: { dlbtn: id }, onclick: (e) => {
    const it = state.lib.get(id);
    if (!it || it.status === 'error') return download(video);
    if (it.status === 'done') return removeDownload(id);
    openMenu(e.clientX, e.clientY, [{ label: 'Cancel download', run: () => api('cancelDownload', id) }]);
  } });
  paintDownloadButton(dlBtn, state.lib.get(id));
  const laterBtn = h(`button.pill${state.later.has(id) ? '.on' : ''}`, { dataset: { later: id }, onclick: () => toggleLater(video) }, icon('clock'), 'Watch later');
  const descBox = h('div.desc.collapsed', h('div.meta', { text: '' }), h('div.body', { text: 'Loading details…' }));
  const chaptersBox = h('div');
  const resume = h('div');
  mainCol.replaceChildren(
    stage,
    h('h1', { text: w.title }),
    h('div.watch-bar',
      h('a.who', { href: w.channelId ? `#channel/${w.channelId}` : '#' },
        w.avatar ? h('img.fade', { src: img(w.avatar), alt: '', onload: (e) => e.target.classList.add('ready') }) : h('div.ph'),
        h('div', { style: 'min-width:0' }, h('b', { text: w.channel }), h('small', { text: w.subscribers }))),
      w.channelId ? subscribeButton({ id: w.channelId, name: w.channel, avatar: w.avatar }, w.subscribed) : null,
      h('span.grow'),
      laterBtn, dlBtn),
    resume,
    descBox,
    chaptersBox);

  // Streams take a few seconds (the engine works out YouTube's protections).
  let s;
  try {
    s = await api('streams', id, state.settings.quality || 'auto', undefined, screenCap());
  } catch (e) {
    if (!live()) return;
    player.showMessage(e.message, route);
    descBox.remove();
    return;
  }
  if (!live()) return;
  const p = w.progress;
  const dur = s.duration || 0;
  let startAt = 0;
  if (p && p.position > 10 && dur && p.position < dur - Math.min(20, dur * 0.08)) {
    startAt = p.position;
    resume.replaceChildren(h('div.resume-chip', `Resumed from ${fmtTime(startAt)}.`, h('button', { text: 'Start over', onclick: () => { player.seek(0); resume.replaceChildren(); } })));
  }
  player.load(s, startAt);
  const bits = [s.views != null ? `${fmtNum(s.views)} views` : null, uploadDate(s.uploadDate), s.offline ? 'Playing from your downloads' : null].filter(Boolean);
  descBox.replaceChildren(h('div.meta', { text: bits.join(', ') }), h('div.body', linkify(s.description || 'No description.', (t) => { player.seek(t); player.play(); main.scrollTo({ top: 0, behavior: 'smooth' }); })));
  if ((s.description || '').length > 180 || (s.description || '').split('\n').length > 3) {
    const body = descBox.querySelector('.body');
    const setOpen = (open) => {
      // Animate the height: measure where it is and where it's going, then let CSS ease between.
      const from = body.getBoundingClientRect().height;
      descBox.classList.toggle('collapsed', !open);
      body.style.maxHeight = open ? 'none' : '';
      const to = body.getBoundingClientRect().height;
      body.style.maxHeight = from + 'px';
      void body.offsetHeight;
      body.style.maxHeight = to + 'px';
      clearTimeout(body._t);
      body._t = setTimeout(() => { body.style.maxHeight = open ? 'none' : ''; }, 460);
      t.textContent = open ? 'Show less' : '…more';
    };
    const t = h('button.toggle', { text: '…more', onclick: (e) => { e.stopPropagation(); setOpen(descBox.classList.contains('collapsed')); } });
    descBox.addEventListener('click', (e) => { if (descBox.classList.contains('collapsed') && !e.target.closest('a')) setOpen(true); });
    descBox.append(t);
  } else descBox.classList.remove('collapsed');
  if (s.chapters.length > 1) {
    chaptersBox.replaceChildren(h('h2', { text: 'Chapters', style: 'margin:26px 0 10px' }), h('div.chapters', s.chapters.map((c) =>
      h('button.chapter', { dataset: { t: c.start }, onclick: () => { player.seek(c.start); player.play(); } }, h('time', { text: fmtTime(c.start) }), h('span', { text: c.title })))));
  }
  navigator.mediaSession.metadata = new MediaMetadata({ title: w.title, artist: w.channel, artwork: [{ src: s.offline ? s.poster : img(`https://i.ytimg.com/vi/${id}/hqdefault.jpg`), sizes: '480x360', type: 'image/jpeg' }] });
  navigator.mediaSession.setActionHandler('play', () => player.play());
  navigator.mediaSession.setActionHandler('pause', () => player.v.pause());
  navigator.mediaSession.setActionHandler('seekto', (d) => player.seek(d.seekTime));
  navigator.mediaSession.setActionHandler('nexttrack', w.related[0] ? () => go(`watch/${w.related[0].id}`) : null);
  // Get the up-next video ready in the background once this one is well under way.
  const upNext = w.related.find((v) => !state.hist.has(v.id)) || w.related[0];
  if (upNext && !s.offline) setTimeout(() => { if (currentPlayer === player && !player.v.paused) R.prefetch(upNext.id).catch(() => {}); }, 20000);

  // When it ends: nothing plays by itself unless you turned Autoplay on.
  function onEnded() {
    document.body.classList.remove('lights-down');
    const next = w.related.find((v) => !state.hist.has(v.id)) || w.related[0];
    const box = h('div.box');
    const card = h('div.endcard', box);
    const replay = h('button.pill', { onclick: () => { card.remove(); player.seek(0); player.play(); } }, icon('replay'), 'Watch again');
    if (next && state.settings.autoplay) {
      let n = 8;
      const label = h('p', { text: `Up next in ${n}s: ${next.title}` });
      const timer = setInterval(() => {
        n--;
        label.textContent = `Up next in ${n}s: ${next.title}`;
        if (n <= 0) { clearInterval(timer); go(`watch/${next.id}`); }
      }, 1000);
      box.append(label, h('div.btns', h('button.pill', { text: 'Cancel', onclick: () => { clearInterval(timer); card.remove(); } }), h('a.pill.primary', { href: `#watch/${next.id}` }, 'Play now')));
    } else {
      box.append(h('p', { text: 'That’s the end of the video.' }), h('div.btns', replay, next && state.settings.showSuggestions ? h('a.pill.primary', { href: `#watch/${next.id}`, title: next.title }, 'Next video') : null));
    }
    player.el.append(card);
  }
}

// ── settings ───────────────────────────────────────────────────────────────────
function toggleRow(key, title, desc) {
  const input = h('input', { type: 'checkbox', role: 'switch', 'aria-label': title, onchange: async () => {
    state.settings[key] = input.checked;
    await R.setSetting(key, input.checked);
    toast('Saved');
  } });
  input.checked = !!state.settings[key];
  return h('label.toggle-row', h('div', h('b', { text: title }), h('small', { text: desc })), h('span.switch', input, h('span')));
}
async function viewSettings() {
  const [version, bytes] = await Promise.all([api('version').catch(() => ''), api('libraryBytes').catch(() => 0)]);
  const quality = h('select', { 'aria-label': 'Video quality', onchange: async () => {
    const val = quality.value === 'auto' ? 'auto' : Number(quality.value);
    state.settings.quality = val;
    await R.setSetting('quality', val);
    toast('Saved');
  } }, h('option', { value: 'auto', text: 'Auto (recommended)' }), [480, 720, 1080, 1440, 2160].map((q) => h('option', { value: String(q), text: `${q}p${q === 1080 ? ' (Full HD)' : q === 2160 ? ' (4K)' : ''}` })));
  quality.value = String(state.settings.quality || 'auto');
  const audioLang = h('select', { 'aria-label': 'Audio language', onchange: async () => {
    state.settings.audioLang = audioLang.value;
    await R.setSetting('audioLang', audioLang.value);
    toast('Saved');
  } }, [['original', 'Original audio'], ['en', 'English'], ['es', 'Spanish'], ['fr', 'French'], ['de', 'German'], ['it', 'Italian'], ['pt', 'Portuguese'], ['ru', 'Russian'], ['ja', 'Japanese'], ['ko', 'Korean'], ['hi', 'Hindi'], ['id', 'Indonesian'], ['ar', 'Arabic'], ['zh', 'Chinese']].map(([v, t]) => h('option', { value: v, text: t })));
  audioLang.value = state.settings.audioLang || 'en';
  const dlQuality = h('select', { 'aria-label': 'Download quality', onchange: async () => {
    state.settings.downloadQuality = Number(dlQuality.value);
    await R.setSetting('downloadQuality', Number(dlQuality.value));
    toast('Saved. New downloads will use this quality.');
  } }, [[360, '360p (smallest)'], [480, '480p'], [720, '720p (recommended)'], [1080, '1080p (Full HD)'], [1440, '1440p'], [2160, '2160p (4K)']].map(([q, t]) => h('option', { value: String(q), text: t })));
  dlQuality.value = String(state.settings.downloadQuality || 720);
  const upd = h('button.pill', { text: 'Update playback engine', onclick: async () => {
    upd.disabled = true;
    upd.textContent = 'Checking…';
    try {
      const out = await api('engineUpdate');
      toast(/up to date/i.test(out || '') ? 'Already up to date' : 'Playback engine updated');
    } catch (e) {
      toast(e.message, true);
    }
    upd.disabled = false;
    upd.textContent = 'Update playback engine';
  } });
  setView(
    h('h1', { text: 'Settings' }),
    h('div.settings',
      h('section', h('h2', { text: 'Watching' }),
        h('div.toggle-row', h('div', h('b', { text: 'Streaming quality' }), h('small', { text: 'When watching online. Auto picks the best your connection can play without buffering, up to your screen’s resolution.' })), quality),
        h('div.toggle-row', h('div', h('b', { text: 'Audio language' }), h('small', { text: 'Many videos now have AI-dubbed audio. FreeReel plays this language when a video has it, otherwise the original. Change it per video with the language button on the player.' })), audioLang),
        toggleRow('autoplay', 'Autoplay the next video', 'Off by default, so a video ends when it ends.'),
        toggleRow('autoPip', 'Pop out video when you minimize FreeReel', 'The video keeps playing in a small window on top of your other apps, and pops back in when you return.'),
        toggleRow('showSuggestions', 'Show suggestions next to videos', 'Turn off for a distraction-free page with just the video.'),
        toggleRow('hideShorts', 'Hide Shorts', 'Keeps Shorts out of your feeds and suggestions.')),
      h('section', h('h2', { text: 'Your channels' }),
        h('p', { text: 'Import your subscriptions from YouTube once. Afterwards they live only on this PC, and YouTube never learns who you follow.' }),
        h('ol',
          h('li', {}, 'Go to takeout.google.com, click “Deselect all”, then tick “YouTube and YouTube Music”.'),
          h('li', {}, 'Under “All YouTube data included”, keep only “subscriptions”. Export and download.'),
          h('li', {}, 'Unzip it and choose subscriptions.csv below.')),
        h('div.btns', h('button.pill.primary', { text: 'Choose subscriptions.csv', onclick: importSubs }), h('a.pill', { href: '#subscriptions/manage', text: 'Manage channels' }))),
      h('section', h('h2', { text: 'History' }),
        toggleRow('pauseHistory', 'Pause watch history', 'Videos you watch won’t be remembered. For you stops learning while this is on.'),
        h('div.btns', h('a.pill', { href: '#history', text: 'View history' }))),
      h('section', h('h2', { text: 'Downloads' }),
        h('div.toggle-row', h('div', h('b', { text: 'Download quality' }), h('small', { text: 'Separate from streaming. 720p looks nearly the same on most screens at about a third the size of 1080p.' })), dlQuality),
        toggleRow('smallerDownloads', 'Smaller downloads', state.settings.av1Smooth
          ? 'Saves in newer video formats (AV1, which this PC plays smoothly) that look the same at about 30–50% smaller.'
          : 'Saves in a newer video format (VP9) that looks the same at about 30% smaller.'),
        h('p', { text: `${fmtBytes(bytes)} of videos saved on this PC.` }),
        h('div.btns', h('button.pill', { text: 'Open downloads folder', onclick: () => api('openLibraryFolder') }))),
      h('section', h('h2', { text: 'Privacy' }),
        h('ul',
          h('li', { text: 'No Google account, no cookies, no ads and no analytics. FreeReel has no server of its own.' }),
          h('li', { text: 'The window can only talk to FreeReel itself. YouTube’s website code, trackers and ad scripts never run.' }),
          h('li', { text: 'Video and thumbnail requests come from FreeReel’s engine on this PC, without any identifier that links them to you.' }),
          h('li', { text: 'Subscriptions, history, Watch later and downloads are stored only on this PC.' }),
          h('li', { text: 'YouTube still sees this PC’s internet address when it sends a video. A VPN hides that if you want.' })),
        h('div.btns', upd, h('button.pill', { text: 'Open log folder', onclick: () => api('openLogs') }))),
      botSection(),
      updatesSection(version),
      h('section', h('h2', { text: 'About' }),
        h('p', { text: `FreeReel ${version}. Video extraction by yt-dlp. Free software under the GPL-3.0 license. Not affiliated with YouTube or Google.` }))));
}

// "YouTube bot checks": when YouTube flags an internet connection, it blocks everyone on it
// who isn't signed in (even a normal browser). Signing in with a spare account gets past it.
function botSection() {
  const sec = h('section');
  const paint = (has) => { state.settings.hasCookies = has;
    sec.replaceChildren(
      h('h2', { text: 'YouTube bot checks' }),
      h('p', { text: 'Sometimes YouTube flags an internet connection and says “Sign in to confirm you’re not a bot” to everyone on it who isn’t signed in, even in a normal browser. FreeReel tries other ways in by itself, and the flag usually lifts within a few hours. Switching networks (like a phone hotspot) also gets around it.' }),
      has
        ? h('p', { text: 'Using a cookies file from a spare Google account. YouTube can link the videos you play here to that account (not to your main one).' })
        : h('p', { text: 'If it keeps happening, you can give FreeReel a cookies.txt from a spare Google account (never your main one: YouTube can link what you play to it). In Chrome, install the “Get cookies.txt LOCALLY” extension and allow it in Incognito. In an Incognito window, sign in to the spare account on youtube.com, export cookies.txt with the extension, then close the Incognito window and choose the file here.' }),
      h('div.btns', has
        ? h('button.pill', { text: 'Stop using the cookies file', onclick: async () => { await api('clearCookies'); paint(false); toast('Cookies file removed. FreeReel is back to not using any account.'); } })
        : [h('button.pill', { text: 'Use a cookies.txt file from a spare account…', onclick: async () => {
            try {
              if (await api('chooseCookies')) { paint(true); toast('Cookies file added. Try the video again.'); }
            } catch (e) { toast(e.message, true); }
          } })]));
  };
  paint(!!state.settings.hasCookies);
  return sec;
}

// ── search box & keyboard ──────────────────────────────────────────────────────
$('#search-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const q = $('#search-input').value.trim();
  if (q) {
    const id = parseVideoLink(q);
    go(id ? `watch/${id}` : `search/${encodeURIComponent(q)}`);
  }
});
function parseVideoLink(s) {
  try {
    const u = new URL(s);
    if (u.hostname === 'youtu.be') return u.pathname.slice(1, 12);
    if (/youtube\.com$/.test(u.hostname)) return u.searchParams.get('v') || (/\/(?:shorts|live|embed)\/([\w-]{11})/.exec(u.pathname) || [])[1] || null;
  } catch {}
  return null;
}
document.addEventListener('keydown', (e) => {
  const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName) && document.activeElement.type !== 'range' && document.activeElement.type !== 'checkbox';
  if (e.key === 'Escape') closeMenu();
  if (e.ctrlKey && (e.key.toLowerCase() === 'f' || e.key.toLowerCase() === 'l')) {
    e.preventDefault();
    $('#search-input').focus();
    $('#search-input').select();
    return;
  }
  if (e.altKey && e.key === 'ArrowLeft') return history.back();
  if (e.altKey && e.key === 'ArrowRight') return history.forward();
  if (e.key === '/' && !typing) { e.preventDefault(); $('#search-input').focus(); return; }
  if (typing || e.ctrlKey || e.altKey || e.metaKey) return;
  if (!currentPlayer) return;
  const onControl = /^(BUTTON|A)$/.test(document.activeElement.tagName);
  if (onControl && (e.key === ' ' || e.key === 'Enter')) return; // let the focused button work
  currentPlayer.key(e);
});

// ── engine banner ──────────────────────────────────────────────────────────────
function engineBanner(s) {
  const b = $('#engine-banner');
  if (!s || s.state === 'ready') {
    b.hidden = true;
    document.body.classList.remove('has-banner');
    return;
  }
  b.hidden = false;
  document.body.classList.add('has-banner');
  b.classList.toggle('error', s.state === 'error');
  if (s.state === 'downloading') b.replaceChildren(h('span', { text: 'Setting up the playback engine. This happens once and takes a few seconds.' }), h('progress', { max: '1', value: String(s.progress || 0) }));
  else b.replaceChildren(h('span', { text: `The playback engine didn’t download: ${s.message}.` }), h('button.pill', { text: 'Try again', onclick: () => { engineBanner({ state: 'downloading', progress: 0 }); R.engineEnsure(); } }));
}
R.onEngineStatus(engineBanner);
R.onLibraryChange(updateDownloadUI);
R.onSubsChange(() => loadSubs());

// ── updates ────────────────────────────────────────────────────────────────────
// Save an update file (e.g. "FreeReel-1.2.0.update") into Downloads and this banner appears.
function updateBanner(u) {
  const b = $('#update-banner');
  if (!u) {
    b.hidden = true;
    document.body.classList.remove('has-update');
    return;
  }
  const go = h('button.pill.primary', { text: 'Restart and update', onclick: async () => {
    go.disabled = true;
    go.textContent = 'Installing…';
    try {
      await api('updateApply');
    } catch (e) {
      go.disabled = false;
      go.textContent = 'Restart and update';
      toast(e.message, true);
    }
  } });
  b.replaceChildren(
    h('b', { text: `FreeReel ${u.version} is ready to install.` }),
    h('span.notes', { text: u.notes || `You have ${u.current}.` }),
    go,
    h('button.pill', { text: 'Later', onclick: () => updateBanner(null) }));
  b.hidden = false;
  document.body.classList.add('has-update');
}
function updatesSection(version) {
  const check = h('button.pill', { text: 'Check for updates', onclick: async () => {
    check.disabled = true;
    try {
      const u = await api('updateCheck');
      if (u) updateBanner(u);
      else toast('No newer FreeReel update found in your Downloads folder.');
    } catch (e) {
      toast(e.message, true);
    }
    check.disabled = false;
  } });
  const pick = h('button.pill', { text: 'Install update file…', onclick: async () => {
    try {
      const u = await api('updatePick');
      if (u) updateBanner(u);
    } catch (e) {
      toast(e.message, true);
    }
  } });
  return h('section',
    h('h2', { text: 'Updates' }),
    h('p', { text: `You have version ${version}. To update, save the .update file you’re sent into your Downloads folder. FreeReel notices it and offers to restart. Only signed updates made for FreeReel are accepted.` }),
    h('div.btns', check, pick));
}

R.onUpdate(updateBanner);
R.updateCheck().then((r) => r && r.ok && r.data && updateBanner(r.data));

// AV1 is the smallest format, but only worth it if this PC decodes it in hardware;
// otherwise downloads use VP9, which every PC plays smoothly.
async function detectAv1() {
  try {
    const r = await navigator.mediaCapabilities.decodingInfo({
      type: 'file',
      video: { contentType: 'video/mp4; codecs="av01.0.08M.08"', width: 1920, height: 1080, bitrate: 2000000, framerate: 30 },
    });
    const ok = !!(r.supported && r.smooth && r.powerEfficient);
    if (ok !== !!state.settings.av1Smooth) {
      state.settings.av1Smooth = ok;
      R.setSetting('av1Smooth', ok);
    }
  } catch {
    /* leave as is */
  }
}

// ── start ──────────────────────────────────────────────────────────────────────
(async function boot() {
  try {
    state.base = await api('base');
    state.settings = await api('settings');
  } catch (e) {
    main.replaceChildren(h('div.empty', { style: 'padding:40px' }, h('h2', { text: 'FreeReel didn’t start properly' }), h('p', { text: e.message })));
    return;
  }
  const [lib, later, hist, eng] = await Promise.all([api('library').catch(() => []), api('later').catch(() => []), api('history').catch(() => []), api('engineStatus').catch(() => ({ installed: true }))]);
  lib.forEach((it) => state.lib.set(it.id, it));
  later.forEach((v) => state.later.add(v.id));
  hist.forEach((x) => state.hist.set(x.id, x));
  if (!eng.installed) engineBanner({ state: 'downloading', progress: 0 });
  detectAv1();
  updateDownloadUI({ id: '__init__', removed: true });
  await loadSubs();
  route();
})();
