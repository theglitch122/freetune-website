// Startup loader. Picks which version of the app to run.
//
// Updates are saved next to the installed app as resources/app-<version>.asar instead of
// replacing files that are in use. On every start this loader runs the newest version
// available (installed or updated). If a version fails to start three times in a row it
// is skipped, so a bad update can never leave the app unable to open.

const path = require('path');
const fs = require('fs');
const { app } = require('electron');

function cmp(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}
const readJson = (p) => {
  try {
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch {
    return null;
  }
};

const bundledDir = path.join(__dirname, '..');
const bundled = { version: (readJson(path.join(bundledDir, 'package.json')) || {}).version || '0.0.0', dir: bundledDir };
const res = process.resourcesPath;

let candidates = [bundled];
if (app.isPackaged) {
  try {
    for (const n of fs.readdirSync(res)) {
      const m = /^app-(\d+\.\d+\.\d+)\.asar$/.exec(n);
      if (!m) continue;
      const dir = path.join(res, n);
      if (fs.existsSync(path.join(dir, 'src', 'main', 'main.js'))) candidates.push({ version: m[1], dir });
    }
  } catch {
    /* no updates installed */
  }
}
candidates.sort((a, b) => cmp(b.version, a.version) || (a === bundled ? 1 : -1));

// Skip a version that has failed to start 3 times in a row.
const bootFile = path.join(app.getPath('userData'), 'boot.json');
const boot = readJson(bootFile) || {};
const bad = new Set(boot.bad || []);
let pick = candidates.find((c) => !bad.has(c.version)) || bundled;
if (boot.trying === pick.version && (boot.tries || 0) >= 3 && pick !== bundled) {
  bad.add(pick.version);
  pick = candidates.find((c) => !bad.has(c.version)) || bundled;
}
const tries = boot.trying === pick.version ? (boot.tries || 0) + 1 : 1;
try {
  fs.mkdirSync(path.dirname(bootFile), { recursive: true });
  fs.writeFileSync(bootFile, JSON.stringify({ trying: pick.version, tries, bad: [...bad] }));
} catch {}

global.__APP_VERSION__ = pick.version;
global.__APP_VERSIONS__ = candidates.map((c) => c.version);
// The app calls this once its window has opened successfully.
global.__bootOk = () => {
  try {
    fs.writeFileSync(bootFile, JSON.stringify({ trying: pick.version, tries: 0, ok: pick.version, bad: [...bad] }));
  } catch {}
};

require(path.join(pick.dir, 'src', 'main', 'main.js'));
