// YouTube Music's own catalog, alongside Spotify's: search it, open its artists (with every
// song they have there), albums and playlists. Uses the same public endpoint the YouTube
// Music website uses, without any account or cookies, like the song matching does.
//
// YouTube Music's answers are deeply nested and change shape now and then, so instead of
// following fixed paths this looks through the answer for the building blocks it knows
// (shelves of songs, cards for albums/artists/playlists, page headers) wherever they are.

const { CLIENT, UA } = require('./youtube');

const BASE = 'https://music.youtube.com/youtubei/v1/';
const FILTERS = {
  songs: 'EgWKAQIIAWoKEAkQBRAKEAMQBA==',
  videos: 'EgWKAQIQAWoKEAkQChAFEAMQBA==',
  albums: 'EgWKAQIYAWoKEAkQChAFEAMQBA==',
  artists: 'EgWKAQIgAWoKEAkQChAFEAMQBA==',
  playlists: 'EgeKAQQoAEABagoQCRAKEAUQAxAE', // community playlists
  featured: 'EgeKAQQoADgBagoQCRAKEAUQAxAE', // YouTube Music's own playlists
};
const ID_RE = /^[\w-]{2,80}$/;

async function call(endpoint, body, fetchImpl = fetch) {
  const res = await fetchImpl(`${BASE}${endpoint}?prettyPrint=false`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': UA,
      Origin: 'https://music.youtube.com',
      Referer: 'https://music.youtube.com/',
      'X-YouTube-Client-Name': '67',
      'X-YouTube-Client-Version': CLIENT.clientVersion,
    },
    body: JSON.stringify({ context: { client: CLIENT, user: {} }, ...body }),
  });
  if (!res.ok) throw new Error(`YouTube Music didn’t answer (${res.status})`);
  return res.json();
}

// ── small readers ──────────────────────────────────────────────────────────────
const runsOf = (x) => (x && Array.isArray(x.runs) ? x.runs : []);
const text = (x) => (!x ? '' : x.simpleText || runsOf(x).map((r) => r.text).join(''));
const browseOf = (nav) => (nav && nav.browseEndpoint) || null;
function pageType(nav) {
  const b = browseOf(nav);
  const c = b && b.browseEndpointContextSupportedConfigs;
  return (c && c.browseEndpointContextMusicConfig && c.browseEndpointContextMusicConfig.pageType) || '';
}
function walk(x, fn, depth = 0) {
  if (!x || typeof x !== 'object' || depth > 40) return;
  if (fn(x) === false) return;
  if (Array.isArray(x)) for (const v of x) walk(v, fn, depth + 1);
  else for (const k of Object.keys(x)) walk(x[k], fn, depth + 1);
}
function first(x, key) {
  let found = null;
  walk(x, (o) => {
    if (found) return false;
    if (!Array.isArray(o) && o[key]) {
      found = o[key];
      return false;
    }
    return true;
  });
  return found;
}
// The biggest picture, asked for at a good size.
function thumb(x) {
  const list = first(x, 'thumbnails');
  if (!Array.isArray(list) || !list.length) return null;
  const t = list.reduce((a, b) => ((b.width || 0) >= (a.width || 0) ? b : a));
  let url = t.url || '';
  if (url.startsWith('//')) url = 'https:' + url;
  if (/googleusercontent\.com|ggpht\.com/.test(url)) url = url.replace(/=w\d+-h\d+[^&]*$/, '=w544-h544-l90-rj').replace(/=s\d+[^&]*$/, '=s544');
  return url || null;
}
function parseDuration(s) {
  const m = /^(?:(\d+):)?(\d{1,2}):(\d{2})$/.exec(String(s || '').trim());
  return m ? Number(m[1] || 0) * 3600 + Number(m[2]) * 60 + Number(m[3]) : null;
}
function watchId(x) {
  let id = null;
  walk(x, (o) => {
    if (id) return false;
    if (o.watchEndpoint && o.watchEndpoint.videoId) {
      id = o.watchEndpoint.videoId;
      return false;
    }
    // A "radio" or "shuffle" button belongs to an artist/playlist, not a song.
    if (o.watchPlaylistEndpoint) return false;
    return true;
  });
  return id;
}
const isArtistType = (pt) => pt === 'MUSIC_PAGE_TYPE_ARTIST' || pt === 'MUSIC_PAGE_TYPE_USER_CHANNEL';
const KIND_WORDS = /^(song|video|album|single|ep|artist|playlist|episode|podcast|profile)$/i;

function peopleAndAlbum(runs) {
  const artists = [];
  let album = null;
  let year = '';
  let label = '';
  for (const r of runs) {
    const nav = r.navigationEndpoint;
    const pt = pageType(nav);
    const b = browseOf(nav);
    if (b && isArtistType(pt)) artists.push({ name: r.text, id: b.browseId });
    else if (b && pt === 'MUSIC_PAGE_TYPE_ALBUM') album = { name: r.text, id: b.browseId };
    else if (/^\d{4}$/.test((r.text || '').trim())) year = r.text.trim();
    else if (!label && KIND_WORDS.test((r.text || '').trim())) label = r.text.trim();
  }
  // Artists without a link (common on uploads): the plain words before the first "•".
  if (!artists.length) {
    const plain = runs.map((r) => r.text || '').join('').split(' • ').map((s) => s.trim()).filter((s) => s && !KIND_WORDS.test(s) && !parseDuration(s) && !/^\d{4}$/.test(s) && !/views?$|plays?$|subscribers?$|songs?$|minutes?$/i.test(s));
    if (plain[0]) artists.push({ name: plain[0], id: '' });
  }
  return { artists, album, year, label };
}

// A row: a song, or (in search) an artist, album or playlist.
function parseRow(r) {
  const cols = (r.flexColumns || []).map((f) => f.musicResponsiveListItemFlexColumnRenderer || {});
  const title = text(cols[0] && cols[0].text);
  const sub = cols.slice(1).flatMap((c) => runsOf(c.text));
  const b = browseOf(r.navigationEndpoint);
  const pt = pageType(r.navigationEndpoint);
  const image = thumb(r.thumbnail);
  const { artists, album, year, label } = peopleAndAlbum(sub);
  if (b && isArtistType(pt)) return { kind: 'artist', id: b.browseId, name: title, image };
  if (b && pt === 'MUSIC_PAGE_TYPE_ALBUM') return { kind: 'album', id: b.browseId, name: title, artists, year, albumType: (label || 'Album').toLowerCase(), image };
  if (b && pt === 'MUSIC_PAGE_TYPE_PLAYLIST') return { kind: 'playlist', id: b.browseId.replace(/^VL/, ''), name: title, owner: (artists[0] && artists[0].name) || '', image };
  const videoId = (r.playlistItemData && r.playlistItemData.videoId) || watchId(r.overlay) || watchId(cols[0]);
  if (!videoId || !title) return null;
  let durationSec = null;
  const fixed = (r.fixedColumns || [])[0];
  if (fixed) durationSec = parseDuration(text((fixed.musicResponsiveListItemFixedColumnRenderer || {}).text));
  if (durationSec == null) for (const s of sub.slice().reverse()) if ((durationSec = parseDuration(s.text)) != null) break;
  const explicit = !!first(r.badges, 'musicInlineBadgeRenderer') && /explicit/i.test(JSON.stringify(r.badges || ''));
  return { kind: /video/i.test(label) ? 'video' : 'song', videoId, title, artists, album, durationSec, image, explicit };
}

// A card: an album, single, playlist, artist or video.
function parseCard(r) {
  const title = text(r.title);
  const nav = r.navigationEndpoint || (runsOf(r.title)[0] || {}).navigationEndpoint;
  const image = thumb(r.thumbnailRenderer);
  const sub = runsOf(r.subtitle);
  const { artists, year, label } = peopleAndAlbum(sub);
  if (nav && nav.watchEndpoint && nav.watchEndpoint.videoId) return { kind: 'video', videoId: nav.watchEndpoint.videoId, title, artists, album: null, durationSec: null, image };
  const b = browseOf(nav);
  if (!b || !title) return null;
  const pt = pageType(nav);
  if (isArtistType(pt)) return { kind: 'artist', id: b.browseId, name: title, image };
  if (pt === 'MUSIC_PAGE_TYPE_ALBUM' || /^MPREb_/.test(b.browseId)) return { kind: 'album', id: b.browseId, name: title, artists, year, albumType: (label || 'Album').toLowerCase(), image };
  if (pt === 'MUSIC_PAGE_TYPE_PLAYLIST' || /^VL/.test(b.browseId)) return { kind: 'playlist', id: b.browseId.replace(/^VL/, ''), name: title, owner: text(r.subtitle).split(' • ').filter((s) => !/playlist/i.test(s))[0] || '', image };
  return null;
}

function itemsOf(list) {
  const out = [];
  let more = null;
  for (const c of list || []) {
    if (c.musicResponsiveListItemRenderer) out.push(parseRow(c.musicResponsiveListItemRenderer));
    else if (c.musicTwoRowItemRenderer) out.push(parseCard(c.musicTwoRowItemRenderer));
    else if (c.continuationItemRenderer) more = first(c.continuationItemRenderer, 'token') || more;
  }
  return { items: out.filter(Boolean), more };
}

// Every shelf on a page: { title, moreId, items, more (continuation) }.
function shelves(json) {
  const out = [];
  walk(json, (o) => {
    if (Array.isArray(o)) return true;
    const s = o.musicShelfRenderer || o.musicCarouselShelfRenderer || o.musicPlaylistShelfRenderer || o.gridRenderer;
    if (!s) return true;
    const head = (s.header && (s.header.musicCarouselShelfBasicHeaderRenderer || s.header.gridHeaderRenderer || s.header.musicShelfHeaderRenderer)) || {};
    const titleRuns = runsOf(s.title).length ? s.title : head.title;
    const moreNav = (runsOf(titleRuns)[0] || {}).navigationEndpoint || (s.bottomEndpoint || null) || first(head.moreContentButton, 'navigationEndpoint');
    const { items, more } = itemsOf(s.contents || s.items);
    out.push({ title: text(titleRuns), moreId: (browseOf(moreNav) || {}).browseId || null, items, more: (s.continuations && first(s.continuations, 'continuation')) || more });
    return false; // shelves don't nest
  });
  return out;
}

function header(json) {
  const keys = ['musicImmersiveHeaderRenderer', 'musicVisualHeaderRenderer', 'musicResponsiveHeaderRenderer', 'musicDetailHeaderRenderer'];
  let h = null;
  walk(json, (o) => {
    if (h) return false;
    if (Array.isArray(o)) return true;
    for (const k of keys) if (o[k]) { h = o[k]; return false; }
    return true;
  });
  if (!h) return null;
  const strap = runsOf(h.straplineTextOne);
  const sub = runsOf(h.subtitle);
  // Who it's by: the line above the title, or linked names in the line below it.
  const byStrap = peopleAndAlbum(strap);
  const bySub = peopleAndAlbum(sub);
  const artists = strap.length ? byStrap.artists : bySub.artists.filter((a) => a.id);
  const year = bySub.year || byStrap.year;
  const label = bySub.label || byStrap.label;
  const desc = h.description ? text(h.description.musicDescriptionShelfRenderer ? h.description.musicDescriptionShelfRenderer.description : h.description) : '';
  return {
    title: text(h.title),
    subtitle: text(h.subtitle),
    artists,
    year,
    label,
    owner: text(h.straplineTextOne) || '',
    image: thumb(h.thumbnail || h.foregroundThumbnail || h),
    description: desc.slice(0, 600),
    stats: text(h.secondSubtitle) || text(h.subscriptionButton && first(h.subscriptionButton, 'subscriberCountText')) || '',
  };
}

// ── what the app shows ─────────────────────────────────────────────────────────
// A YouTube Music song, in the same shape as a Spotify track (it plays straight from YouTube).
function toTrack(s, fallback = {}) {
  const artists = (s.artists && s.artists.length ? s.artists : fallback.artists || []).map((a) => ({ name: a.name, id: a.id || '', type: 'ytartist' }));
  const album = s.album || fallback.album || null;
  const image = s.image || fallback.image || null;
  return {
    type: 'ytm',
    uri: `ytm:track:${s.videoId}`,
    id: s.videoId,
    videoId: s.videoId,
    name: s.title,
    artists,
    album: album ? { name: album.name, id: album.id || '', type: 'ytalbum', image } : { name: '', id: '' },
    durationMs: s.durationSec ? s.durationSec * 1000 : 0,
    image,
    imageLarge: image,
    playable: true,
    video: s.kind === 'video' || undefined,
  };
}
const toAlbum = (a) => ({ type: 'ytalbum', id: a.id, uri: `ytm:album:${a.id}`, name: a.name, image: a.image, artists: (a.artists || []).map((x) => ({ name: x.name, id: x.id || '', type: 'ytartist' })), year: a.year || '', albumType: a.albumType || 'album', source: 'ytm' });
const toArtist = (a) => ({ type: 'ytartist', id: a.id, uri: `ytm:artist:${a.id}`, name: a.name, image: a.image, source: 'ytm' });
const toPlaylist = (p) => ({ type: 'ytplaylist', id: p.id, uri: `ytm:playlist:${p.id}`, name: p.name, image: p.image, owner: p.owner || '', source: 'ytm' });

class YtMusic {
  constructor({ log = console.log, fetchImpl } = {}) {
    this.log = log;
    this.fetch = fetchImpl || ((...a) => fetch(...a));
  }

  _call(endpoint, body) {
    return call(endpoint, body, this.fetch);
  }

  async _search(q, filter) {
    const json = await this._call('search', { query: q, params: FILTERS[filter] });
    return shelves(json).flatMap((s) => s.items);
  }

  // Songs, videos, albums, artists and playlists for a search.
  async search(q) {
    const kinds = ['songs', 'albums', 'artists', 'playlists', 'featured', 'videos'];
    const res = await Promise.allSettled(kinds.map((k) => this._search(q, k)));
    const got = Object.fromEntries(kinds.map((k, i) => [k, res[i].status === 'fulfilled' ? res[i].value : []]));
    if (res.every((r) => r.status === 'rejected')) throw res[0].reason;
    const songs = got.songs.filter((x) => x.kind === 'song').map(toTrack);
    const videos = got.videos.filter((x) => x.videoId).map((x) => toTrack({ ...x, kind: 'video' }));
    const playlists = [...got.featured, ...got.playlists].filter((x) => x.kind === 'playlist');
    const seen = new Set();
    return {
      songs: songs.slice(0, 20),
      videos: videos.slice(0, 12),
      albums: got.albums.filter((x) => x.kind === 'album').map(toAlbum).slice(0, 12),
      artists: got.artists.filter((x) => x.kind === 'artist').map(toArtist).slice(0, 10),
      playlists: playlists.filter((p) => !seen.has(p.id) && seen.add(p.id)).map(toPlaylist).slice(0, 16),
    };
  }

  // An artist's page: their top songs, the list of every song they have, releases, videos.
  async artist(id) {
    if (!ID_RE.test(String(id))) throw new Error('Not a YouTube Music artist');
    const json = await this._call('browse', { browseId: id });
    const h = header(json) || {};
    const all = shelves(json);
    const find = (re) => all.find((s) => re.test(s.title)) || { items: [], moreId: null };
    const songs = find(/^(top )?songs$/i);
    const info = { type: 'ytartist', id, name: h.title || '', image: h.image, description: h.description, stats: h.stats };
    const fallback = { artists: [{ name: info.name, id }] };
    return {
      info,
      topSongs: songs.items.filter((x) => x.videoId).map((s) => toTrack(s, fallback)),
      allSongsId: songs.moreId ? songs.moreId.replace(/^VL/, '') : null,
      albums: find(/^albums$/i).items.filter((x) => x.kind === 'album').map(toAlbum),
      singles: find(/singles/i).items.filter((x) => x.kind === 'album').map(toAlbum),
      videos: find(/^videos$/i).items.filter((x) => x.videoId).map((v) => toTrack({ ...v, kind: 'video' }, fallback)),
      playlists: all.filter((s) => /playlists|featured on/i.test(s.title)).flatMap((s) => s.items).filter((x) => x.kind === 'playlist').map(toPlaylist),
      related: find(/fans might also like|similar artists|fans also like/i).items.filter((x) => x.kind === 'artist').map(toArtist),
    };
  }

  // An album (or single/EP) and its songs.
  async album(id) {
    if (!ID_RE.test(String(id))) throw new Error('Not a YouTube Music album');
    if (/^OLAK5uy_/.test(id)) return this.playlist(id, { asAlbum: true });
    const json = await this._call('browse', { browseId: id });
    const h = header(json) || {};
    const info = toAlbum({ id, name: h.title, image: h.image, artists: h.artists, year: h.year, albumType: (h.label || 'album').toLowerCase() });
    const fallback = { artists: h.artists, album: { name: h.title, id }, image: h.image };
    const tracks = shelves(json).flatMap((s) => s.items).filter((x) => x.videoId).map((s) => toTrack(s, fallback));
    return { info: { ...info, total: tracks.length, description: h.description }, tracks };
  }

  // A playlist with all its songs (YouTube Music sends them in pages of 100).
  async playlist(id, { asAlbum = false, max = 3000 } = {}) {
    if (!ID_RE.test(String(id))) throw new Error('Not a YouTube Music playlist');
    const plain = String(id).replace(/^VL/, '');
    const json = await this._call('browse', { browseId: `VL${plain}` });
    const h = header(json) || {};
    const list = shelves(json).filter((s) => s.items.some((x) => x.videoId));
    const songs = list.flatMap((s) => s.items).filter((x) => x.videoId);
    let more = (list.find((s) => s.more) || {}).more || null;
    for (let n = 0; more && songs.length < max && n < 40; n++) {
      const page = await this._call('browse', { continuation: more });
      const got = [];
      let next = null;
      walk(page, (o) => {
        if (!Array.isArray(o)) return true;
        if (o.some((c) => c && (c.musicResponsiveListItemRenderer || c.continuationItemRenderer))) {
          const r = itemsOf(o);
          got.push(...r.items);
          next = r.more || next;
          return false;
        }
        return true;
      });
      next = next || first(page.continuationContents, 'continuation');
      songs.push(...got.filter((x) => x.videoId));
      if (!got.length || next === more) break;
      more = next;
    }
    const image = h.image || (songs[0] && songs[0].image) || null;
    const tracks = songs.map((s) => toTrack(s, asAlbum ? { artists: h.artists, album: { name: h.title, id: plain }, image } : {}));
    const base = asAlbum ? toAlbum({ id: plain, name: h.title, image, artists: h.artists, year: h.year }) : toPlaylist({ id: plain, name: h.title, image, owner: (h.artists[0] && h.artists[0].name) || h.owner || '' });
    return { info: { ...base, description: h.description, total: tracks.length, stats: h.stats || h.subtitle }, tracks };
  }

  // The YouTube Music artist with this name (for "More on YouTube Music" on an artist page).
  // One song or video from its YouTube id (for "add a YouTube link to a playlist").
  async song(videoId) {
    if (!/^[\w-]{11}$/.test(String(videoId))) throw new Error('That isn’t a YouTube video link');
    let found = null;
    try {
      const json = await this._call('next', { videoId, isAudioOnly: true });
      const walk = (o) => {
        if (found || !o || typeof o !== 'object') return;
        if (o.playlistPanelVideoRenderer && o.playlistPanelVideoRenderer.videoId === videoId) return (found = o.playlistPanelVideoRenderer);
        for (const v of Object.values(o)) walk(v);
      };
      walk(json);
    } catch {}
    if (found) {
      const runs = runsOf(found.longBylineText);
      const artists = runs.filter((r) => /^UC/.test(((r.navigationEndpoint || {}).browseEndpoint || {}).browseId || '')).map((r) => ({ name: r.text, id: r.navigationEndpoint.browseEndpoint.browseId }));
      const alb = runs.find((r) => /^MPRE/.test(((r.navigationEndpoint || {}).browseEndpoint || {}).browseId || ''));
      const thumbs = (found.thumbnail && found.thumbnail.thumbnails) || [];
      const len = text(found.lengthText).split(':').map(Number);
      return toTrack({
        videoId,
        title: text(found.title),
        artists: artists.length ? artists : runs.length ? [{ name: runs[0].text }] : [],
        album: alb ? { name: alb.text, id: alb.navigationEndpoint.browseEndpoint.browseId } : null,
        image: thumbs.length ? thumbs[thumbs.length - 1].url : null,
        durationSec: len.every((n) => !isNaN(n)) ? len.reduce((a, n) => a * 60 + n, 0) : 0,
        kind: alb ? 'song' : 'video',
      });
    }
    // Fallback: the video's own details.
    const p = await this._call('player', { videoId });
    const d = p && p.videoDetails;
    if (!d || !d.title) throw new Error('YouTube couldn’t find that video');
    const thumbs = (d.thumbnail && d.thumbnail.thumbnails) || [];
    return toTrack({ videoId, title: d.title, artists: [{ name: String(d.author || '').replace(/ - Topic$/, ''), id: /^UC/.test(d.channelId || '') ? d.channelId : '' }], image: thumbs.length ? thumbs[thumbs.length - 1].url : null, durationSec: Number(d.lengthSeconds) || 0, kind: 'video' });
  }

  async findArtist(name) {
    const items = (await this._search(String(name || '').slice(0, 100), 'artists')).filter((x) => x.kind === 'artist');
    const norm = (s) => String(s || '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^\p{L}\p{N}]+/gu, '');
    const exact = items.find((a) => norm(a.name) === norm(name));
    return exact ? toArtist(exact) : null;
  }
}

module.exports = { YtMusic, shelves, header, parseRow, parseCard, toTrack, FILTERS, isYtId: (id) => ID_RE.test(String(id)) };
