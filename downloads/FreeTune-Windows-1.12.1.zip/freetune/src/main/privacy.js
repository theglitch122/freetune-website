// Requests the hidden Spotify sign-in/token window is never allowed to make.
// FreeTune only needs Spotify's login page and its data API; everything below is
// advertising, analytics, or telemetry, so it is cancelled before it leaves your PC.

const BLOCKED_HOSTS = [
  'doubleclick.net',
  'googlesyndication.com',
  'googleadservices.com',
  'google-analytics.com',
  'googletagmanager.com',
  'googletagservices.com',
  'analytics.google.com',
  'adservice.google.com',
  'facebook.net',
  'connect.facebook.net',
  'scorecardresearch.com',
  'hotjar.com',
  'sentry.io',
  'branch.io',
  'app.link',
  'adsrvr.org',
  'adnxs.com',
  'quantserve.com',
  'omtrdc.net',
  'demdex.net',
  'bat.bing.com',
  'clarity.ms',
  'tiktok.com',
  'snapchat.com',
  'pinterest.com',
  'twitter.com',
  'ads-twitter.com',
  'redditstatic.com',
  'licdn.com',
  'onetrust.com',
  'cookielaw.org',
  // Spotify's own ad + telemetry endpoints
  'adeventtracker.spotify.com',
  'pixel.spotify.com',
  'pixel-static.spotify.com',
  'log.spotify.com',
  'analytics.spotify.com',
  'ads-fa.spotify.com',
  'audio-ak-spotify-com.akamaized.net', // ad audio
  'spclient.wg.spotify.com/ads',
];

// Path fragments on otherwise-needed Spotify hosts that are pure tracking or ads.
const BLOCKED_PATHS = [
  '/gabo-receiver-service/', // event logging
  '/ad-logic/',
  '/ads/',
  '/event-service/',
];

function isBlocked(urlString) {
  let u;
  try {
    u = new URL(urlString);
  } catch {
    return false;
  }
  const host = u.hostname;
  const hostPath = host + u.pathname;
  for (const h of BLOCKED_HOSTS) {
    if (h.includes('/')) {
      if (hostPath.startsWith(h)) return true;
    } else if (host === h || host.endsWith('.' + h)) {
      return true;
    }
  }
  if (host.endsWith('spotify.com')) {
    for (const p of BLOCKED_PATHS) if (u.pathname.includes(p)) return true;
  }
  return false;
}

module.exports = { isBlocked };
