// A tiny HTTP server bound to 127.0.0.1 (only reachable from this PC). The player asks
// it for /audio/<videoId>; it resolves the stream with yt-dlp and relays the bytes,
// passing seek (Range) requests straight through so scrubbing is instant.
//
// Streams are fetched over the same kind of internet address (IPv4 or IPv6) as the
// lookup that produced them, because YouTube ties each stream link to that address.

const http = require('http');
const fs = require('fs');
const { streamRequest } = require('./httpstream');

// A song already saved on this PC: served straight from disk, seeking included.
function serveFile(req, res, file) {
  let size;
  try {
    size = fs.statSync(file).size;
  } catch {
    return false;
  }
  const type = file.endsWith('.webm') ? 'audio/webm' : file.endsWith('.audio') ? 'audio/mpeg' : 'audio/mp4';
  const m = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
  const base = { 'Content-Type': type, 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store' };
  if (m && (m[1] || m[2])) {
    const start = m[1] ? Number(m[1]) : Math.max(0, size - Number(m[2]));
    const end = Math.min(m[1] && m[2] ? Number(m[2]) : size - 1, size - 1);
    if (start >= size || start > end) {
      res.writeHead(416, { 'Content-Range': `bytes */${size}` }).end();
      return true;
    }
    res.writeHead(206, { ...base, 'Content-Range': `bytes ${start}-${end}/${size}`, 'Content-Length': end - start + 1 });
    if (req.method === 'HEAD') return res.end(), true;
    fs.createReadStream(file, { start, end }).on('error', () => res.destroy()).pipe(res);
  } else {
    res.writeHead(200, { ...base, 'Content-Length': size });
    if (req.method === 'HEAD') return res.end(), true;
    fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
  }
  return true;
}

const REFUSED_MESSAGE =
  'YouTube is refusing to send audio to your internet connection right now. To fix it: use a cookies file from a spare Google account (Settings → YouTube bot checks), switch networks (like a phone hotspot), or try again in a few hours.';

const isRefused = (status) => status === 403 || status === 410;

// Podcast episodes stream straight from the podcast's own host. Only the plain request a
// podcast app makes is sent: no cookies, no referrer, nothing that identifies you.
const EPISODE_HEADERS = { 'User-Agent': 'FreeTune/podcast-player', Accept: 'audio/*,*/*;q=0.5' };

async function relayEpisode(req, res, url, log) {
  const ctrl = new AbortController();
  res.on('close', () => ctrl.abort());
  const headers = { ...EPISODE_HEADERS };
  if (req.headers.range) headers.Range = req.headers.range;
  let up;
  try {
    up = await streamRequest(url, { headers, signal: ctrl.signal, maxHops: 10, timeoutMs: 25000 });
  } catch (e) {
    if (!res.headersSent && !res.destroyed) res.writeHead(502, { 'Content-Type': 'text/plain' }).end(`The podcast’s server didn’t answer (${e.message})`);
    return;
  }
  if (!(up.status === 200 || up.status === 206)) {
    up.cancel();
    log('podcasts: host answered', up.status);
    if (!res.headersSent) res.writeHead(up.status === 416 ? 416 : 502, { 'Content-Type': 'text/plain' }).end(`The podcast’s server answered ${up.status}`);
    return;
  }
  const out = { 'Content-Type': up.headers.get('content-type') || 'audio/mpeg', 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store' };
  if (/text\/html/i.test(out['Content-Type'])) out['Content-Type'] = 'audio/mpeg';
  for (const h of ['content-length', 'content-range']) {
    const v = up.headers.get(h);
    if (v) out[h.replace(/(^|-)\w/g, (x) => x.toUpperCase())] = v;
  }
  res.writeHead(up.status, out);
  if (req.method === 'HEAD') {
    up.cancel();
    res.end();
    return;
  }
  up.body.on('error', () => res.destroy());
  up.body.pipe(res);
}

function createAudioServer({ ytdlp, cache = null, log = console.log }) {
  // Before a song starts: make sure YouTube will actually send its audio. A refused link is
  // refreshed once, then another way in is tried once, so the player gets a clear answer
  // instead of a vague "format error" (and doesn't skip through the whole queue).
  async function check(videoId) {
    for (let attempt = 0; attempt < 3; attempt++) {
      const entry = await ytdlp.resolve(videoId);
      let res = null;
      try {
        res = await streamRequest(entry.url, { headers: { ...entry.headers, Range: 'bytes=0-1' }, family: entry.family || 0, timeoutMs: 12000 });
        res.cancel();
      } catch (e) {
        log('audio: stream check could not connect for', videoId, '-', e.message);
        if (attempt === 0) continue; // try once more, then let the player have a go anyway
        return entry;
      }
      if (!isRefused(res.status)) return entry;
      log('audio: YouTube refused the stream for', videoId, `(${res.status}, ${entry.method || 'default'} method)`);
      if (attempt === 0) ytdlp.invalidate(videoId);
      else if (attempt === 1) ytdlp.nextStrategy();
    }
    ytdlp.botUntil = Date.now() + 15 * 60e3; // back off: one attempt per song for a while
    throw Object.assign(new Error(REFUSED_MESSAGE), { refused: true });
  }

  // Episode addresses the player may ask for, by a short key (never the address itself in the page).
  const episodes = new Map();
  let epCounter = 0;
  function addEpisode(uri, url) {
    for (const [k, v] of episodes) if (v.uri === uri && v.url === url) return `${base}/ep/${k}`;
    const k = `${(++epCounter).toString(36)}${Math.random().toString(36).slice(2, 8)}`;
    episodes.set(k, { uri, url });
    if (episodes.size > 50) episodes.delete(episodes.keys().next().value);
    return `${base}/ep/${k}`;
  }
  let base = '';
  // Files on this PC the player may ask for (downloaded episodes), by a short key.
  const files = new Map();
  function addFile(p) {
    for (const [k, v] of files) if (v === p) return `${base}/file/${k}`;
    const k = `${(++epCounter).toString(36)}${Math.random().toString(36).slice(2, 8)}`;
    files.set(k, p);
    if (files.size > 50) files.delete(files.keys().next().value);
    return `${base}/file/${k}`;
  }

  const server = http.createServer(async (req, res) => {
    const lf = /^\/file\/([a-z0-9]{2,20})(?:\?.*)?$/.exec(req.url || '');
    if (lf) {
      const p = files.get(lf[1]);
      if (!p || !serveFile(req, res, p)) res.writeHead(404).end();
      return;
    }
    const ep = /^\/ep\/([a-z0-9]{2,20})(?:\?.*)?$/.exec(req.url || '');
    if (ep) {
      const e = episodes.get(ep[1]);
      if (!e) return res.writeHead(404).end();
      return relayEpisode(req, res, e.url, log);
    }
    const m = /^\/audio\/([\w-]{11})(?:\?.*)?$/.exec(req.url || '');
    if (!m) {
      res.writeHead(404).end();
      return;
    }
    const videoId = m[1];
    const saved = cache && cache.file(videoId);
    if (saved && serveFile(req, res, saved)) return;
    const range = req.headers.range;
    let closed = false;
    const ctrl = new AbortController();
    res.on('close', () => {
      closed = true;
      ctrl.abort();
    });
    let upstream = null;
    let entry = null;
    for (let attempt = 0; attempt < 2 && !closed; attempt++) {
      try {
        entry = await ytdlp.resolve(videoId);
      } catch (e) {
        log('audio: resolve failed', videoId, e.message);
        if (!res.headersSent) res.writeHead(502, { 'Content-Type': 'text/plain' }).end(e.message);
        return;
      }
      const headers = { ...entry.headers };
      delete headers['Accept-Encoding'];
      if (range) headers.Range = range;
      try {
        upstream = await streamRequest(entry.url, { headers, family: entry.family || 0, signal: ctrl.signal });
      } catch (e) {
        upstream = null;
        if (closed) return;
      }
      if (upstream && (upstream.ok || upstream.status === 206)) break;
      if (upstream && upstream.status === 416) {
        upstream.cancel();
        res.writeHead(416).end();
        return;
      }
      log('audio: upstream', upstream ? upstream.status : 'unreachable', 'for', videoId, '- refreshing link');
      if (upstream) upstream.cancel();
      upstream = null;
      ytdlp.invalidate(videoId);
    }
    if (closed) {
      if (upstream) upstream.cancel();
      return;
    }
    if (!upstream) {
      res.writeHead(502, { 'Content-Type': 'text/plain' }).end('Stream unavailable');
      return;
    }
    const out = {
      'Content-Type': upstream.headers.get('content-type') || entry.mime || 'audio/mp4',
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'no-store',
    };
    for (const h of ['content-length', 'content-range']) {
      const v = upstream.headers.get(h);
      if (v) out[h.replace(/(^|-)\w/g, (s) => s.toUpperCase())] = v;
    }
    res.writeHead(upstream.status, out);
    if (req.method === 'HEAD') {
      upstream.cancel();
      res.end();
      return;
    }
    upstream.body.on('error', () => res.destroy());
    upstream.body.pipe(res);
  });

  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      log('audio: server on port', port);
      base = `http://127.0.0.1:${port}`;
      resolve({ server, port, base, check, addEpisode, addFile });
    });
  });
}

module.exports = { createAudioServer, REFUSED_MESSAGE };
