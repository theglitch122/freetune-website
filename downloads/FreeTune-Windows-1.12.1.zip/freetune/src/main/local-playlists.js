// Playlists that live only on this PC. Nothing about them is sent anywhere: the songs are
// saved with their details (title, artists, album, cover) so they show up and play even
// without asking Spotify again.

const crypto = require('crypto');

const newId = (bytes = 8) => crypto.randomBytes(bytes).toString('hex');

// Just what's needed to show and play a song, plus a per-entry id (uid) so the same
// song can be removed or moved precisely.
function slimTrack(t) {
  return {
    uri: String(t.uri || ''),
    id: String(t.id || String(t.uri || '').split(':').pop() || ''),
    name: String(t.name || ''),
    artists: (t.artists || []).map((a) => ({ uri: a.uri || '', id: a.id || '', name: a.name || '' })).slice(0, 10),
    album: t.album ? { uri: t.album.uri || '', id: t.album.id || '', name: t.album.name || '', image: t.album.image || null, imageLarge: t.album.imageLarge || null } : null,
    durationMs: Number(t.durationMs) || 0,
    image: t.image || (t.album && t.album.image) || null,
    imageLarge: t.imageLarge || t.image || null,
    playable: t.playable !== false,
  };
}

class LocalPlaylists {
  constructor(store) {
    this.store = store; // JsonStore with { lists: [] }
  }

  _all() {
    const l = this.store.get('lists', []);
    return Array.isArray(l) ? l : [];
  }

  // Saved straight away (not batched): these are your own playlists, so closing the app
  // right after an edit must never lose it.
  _save(lists) {
    this.store.set('lists', lists);
    if (this.store.saveNow) this.store.saveNow();
  }

  _find(id) {
    const lists = this._all();
    const p = lists.find((x) => x.id === id);
    if (!p) throw new Error('That playlist doesn’t exist any more.');
    return { lists, p };
  }

  summary(p) {
    const covers = [];
    for (const t of p.tracks) {
      const img = t.image || (t.album && t.album.image);
      if (img && !covers.includes(img)) covers.push(img);
      if (covers.length === 4) break;
    }
    return {
      type: 'playlist',
      local: true,
      uri: `local:playlist:${p.id}`,
      id: p.id,
      name: p.name,
      description: p.description || '',
      image: covers[0] || null,
      covers,
      owner: 'You',
      total: p.tracks.length,
      createdAt: p.createdAt,
      updatedAt: p.updatedAt,
    };
  }

  list() {
    return this._all()
      .map((p) => this.summary(p))
      .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  }

  get(id) {
    const { p } = this._find(id);
    return { info: this.summary(p), tracks: p.tracks.map((t) => ({ ...t })), total: p.tracks.length };
  }

  create(name, description = '') {
    const clean = String(name || '').trim().slice(0, 100) || 'My playlist';
    const p = { id: newId(), name: clean, description: String(description || '').slice(0, 300), createdAt: Date.now(), updatedAt: Date.now(), tracks: [] };
    this._save([...this._all(), p]);
    return this.summary(p);
  }

  edit(id, { name, description } = {}) {
    const { lists, p } = this._find(id);
    if (name != null) p.name = String(name).trim().slice(0, 100) || p.name;
    if (description != null) p.description = String(description).slice(0, 300);
    p.updatedAt = Date.now();
    this._save(lists);
    return this.summary(p);
  }

  remove(id) {
    this._save(this._all().filter((x) => x.id !== id));
    return true;
  }

  // Adds songs at the end. Songs already in the playlist are skipped (like Spotify's
  // "already added" warning), so double-clicking Add doesn't make duplicates.
  addTracks(id, tracks) {
    const { lists, p } = this._find(id);
    const have = new Set(p.tracks.map((t) => t.uri));
    let added = 0;
    for (const t of tracks || []) {
      if (!t || !t.uri || have.has(t.uri)) continue;
      have.add(t.uri);
      p.tracks.push({ ...slimTrack(t), uid: newId(6), addedAt: new Date().toISOString() });
      added++;
    }
    p.updatedAt = Date.now();
    this._save(lists);
    return { added, skipped: (tracks || []).length - added };
  }

  removeTracks(id, uids) {
    const { lists, p } = this._find(id);
    const drop = new Set(uids || []);
    p.tracks = p.tracks.filter((t) => !drop.has(t.uid));
    p.updatedAt = Date.now();
    this._save(lists);
    return true;
  }

  // Moves the given entries (kept in their current order) to just before `beforeUid`,
  // or to the end when beforeUid is null.
  moveTracks(id, uids, beforeUid) {
    const { lists, p } = this._find(id);
    const moving = new Set(uids || []);
    const moved = p.tracks.filter((t) => moving.has(t.uid));
    const rest = p.tracks.filter((t) => !moving.has(t.uid));
    let at = beforeUid ? rest.findIndex((t) => t.uid === beforeUid) : -1;
    if (at < 0) at = rest.length;
    p.tracks = [...rest.slice(0, at), ...moved, ...rest.slice(at)];
    p.updatedAt = Date.now();
    this._save(lists);
    return true;
  }
}

// YouTube songs added to your Spotify playlists. Spotify can only hold Spotify songs, so
// these are kept on this device only (like Spotify's own local files) and shown at the end
// of the playlist here. Spotify never sees them.
const EXTRA_KEYS = ['type', 'uri', 'id', 'videoId', 'name', 'artists', 'album', 'image', 'imageLarge', 'durationMs', 'playable', 'video'];
class PlaylistExtras {
  constructor(store) {
    this.store = store; // { lists: { spotifyPlaylistId: [track, ...] } }
  }
  all() {
    return this.store.get('lists', {});
  }
  get(id) {
    return this.all()[String(id)] || [];
  }
  add(id, tracks) {
    id = String(id || '');
    if (!/^[A-Za-z0-9]{10,40}$/.test(id)) throw new Error('Not a Spotify playlist');
    const lists = this.all();
    const list = lists[id] || [];
    let added = 0;
    for (const t of Array.isArray(tracks) ? tracks.slice(0, 500) : []) {
      if (!t || !/^[\w-]{11}$/.test(String(t.videoId || ''))) continue;
      const uri = `ytm:track:${t.videoId}`;
      if (list.some((x) => x.uri === uri)) continue;
      const o = {};
      for (const k of EXTRA_KEYS) if (t[k] != null) o[k] = t[k];
      list.push({ ...o, uri, type: 'ytm', extra: true, addedAt: new Date().toISOString() });
      added++;
    }
    lists[id] = list;
    this.store.set('lists', lists);
    return { added, skipped: (Array.isArray(tracks) ? tracks.length : 0) - added, list };
  }
  remove(id, uris) {
    const lists = this.all();
    const drop = new Set([].concat(uris || []));
    const list = (lists[String(id)] || []).filter((t) => !drop.has(t.uri));
    if (list.length) lists[String(id)] = list;
    else delete lists[String(id)];
    this.store.set('lists', lists);
    return list;
  }
}

module.exports = { LocalPlaylists, PlaylistExtras, slimTrack };
