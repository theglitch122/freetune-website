// Finds the YouTube Music recording that matches a Spotify track.
// Search runs against YouTube Music's public search endpoint without any account or
// cookies, so YouTube can't tie what you play to you. Matching uses the same
// title/artist/duration scoring as Meld; good matches are remembered locally.

const SEARCH_URL = 'https://music.youtube.com/youtubei/v1/search?prettyPrint=false';
const SONGS_FILTER = 'EgWKAQIIAWoKEAkQBRAKEAMQBA=='; // "Songs" tab
const VIDEOS_FILTER = 'EgWKAQIQAWoKEAkQChAFEAMQBA=='; // "Videos" tab
const CLIENT = {
  clientName: 'WEB_REMIX',
  clientVersion: '1.20250929.03.00',
  hl: 'en',
  gl: 'US',
};
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36';

// ── matching (ported from Meld's SpotifyMapper) ────────────────────────────────
function normalize(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/\(feat\..*?\)/g, '')
    .replace(/\(ft\..*?\)/g, '')
    .replace(/\[.*?]/g, '')
    .replace(/\(.*?remaster.*?\)/gi, '')
    .replace(/\s+-\s+.*remaster.*$/gi, '')
    .replace(/\(.*?remix.*?\)/gi, '')
    .replace(/[^\p{L}\p{N}\s]/gu, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function bigrams(s) {
  const out = new Set();
  for (let i = 0; i < s.length - 1; i++) out.add(s.slice(i, i + 2));
  return out;
}

function similarity(a, b) {
  if (!a || !b) return 0;
  if (a === b) return 1;
  const A = bigrams(a);
  const B = bigrams(b);
  if (!A.size || !B.size) return a === b ? 1 : 0;
  let inter = 0;
  for (const x of A) if (B.has(x)) inter++;
  return (2 * inter) / (A.size + B.size);
}

function durationScore(spotifyMs, candSec) {
  if (!candSec || !spotifyMs) return 0.5;
  const diff = Math.abs(Math.round(spotifyMs / 1000) - candSec);
  if (diff <= 2) return 1;
  if (diff <= 5) return 0.8;
  if (diff <= 10) return 0.5;
  if (diff <= 30) return 0.2;
  return 0;
}

function matchScore(track, cand) {
  const title = similarity(normalize(track.name), normalize(cand.title));
  const spotifyArtists = (track.artists || []).map((a) => a.name).join(' ');
  const artist = Math.max(
    similarity(normalize(spotifyArtists), normalize(cand.artists)),
    similarity(normalize((track.artists[0] || {}).name), normalize(cand.artists))
  );
  return title * 0.45 + artist * 0.35 + durationScore(track.durationMs, cand.durationSec) * 0.2;
}

// ── YouTube Music search ───────────────────────────────────────────────────────
function textOf(runsHolder) {
  if (!runsHolder) return '';
  if (runsHolder.simpleText) return runsHolder.simpleText;
  return (runsHolder.runs || []).map((r) => r.text).join('');
}

function parseDuration(s) {
  const m = /^(?:(\d+):)?(\d{1,2}):(\d{2})$/.exec(String(s).trim());
  if (!m) return null;
  return (Number(m[1] || 0) * 3600) + Number(m[2]) * 60 + Number(m[3]);
}

function findVideoId(item) {
  if (item.playlistItemData && item.playlistItemData.videoId) return item.playlistItemData.videoId;
  let found = null;
  (function walk(x, depth) {
    if (found || !x || typeof x !== 'object' || depth > 12) return;
    if (x.watchEndpoint && x.watchEndpoint.videoId) {
      found = x.watchEndpoint.videoId;
      return;
    }
    for (const k of Object.keys(x)) walk(x[k], depth + 1);
  })(item, 0);
  return found;
}

function parseSearchResponse(json) {
  const out = [];
  const tabs =
    (json.contents &&
      json.contents.tabbedSearchResultsRenderer &&
      json.contents.tabbedSearchResultsRenderer.tabs) ||
    [];
  for (const tab of tabs) {
    const sections =
      (tab.tabRenderer &&
        tab.tabRenderer.content &&
        tab.tabRenderer.content.sectionListRenderer &&
        tab.tabRenderer.content.sectionListRenderer.contents) ||
      [];
    for (const sec of sections) {
      const shelf = sec.musicShelfRenderer;
      if (!shelf) continue;
      for (const c of shelf.contents || []) {
        const item = c.musicResponsiveListItemRenderer;
        if (!item) continue;
        const cols = (item.flexColumns || []).map((f) => f.musicResponsiveListItemFlexColumnRenderer || {});
        const title = textOf(cols[0] && cols[0].text);
        const runs = (cols[1] && cols[1].text && cols[1].text.runs) || [];
        const artistRuns = runs.filter((r) => {
          const b = r.navigationEndpoint && r.navigationEndpoint.browseEndpoint;
          const pt = b && b.browseEndpointContextSupportedConfigs &&
            b.browseEndpointContextSupportedConfigs.browseEndpointContextMusicConfig &&
            b.browseEndpointContextSupportedConfigs.browseEndpointContextMusicConfig.pageType;
          return pt ? pt === 'MUSIC_PAGE_TYPE_ARTIST' || pt === 'MUSIC_PAGE_TYPE_USER_CHANNEL' : b && /^UC/.test(b.browseId || '');
        });
        const parts = runs.map((r) => r.text).filter((t) => t && t.trim() !== '•' && t.trim() !== '&' && t.trim() !== ',');
        let artists = artistRuns.map((r) => r.text).join(', ');
        if (!artists) artists = parts.filter((p) => !/^(song|video|single|ep|album)$/i.test(p.trim()))[0] || '';
        let durationSec = null;
        for (const p of parts.slice().reverse()) {
          const d = parseDuration(p);
          if (d != null) {
            durationSec = d;
            break;
          }
        }
        const fixed = (item.fixedColumns || [])[0];
        if (durationSec == null && fixed) {
          durationSec = parseDuration(textOf(fixed.musicResponsiveListItemFixedColumnRenderer.text));
        }
        const videoId = findVideoId(item);
        if (videoId && title) out.push({ videoId, title, artists, durationSec });
      }
    }
  }
  return out;
}

async function searchYtMusic(query, filter = SONGS_FILTER) {
  const res = await fetch(SEARCH_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': UA,
      Origin: 'https://music.youtube.com',
      Referer: 'https://music.youtube.com/',
      'X-YouTube-Client-Name': '67',
      'X-YouTube-Client-Version': CLIENT.clientVersion,
    },
    body: JSON.stringify({ context: { client: CLIENT, user: {} }, query, params: filter }),
  });
  if (!res.ok) throw new Error(`YouTube Music search failed (${res.status})`);
  return parseSearchResponse(await res.json());
}

class Matcher {
  constructor({ store, log = console.log }) {
    this.store = store; // { [spotifyUri]: { videoId, score, manual? } }
    this.log = log;
    this.inflight = new Map();
  }

  cached(uri) {
    return this.store.get(uri, null);
  }

  setManual(uri, videoId) {
    this.store.set(uri, { videoId, score: 1, manual: true });
  }

  clear() {
    this.store.clear();
  }

  async find(track) {
    // A song from YouTube Music's own catalog is already its recording.
    if (track && track.videoId && /^[\w-]{11}$/.test(track.videoId)) return { videoId: track.videoId, score: 1 };
    const key = track.uri || `${track.name}|${(track.artists[0] || {}).name}`;
    const hit = this.store.get(key, null);
    if (hit && hit.videoId) return hit;
    if (this.inflight.has(key)) return this.inflight.get(key);
    const job = (async () => {
      const artist = (track.artists[0] || {}).name || '';
      const q = `${artist} ${track.name}`.trim();
      let best = null;
      const consider = (cands, penalty = 0) => {
        for (const c of cands.slice(0, 8)) {
          const s = matchScore(track, c) - penalty;
          if (!best || s > best.score) best = { videoId: c.videoId, score: s, title: c.title, artists: c.artists };
        }
      };
      consider(await searchYtMusic(q, SONGS_FILTER));
      if (!best || best.score < 0.6) {
        try {
          consider(await searchYtMusic(q, VIDEOS_FILTER), 0.05);
        } catch (e) {
          this.log('youtube: video search failed', e.message);
        }
      }
      if (!best) throw new Error(`Couldn't find “${track.name}” on YouTube Music`);
      this.log(`youtube: matched "${q}" -> ${best.videoId} (${best.title} / ${best.artists}) score=${best.score.toFixed(2)}`);
      if (best.score >= 0.5) this.store.set(key, { videoId: best.videoId, score: best.score });
      return best;
    })().finally(() => this.inflight.delete(key));
    this.inflight.set(key, job);
    return job;
  }
}

// Podcast episodes whose show has no public feed. Some shows also post episodes on YouTube,
// and many "shows" are really songs (unreleased tracks uploaded as episodes). Only a close
// match is used: the right title and, for a title-only match, the same length to the
// second or so (a wrong hour-long video is worse than none).
Matcher.prototype.findEpisode = async function (ep) {
  const key = ep.uri;
  const hit = this.store.get(key, null);
  if (hit && hit.videoId) return hit;
  const show = (ep.artists[0] || {}).name || '';
  const feat = (/\((?:feat|ft)\.?\s+([^)]*)\)/i.exec(ep.name) || [])[1] || '';
  const queries = [`${show} ${ep.name}`.trim()];
  if (feat) queries.push(`${ep.name.replace(/\((?:feat|ft)\.?[^)]*\)/i, '')} ${feat}`.trim());
  let best = null;
  const consider = (cands) => {
    for (const c of cands.slice(0, 8)) {
      const full = matchScore(ep, c);
      const title = similarity(normalize(ep.name), normalize(c.title));
      const dur = durationScore(ep.durationMs, c.durationSec);
      // A match on the show as the artist, or the same title at the same length.
      const ok = full >= 0.62 || (title >= 0.85 && dur >= 0.8 && ep.durationMs > 0);
      const s = Math.max(full, title * 0.7 + dur * 0.3);
      if (ok && (!best || s > best.score)) best = { videoId: c.videoId, score: s, title: c.title, artists: c.artists };
    }
  };
  for (const q of queries) {
    for (const f of [SONGS_FILTER, VIDEOS_FILTER]) {
      try {
        consider(await searchYtMusic(q, f));
      } catch (e) {
        this.log('youtube: episode search failed', e.message);
      }
      if (best && best.score >= 0.85) break;
    }
    if (best && best.score >= 0.85) break;
  }
  if (!best) return null;
  this.log(`youtube: episode "${ep.name}" -> ${best.videoId} (${best.title} / ${best.artists}) score=${best.score.toFixed(2)}`);
  this.store.set(key, { videoId: best.videoId, score: best.score });
  return best;
};

function parseYouTubeLink(s) {
  const str = String(s || '').trim();
  if (/^[\w-]{11}$/.test(str)) return str;
  try {
    const u = new URL(str);
    if (u.hostname === 'youtu.be') return u.pathname.slice(1, 12);
    const v = u.searchParams.get('v');
    if (v && /^[\w-]{11}$/.test(v)) return v;
    const m = /\/(?:shorts|embed|live)\/([\w-]{11})/.exec(u.pathname);
    if (m) return m[1];
  } catch {
    /* not a URL */
  }
  return null;
}

module.exports = { Matcher, searchYtMusic, parseSearchResponse, matchScore, normalize, parseYouTubeLink, CLIENT, UA };
