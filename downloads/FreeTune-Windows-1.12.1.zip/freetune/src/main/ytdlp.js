// Manages yt-dlp, the open-source tool FreeTune uses to get the audio stream for a
// YouTube Music track. It is downloaded once from its official GitHub releases into
// FreeTune's own folder and kept up to date automatically (YouTube changes often).
//
// yt-dlp needs a JavaScript runtime for YouTube. Electron already contains Node.js, so
// we point yt-dlp at FreeTune's own executable running in Node mode — no extra installs.

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const { Readable } = require('stream');
const { pipeline } = require('stream/promises');

// Nightly builds: YouTube breaks things often, and fixes land there days or weeks before a stable release.
const RELEASE = 'https://github.com/yt-dlp/yt-dlp-nightly-builds/releases/latest/download/';
const CHANNEL = 'nightly';
const ASSET = { win32: 'yt-dlp.exe', darwin: 'yt-dlp_macos', linux: 'yt-dlp_linux' }[process.platform] || 'yt-dlp';
const UPDATE_EVERY_MS = 2 * 24 * 3600 * 1000;

// YouTube's "Sign in to confirm you're not a bot" wall (the apostrophe can arrive garbled on Windows).
const isBotCheck = (s) => /confirm you.{0,3}re not a bot|not a bot/i.test(String(s));
const BOT_MESSAGE = 'YouTube is asking FreeTune to prove it isn’t a bot. YouTube has flagged your internet connection for anyone who isn’t signed in (not just FreeTune). To fix it: use a cookies file from a spare Google account (Settings → YouTube bot checks), switch networks (like a phone hotspot), or wait a few hours.';

// Errors that are about the video itself: no other method will help, so stop right away.
const isFinalError = (s) => /private video|members only|members-only|join this channel|removed|terminated|isn.t available|unavailable|age-restricted|confirm your age|copyright|not available in your country|live event|premieres in|invalid|not a valid/i.test(String(s));
const BROKEN_MESSAGE = 'YouTube changed something and none of FreeTune’s ways in work right now. FreeTune is updating its playback engine. Try again in a few minutes.';

// Ways of asking YouTube for a song, tried in order when one hits the bot check.
// The one that worked is remembered for a few hours.
const STRATEGIES = [
  { name: 'default', args: [], family: 0 },
  { name: 'music', args: ['--extractor-args', 'youtube:player_client=web_music'], family: 0 },
  { name: 'safari', args: ['--extractor-args', 'youtube:player_client=web_safari,web_embedded,-tv_downgraded'], family: 0 },
  { name: 'embedded', args: ['--extractor-args', 'youtube:player_client=web_embedded'], family: 0 },
  { name: 'vr', args: ['--extractor-args', 'youtube:player_client=android_vr'], family: 0 },
  // Last resort over IPv4. Its streams are then fetched over IPv4 too (see httpstream.js).
  { name: 'vr4', args: ['-4', '--extractor-args', 'youtube:player_client=android_vr'], family: 4 },
];

class YtDlp {
  constructor({ binDir, store, log = console.log, onStatus = () => {} }) {
    this.binDir = binDir;
    this.store = store;
    this.log = log;
    this.onStatus = onStatus;
    this.exe = path.join(binDir, process.platform === 'win32' ? 'yt-dlp.exe' : 'yt-dlp');
    this._ensuring = null;
    this.cache = new Map(); // videoId -> { url, headers, expires, mime }
    this.inflight = new Map();
  }

  installed() {
    return fs.existsSync(this.exe) && fs.statSync(this.exe).size > 1_000_000;
  }

  async ensure() {
    if (this.installed()) {
      // Move an older stable engine over to the nightly channel once, before using it.
      if (this.store.get('ytdlpChannel', null) !== CHANNEL) {
        if (!this._switching) {
          this._switching = this._maybeUpdate(true).then((out) => {
            if (out && /nightly|up to date|Updated yt-dlp/i.test(out)) this.store.set('ytdlpChannel', CHANNEL);
          }).finally(() => (this._switching = null));
        }
        await this._switching;
        return this.exe;
      }
      this._maybeUpdate();
      return this.exe;
    }
    if (!this._ensuring) {
      this._ensuring = this._download().finally(() => {
        this._ensuring = null;
      });
    }
    return this._ensuring;
  }

  async _download() {
    fs.mkdirSync(this.binDir, { recursive: true });
    const url = RELEASE + ASSET;
    this.log('ytdlp: downloading', url);
    this.onStatus({ state: 'downloading', progress: 0 });
    const res = await fetch(url, { redirect: 'follow' });
    if (!res.ok || !res.body) {
      this.onStatus({ state: 'error', message: `Download failed (${res.status})` });
      throw new Error(`Could not download the playback engine (HTTP ${res.status})`);
    }
    const total = Number(res.headers.get('content-length')) || 0;
    let got = 0;
    const tmp = this.exe + '.part';
    const counter = new (require('stream').Transform)({
      transform: (chunk, _enc, cb) => {
        got += chunk.length;
        if (total) this.onStatus({ state: 'downloading', progress: got / total });
        cb(null, chunk);
      },
    });
    await pipeline(Readable.fromWeb(res.body), counter, fs.createWriteStream(tmp));
    fs.renameSync(tmp, this.exe);
    if (process.platform !== 'win32') fs.chmodSync(this.exe, 0o755);
    this.store.set('ytdlpUpdatedAt', Date.now());
    this.store.set('ytdlpChannel', CHANNEL);
    this.onStatus({ state: 'ready' });
    this.log('ytdlp: installed');
    return this.exe;
  }

  _maybeUpdate(force = false) {
    const last = this.store.get('ytdlpUpdatedAt', 0);
    if (!force && Date.now() - last < UPDATE_EVERY_MS) return Promise.resolve(null);
    this.store.set('ytdlpUpdatedAt', Date.now());
    return new Promise((resolve) => {
      const p = spawn(this.exe, ['--update-to', CHANNEL], { windowsHide: true, env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' } });
      let out = '';
      p.stdout.on('data', (d) => (out += d));
      p.stderr.on('data', (d) => (out += d));
      p.on('close', () => {
        this.log('ytdlp: update check:', out.trim().split('\n').pop());
        resolve(out.trim());
      });
      p.on('error', () => resolve(null));
    });
  }

  update() {
    return this._maybeUpdate(true);
  }

  _run(args, timeoutMs = 45000) {
    return new Promise((resolve, reject) => {
      const env = { ...process.env, ELECTRON_RUN_AS_NODE: '1', PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' };
      const p = spawn(this.exe, args, { windowsHide: true, env });
      let out = '';
      let err = '';
      const t = setTimeout(() => {
        p.kill();
        reject(new Error('The playback engine took too long to respond'));
      }, timeoutMs);
      p.stdout.on('data', (d) => (out += d));
      p.stderr.on('data', (d) => (err += d));
      p.on('error', (e) => {
        clearTimeout(t);
        reject(e);
      });
      p.on('close', (code) => {
        clearTimeout(t);
        if (code === 0) resolve(out);
        else reject(new Error(cleanError(err) || `yt-dlp exited with code ${code}`));
      });
    });
  }

  // Returns a direct audio URL (+ the headers YouTube expects) for a video.
  async resolve(videoId) {
    const hit = this.cache.get(videoId);
    if (hit && hit.expires - Date.now() > 10 * 60 * 1000) return hit;
    if (this.inflight.has(videoId)) return this.inflight.get(videoId);
    const job = (async () => {
      await this.ensure();
      const { raw, family, method } = await this._extract(videoId);
      const info = JSON.parse(raw);
      const fmt = (info.requested_formats && info.requested_formats[0]) || info;
      const url = fmt.url || info.url;
      if (!url) throw new Error('No playable audio found for this track');
      if (/m3u8/i.test(`${fmt.protocol || ''} ${url}`)) throw new Error('YouTube only offered this song as a streaming playlist, which can’t be played');
      const expireParam = Number(new URL(url).searchParams.get('expire'));
      const entry = {
        url,
        headers: fmt.http_headers || info.http_headers || {},
        mime: fmt.ext === 'webm' ? 'audio/webm' : 'audio/mp4',
        expires: expireParam ? expireParam * 1000 : Date.now() + 3 * 3600 * 1000,
        duration: info.duration || null,
        family, // fetch the stream over the same kind of address (IPv4/IPv6) as the lookup
        method,
      };
      this.cache.set(videoId, entry);
      return entry;
    })().finally(() => this.inflight.delete(videoId));
    this.inflight.set(videoId, job);
    return job;
  }

  _strategy() {
    const m = this.store.get('ytStrategy', null);
    if (!m || Date.now() - m.at > 6 * 3600e3) return 0;
    return Math.max(0, STRATEGIES.findIndex((x) => x.name === m.name));
  }

  cookiesFile() {
    const f = this.store.get('cookiesFile', null);
    return f && fs.existsSync(f) ? f : null;
  }

  // Blocked recently? Background work (warming up the next song) waits until this passes.
  blocked() {
    return Date.now() < (this.botUntil || 0);
  }

  async _extract(videoId) {
    const first = this._strategy();
    // While YouTube is blocking this connection, one attempt per song: going through
    // every method again only adds to the traffic that keeps the block going.
    const order = this.blocked() ? [first] : [first, ...STRATEGIES.map((_, i) => i).filter((i) => i !== first)];
    let lastErr = null;
    for (const i of order) {
      const args = [
        '--no-playlist',
        '--no-warnings',
        // Plain audio files only: some songs also come as HLS playlists (m3u8), which the player can't read.
        '-f', 'bestaudio[ext=m4a][protocol^=http]/bestaudio[acodec=opus][protocol^=http]/bestaudio[protocol^=http]/best[protocol^=http]',
        '--js-runtimes', `node:${process.execPath}`,
        ...STRATEGIES[i].args,
        ...(this.cookiesFile() ? ['--cookies', this.cookiesFile()] : []),
        '-J',
        `https://music.youtube.com/watch?v=${videoId}`,
      ];
      try {
        let raw;
        try {
          raw = await this._run(args);
        } catch (e) {
          // Older/newer yt-dlp builds may not accept the runtime flag; retry plainly.
          if (!/js-runtimes|no such option/i.test(e.message)) throw e;
          raw = await this._run(args.filter((a, j) => a !== '--js-runtimes' && args[j - 1] !== '--js-runtimes'));
        }
        if (i !== first) {
          this.log('ytdlp: now using the', STRATEGIES[i].name, 'method (the previous one stopped working)');
          this.store.set('ytStrategy', { name: STRATEGIES[i].name, at: Date.now() });
        }
        this.botUntil = 0;
        return { raw, family: STRATEGIES[i].family || 0, method: STRATEGIES[i].name };
      } catch (e) {
        if (!lastErr || lastErr.message !== BOT_MESSAGE) lastErr = e;
        this.log('ytdlp:', STRATEGIES[i].name, 'method failed:', e.message.slice(0, 120));
        if (e.message !== BOT_MESSAGE && isFinalError(e.message)) throw e; // a real problem with this song, not the bot check
      }
    }
    this.botUntil = Date.now() + 15 * 60e3;
    this.log('ytdlp: YouTube bot check on every method - backing off for 15 minutes');
    if (Date.now() - (this.store.get('ytdlpUpdatedAt', 0) || 0) > 6 * 3600e3) this._maybeUpdate(true);
    if (lastErr && lastErr.message !== BOT_MESSAGE) {
      this.log('ytdlp: every method failed, last error:', lastErr.message);
      throw Object.assign(new Error(BROKEN_MESSAGE), { botCheck: true });
    }
    throw Object.assign(lastErr || new Error(BOT_MESSAGE), { botCheck: true });
  }

  // YouTube keeps refusing the streams this method gives (even fresh ones): switch to the next method.
  nextStrategy() {
    if (this.blocked()) return; // nothing works right now; don't churn through methods
    const i = (this._strategy() + 1) % STRATEGIES.length;
    this.store.set('ytStrategy', { name: STRATEGIES[i].name, at: Date.now() });
    this.log('ytdlp: streams keep being refused - switching to the', STRATEGIES[i].name, 'method');
    (this.cache || this.infoCache).clear();
  }

  invalidate(videoId) {
    this.cache.delete(videoId);
  }
}

function cleanError(s) {
  const lines = String(s)
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => /^ERROR/.test(l));
  const msg = (lines[0] || String(s).trim().split('\n').pop() || '').replace(/^ERROR:\s*/, '');
  if (isBotCheck(msg)) return BOT_MESSAGE;
  return msg.slice(0, 300);
}

module.exports = { YtDlp, cleanError, isBotCheck, BOT_MESSAGE, STRATEGIES };
