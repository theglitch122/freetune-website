// Keeps whole songs on this PC so they start instantly: the song after the one playing
// and the one before it are downloaded in the background while you listen. Songs are
// fetched in pieces (YouTube slows one long request to a crawl), saved as
// <videoId>.<ext>, and the oldest are cleared out once the folder passes its size limit.

const fs = require('fs');
const path = require('path');
const { streamRequest } = require('./httpstream');

const PIECE = 4 << 20; // 4 MB
const LIMIT = 600e6; // keep up to ~600 MB of songs

class AudioCache {
  // limit: how much to keep before the oldest are cleared out (Infinity for downloads,
  // which are only removed when you remove them).
  constructor({ dir, ytdlp, log = console.log, limit = LIMIT }) {
    this.dir = dir;
    this.limit = limit;
    this.ytdlp = ytdlp;
    this.log = log;
    this.jobs = new Map(); // videoId -> promise
    fs.mkdirSync(dir, { recursive: true });
    for (const f of fs.readdirSync(dir)) {
      const p = path.join(dir, f);
      // unfinished downloads, and anything too small to be a song (a playlist saved by 1.7.0)
      if (f.endsWith('.part') || fs.statSync(p).size < 32 * 1024) fs.rmSync(p, { force: true });
    }
    this.prune();
  }

  // Path of a fully downloaded song, or null.
  file(videoId) {
    for (const ext of ['webm', 'm4a']) {
      const p = path.join(this.dir, `${videoId}.${ext}`);
      if (fs.existsSync(p)) {
        try {
          const now = new Date();
          fs.utimesSync(p, now, now); // recently played songs are kept longest
        } catch {}
        return p;
      }
    }
    return null;
  }

  downloading(videoId) {
    return this.jobs.has(videoId);
  }

  // Download a song in the background (once, even if asked several times).
  fetch(videoId) {
    if (this.file(videoId)) return Promise.resolve(this.file(videoId));
    if (this.jobs.has(videoId)) return this.jobs.get(videoId);
    const job = this._download(videoId)
      .catch((e) => {
        this.log('cache: could not save', videoId, '-', e.message);
        return null;
      })
      .finally(() => this.jobs.delete(videoId));
    this.jobs.set(videoId, job);
    return job;
  }

  async _download(videoId) {
    const started = Date.now();
    for (let attempt = 0; attempt < 2; attempt++) {
      const entry = await this.ytdlp.resolve(videoId);
      const ext = entry.mime === 'audio/webm' ? 'webm' : 'm4a';
      const final = path.join(this.dir, `${videoId}.${ext}`);
      const part = `${final}.part`;
      const out = fs.openSync(part, 'w');
      let pos = 0;
      let total = null;
      let refused = false;
      try {
        while (total == null || pos < total) {
          const headers = { ...entry.headers, Range: `bytes=${pos}-${pos + PIECE - 1}` };
          delete headers['Accept-Encoding'];
          const res = await streamRequest(entry.url, { headers, family: entry.family || 0, timeoutMs: 20000 });
          if (res.status === 403 || res.status === 410) {
            res.cancel();
            refused = true;
            break;
          }
          if (res.status !== 206 && res.status !== 200) {
            res.cancel();
            throw new Error(`YouTube answered ${res.status}`);
          }
          const m = /\/(\d+)\s*$/.exec(res.headers.get('content-range') || '');
          total = m ? Number(m[1]) : Number(res.headers.get('content-length')) || 0;
          let got = 0;
          for await (const chunk of res.body) {
            fs.writeSync(out, chunk);
            got += chunk.length;
          }
          if (!got) throw new Error('empty piece');
          pos += got;
          if (res.status === 200) break; // the whole file came at once
        }
      } finally {
        fs.closeSync(out);
      }
      if (refused) {
        fs.rmSync(part, { force: true });
        this.ytdlp.invalidate(videoId);
        continue;
      }
      // Never keep a playlist or error page in place of a song.
      const head = Buffer.alloc(16);
      const fd = fs.openSync(part, 'r');
      fs.readSync(fd, head, 0, 16, 0);
      fs.closeSync(fd);
      if (/#EXTM3U|<html|<\?xml/i.test(head.toString('latin1')) || pos < 32 * 1024) {
        fs.rmSync(part, { force: true });
        throw new Error('what YouTube sent wasn’t an audio file');
      }
      fs.renameSync(part, final);
      this.log(`cache: saved ${videoId} (${Math.round(pos / 1024)} KB in ${((Date.now() - started) / 1000).toFixed(1)}s)`);
      this.prune();
      return final;
    }
    throw new Error('YouTube refused the download');
  }

  prune() {
    try {
      const files = fs.readdirSync(this.dir).filter((f) => !f.endsWith('.part')).map((f) => {
        const p = path.join(this.dir, f);
        const s = fs.statSync(p);
        return { p, size: s.size, t: s.mtimeMs };
      });
      let total = files.reduce((a, f) => a + f.size, 0);
      for (const f of files.sort((a, b) => a.t - b.t)) {
        if (total <= this.limit) break;
        fs.rmSync(f.p, { force: true });
        total -= f.size;
      }
    } catch {}
  }

  remove(videoId) {
    for (const ext of ['webm', 'm4a']) fs.rmSync(path.join(this.dir, `${videoId}.${ext}`), { force: true });
  }

  // Bytes used by finished songs.
  usage() {
    let total = 0;
    try {
      for (const f of fs.readdirSync(this.dir)) if (!f.endsWith('.part')) total += fs.statSync(path.join(this.dir, f)).size;
    } catch {}
    return total;
  }

  clear() {
    for (const f of fs.readdirSync(this.dir)) if (!this.jobs.size || !f.endsWith('.part')) fs.rmSync(path.join(this.dir, f), { force: true });
  }
}

module.exports = { AudioCache };
