// Podcast episodes, played from the show's own public feed instead of from Spotify.
//
// Almost every podcast publishes a public RSS feed (that's how Apple Podcasts, Pocket Casts
// and every other app gets them). FreeTune finds the show's feed through Apple's public
// podcast directory (no account, nothing about you is sent, just the show's name), reads the
// feed, picks the same episode by its title, date and length, and plays the audio straight
// from the podcast's own host. Spotify is never asked for the audio and is never told what
// you play or how far you got.
//
// Many feeds wrap their audio links in "measurement" redirects (several are run by Spotify
// itself: Podsights, Chartable, Megaphone's prefix). Those are stripped off so the request
// goes straight to the podcast's host.

const ITUNES_SEARCH = 'https://itunes.apple.com/search';
const FEED_TTL = 3 * 3600 * 1000;
const UA = 'FreeTune/podcast-player (+https://github.com/)';

// Measurement/redirect prefixes put in front of the real audio address. Each pattern
// matches the prefix; what follows it is the real address (scheme added back if missing).
const TRACKING_PREFIXES = [
  /^https?:\/\/(?:www\.)?dts\.podtrac\.com\/redirect\.(?:mp3|m4a|aac)\//i,
  /^https?:\/\/(?:www\.)?podtrac\.com\/pts\/redirect\.(?:mp3|m4a|aac)\//i,
  /^https?:\/\/(?:www\.)?chtbl\.com\/track\/[^/]+\//i, // Chartable (Spotify)
  /^https?:\/\/(?:www\.)?chrt\.fm\/track\/[^/]+\//i, // Chartable (Spotify)
  /^https?:\/\/(?:www\.)?pdst\.fm\/e\//i, // Podsights (Spotify)
  /^https?:\/\/prfx\.byspotify\.com\/e\//i, // Spotify's own prefix
  /^https?:\/\/(?:www\.)?pfx\.vpixl\.com\/[^/]+\//i,
  /^https?:\/\/(?:www\.)?op3\.dev\/e(?:,[^/]*)?\//i,
  /^https?:\/\/(?:www\.)?mgln\.ai\/e\/[^/]+\//i,
  /^https?:\/\/(?:www\.)?arttrk\.com\/p\/[^/]+\//i,
  /^https?:\/\/(?:www\.)?pscrb\.fm\/rss\/p\//i,
  /^https?:\/\/(?:www\.)?verifi\.podscribe\.com\/rss\/p\//i,
  /^https?:\/\/(?:www\.)?clrtpod\.com\/m\/[^/]+\//i,
  /^https?:\/\/(?:www\.)?claritaspod\.com\/measure\//i,
  /^https?:\/\/(?:www\.)?tracking\.swap\.fm\/track\/[^/]+\//i,
  /^https?:\/\/(?:www\.)?ads\.blubrry\.com\/[^/]+\//i,
  /^https?:\/\/(?:www\.)?media\.blubrry\.com\/[^/]+\//i,
  /^https?:\/\/(?:www\.)?growx\.podkite\.com\/[^/]+\/[^/]+\//i,
  /^https?:\/\/(?:www\.)?pod\.chtbl\.com\/track\/[^/]+\//i,
  /^https?:\/\/(?:www\.)?zencastr\.com\/r\//i,
];

// The real address behind a feed's audio link, with measurement redirects removed.
function unwrap(url) {
  let u = String(url || '').trim();
  for (let i = 0; i < 8; i++) {
    const p = TRACKING_PREFIXES.find((re) => re.test(u));
    if (!p) break;
    let rest = u.replace(p, '');
    if (!/^https?:\/\//i.test(rest)) rest = (/^https:/i.test(u) || !/^http:/i.test(u) ? 'https://' : 'http://') + rest.replace(/^\/+/, '');
    try {
      new URL(rest);
    } catch {
      break;
    }
    u = rest;
  }
  return u;
}

// ── tiny RSS reading (podcast feeds are simple and very consistent) ─────────────
const decode = (s) =>
  String(s || '')
    .replace(/^\s*<!\[CDATA\[([\s\S]*?)\]\]>\s*$/, '$1')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#0*39;|&apos;/g, "'")
    .replace(/&#x([0-9a-f]+);/gi, (_, x) => String.fromCodePoint(parseInt(x, 16)))
    .replace(/&#(\d+);/g, (_, x) => String.fromCodePoint(Number(x)))
    .replace(/&amp;/g, '&')
    .trim();

function tag(xml, name) {
  const re = new RegExp(`<${name.replace(':', '\\:')}(?:\\s[^>]*)?>([\\s\\S]*?)</${name.replace(':', '\\:')}>`, 'i');
  const m = re.exec(xml);
  return m ? decode(m[1]) : '';
}

function attr(xml, name, a) {
  const m = new RegExp(`<${name.replace(':', '\\:')}\\b([^>]*)>`, 'i').exec(xml);
  if (!m) return '';
  const v = new RegExp(`\\b${a}\\s*=\\s*("([^"]*)"|'([^']*)')`, 'i').exec(m[1]);
  return v ? decode(v[2] != null ? v[2] : v[3]) : '';
}

function parseDuration(s) {
  s = String(s || '').trim();
  if (!s) return 0;
  if (/^\d+(\.\d+)?$/.test(s)) return Math.round(Number(s) * 1000);
  const parts = s.split(':').map(Number);
  if (parts.some((n) => !Number.isFinite(n))) return 0;
  return Math.round(parts.reduce((t, n) => t * 60 + n, 0) * 1000);
}

function parseFeed(xml) {
  const channel = (/<channel\b[\s\S]*?(?=<item\b)/i.exec(xml) || [xml.slice(0, 20000)])[0];
  const items = [];
  const re = /<item\b[\s\S]*?<\/item>/gi;
  let m;
  while ((m = re.exec(xml)) && items.length < 5000) {
    const it = m[0];
    const url = attr(it, 'enclosure', 'url');
    if (!url) continue;
    const pub = tag(it, 'pubDate');
    items.push({
      title: tag(it, 'title') || tag(it, 'itunes:title'),
      url,
      type: attr(it, 'enclosure', 'type'),
      date: pub ? Date.parse(pub) || 0 : 0,
      durationMs: parseDuration(tag(it, 'itunes:duration')),
      guid: tag(it, 'guid'),
      episode: Number(tag(it, 'itunes:episode')) || null,
    });
  }
  return { title: tag(channel, 'title'), author: tag(channel, 'itunes:author'), items };
}

// ── matching ────────────────────────────────────────────────────────────────────
const norm = (s) =>
  String(s || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/&/g, ' and ')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .replace(/\b(the|a|an|podcast|show|with)\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

function similarity(a, b) {
  a = norm(a);
  b = norm(b);
  if (!a || !b) return 0;
  if (a === b) return 1;
  if (a.includes(b) || b.includes(a)) return 0.85 * (Math.min(a.length, b.length) / Math.max(a.length, b.length)) + 0.15;
  const wa = new Set(a.split(' '));
  const wb = new Set(b.split(' '));
  let common = 0;
  for (const w of wa) if (wb.has(w)) common++;
  return (2 * common) / (wa.size + wb.size);
}

// Episode titles often carry numbers ("#412", "Ep. 12"); those must agree.
const numbersIn = (s) => (String(s).match(/\d+/g) || []).filter((n) => n.length < 6);

function scoreEpisode(ep, item) {
  let s = similarity(ep.name, item.title) * 70;
  const a = numbersIn(ep.name);
  const b = numbersIn(item.title);
  if (a.length && b.length) s += a.some((n) => b.includes(n)) ? 8 : -25;
  const when = Date.parse(ep.releaseDate || '') || 0;
  if (when && item.date) {
    const days = Math.abs(when - item.date) / 864e5;
    s += days <= 1.5 ? 20 : days <= 4 ? 10 : days <= 30 ? 0 : -15;
  }
  if (ep.durationMs && item.durationMs) {
    const diff = Math.abs(ep.durationMs - item.durationMs) / Math.max(ep.durationMs, item.durationMs);
    // Feeds often carry a slightly different cut (ads stitched in or not).
    s += diff < 0.04 ? 10 : diff < 0.15 ? 4 : diff < 0.35 ? 0 : -10;
  }
  return s;
}

class Podcasts {
  constructor({ store, log = console.log, fetchImpl = (...a) => fetch(...a) }) {
    this.store = store; // remembers which feed belongs to which show
    this.log = log;
    this.fetch = fetchImpl;
    this.feeds = new Map(); // feedUrl -> { at, feed }
    this.inflight = new Map();
  }

  async _get(url, accept) {
    const ac = new AbortController();
    const t = setTimeout(() => ac.abort(), 20000);
    try {
      const r = await this.fetch(url, { headers: { 'User-Agent': UA, Accept: accept }, signal: ac.signal, redirect: 'follow' });
      if (!r.ok) throw Object.assign(new Error(`HTTP ${r.status}`), { status: r.status });
      return await r.text();
    } finally {
      clearTimeout(t);
    }
  }

  // The show's public feed address: remembered, or found in Apple's public podcast directory.
  async feedFor(show) {
    const key = show.uri || show.name;
    const known = this.store.get(key);
    if (known && known.feedUrl) return known.feedUrl;
    if (known && known.none && Date.now() - known.at < 7 * 864e5) return null;
    const q = new URLSearchParams({ media: 'podcast', entity: 'podcast', limit: '15', term: show.name });
    const j = JSON.parse(await this._get(`${ITUNES_SEARCH}?${q}`, 'application/json'));
    let best = null;
    for (const r of j.results || []) {
      if (!r.feedUrl) continue;
      let s = similarity(show.name, r.collectionName) * 80;
      if (show.publisher && r.artistName) s += similarity(show.publisher, r.artistName) * 20;
      if (!best || s > best.s) best = { s, url: r.feedUrl, name: r.collectionName };
    }
    if (!best || best.s < 60) {
      this.log('podcasts: no public feed found for', show.name);
      this.store.set(key, { none: true, at: Date.now() });
      return null;
    }
    this.log('podcasts: feed for', show.name, '→', best.name);
    this.store.set(key, { feedUrl: best.url, at: Date.now() });
    return best.url;
  }

  async _feed(url, { fresh = false } = {}) {
    const hit = this.feeds.get(url);
    if (!fresh && hit && Date.now() - hit.at < FEED_TTL) return hit.feed;
    if (this.inflight.has(url)) return this.inflight.get(url);
    const job = this._get(url, 'application/rss+xml, application/xml, text/xml, */*')
      .then((xml) => {
        const feed = parseFeed(xml);
        this.feeds.set(url, { at: Date.now(), feed });
        if (this.feeds.size > 30) this.feeds.delete(this.feeds.keys().next().value);
        return feed;
      })
      .finally(() => this.inflight.delete(url));
    this.inflight.set(url, job);
    return job;
  }

  // The audio address of a Spotify episode, from the show's own feed. Returns null when the
  // show has no public feed (Spotify-only shows) or the episode isn't in it.
  async find(ep) {
    const show = ep.show || (ep.artists && ep.artists[0]) || {};
    if (!show.name) return null;
    const feedUrl = await this.feedFor(show);
    if (!feedUrl) return null;
    const pick = (feed) => {
      let best = null;
      for (const it of feed.items) {
        const s = scoreEpisode(ep, it);
        if (!best || s > best.s) best = { s, it };
      }
      return best && best.s >= 55 ? best : null;
    };
    let feed = await this._feed(feedUrl);
    let best = pick(feed);
    // A brand-new episode may not be in the copy read earlier.
    if (!best) {
      feed = await this._feed(feedUrl, { fresh: true });
      best = pick(feed);
    }
    if (!best) {
      this.log('podcasts: episode not in the feed:', ep.name);
      return null;
    }
    const url = unwrap(best.it.url);
    this.log('podcasts:', ep.name, '→', best.it.title, `(score ${Math.round(best.s)})`, url !== best.it.url ? '(measurement redirects removed)' : '');
    return { url, title: best.it.title, type: best.it.type || 'audio/mpeg', durationMs: best.it.durationMs };
  }

  forgetShow(show) {
    this.store.delete ? this.store.delete(show.uri || show.name) : this.store.set(show.uri || show.name, undefined);
  }
}

module.exports = { Podcasts, unwrap, parseFeed, scoreEpisode, similarity, UA };
