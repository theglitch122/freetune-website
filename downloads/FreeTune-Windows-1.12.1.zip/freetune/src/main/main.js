const { app, BrowserWindow, ipcMain, shell, nativeTheme, Menu, dialog, session } = require('electron');
const { Updater } = require('./updater');
const path = require('path');
const fs = require('fs');
const { JsonStore } = require('./store');
const { SpotifyClient } = require('./spotify');
const { YtDlp } = require('./ytdlp');
const { Matcher, parseYouTubeLink } = require('./youtube');
const { createAudioServer } = require('./audio-server');
const { Podcasts } = require('./podcasts');
const { Downloads } = require('./downloads');
const { YtMusic, isYtId } = require('./ytmusic');
const { streamRequest } = require('./httpstream');
const { AudioCache } = require('./audio-cache');
const { Lyrics } = require('./lyrics');

app.setAppUserModelId('com.freetune.app');
if (!app.requestSingleInstanceLock()) {
  app.quit();
  process.exit(0);
}

const userData = app.getPath('userData');
const resourcesDir = app.isPackaged ? path.join(process.resourcesPath, 'resources') : path.join(__dirname, '..', '..', 'resources');

// ── logging to a local file, to help troubleshoot ──────────────────────────────
const logFile = path.join(userData, 'freetune.log');
try {
  fs.mkdirSync(userData, { recursive: true });
  if (fs.existsSync(logFile) && fs.statSync(logFile).size > 1_000_000) fs.renameSync(logFile, logFile + '.old');
} catch {}
function log(...args) {
  const line = `[${new Date().toISOString()}] ${args.map((a) => (typeof a === 'string' ? a : JSON.stringify(a))).join(' ')}\n`;
  process.stdout.write(line);
  try {
    fs.appendFileSync(logFile, line);
  } catch {}
}

const settings = new JsonStore(userData, 'settings', { volume: 0.8, ytdlpUpdatedAt: 0 });
const matches = new JsonStore(userData, 'matches', {});
let win = null;
const { DiscordPresence } = require('./discord');
const discord = new DiscordPresence({ log, onStatus: (st) => win && !win.isDestroyed() && win.webContents.send('discord-status', st) });
const updater = new Updater({ app, appId: 'freetune', appName: 'FreeTune', log, onAvailable: (u) => win && !win.isDestroyed() && win.webContents.send('update-available', u) });

const spotify = new SpotifyClient({ userDataDir: userData, resourcesDir, log });
const ytdlp = new YtDlp({
  binDir: path.join(userData, 'bin'),
  store: settings,
  log,
  onStatus: (s) => win && !win.isDestroyed() && win.webContents.send('engine-status', s),
});
const matcher = new Matcher({ store: matches, log });
// Podcast episodes: which public feed belongs to which show, and how far you got in each
// episode. Both stay on this PC; Spotify is never told what you listen to.
const podcasts = new Podcasts({ store: new JsonStore(userData, 'podcast-feeds', {}), log });
const episodeProgress = new JsonStore(userData, 'episode-progress', {});
// A saved copy of what the screens last showed (home, your library, recent pages), so the
// app opens straight to them instead of loading bars. Stays on this PC.
const uiCache = new JsonStore(userData, 'ui-cache', {});
const ytmusic = new YtMusic({ log });
// YouTube Music playlists and albums you saved to Your Library (kept on this PC).
const ytLibrary = new JsonStore(userData, 'yt-library', { items: [] });
// YouTube Music songs you liked (Spotify can't hold them; kept on this PC, newest first).
const ytLiked = new JsonStore(userData, 'yt-liked', { tracks: [] });
const YT_TRACK_KEYS = ['type', 'uri', 'id', 'videoId', 'name', 'artists', 'album', 'image', 'imageLarge', 'durationMs', 'playable', 'video'];
function ytLike(track, on) {
  if (!track || !/^[\w-]{11}$/.test(String(track.videoId || ''))) throw new Error('Only YouTube Music songs can be liked here');
  const uri = `ytm:track:${track.videoId}`;
  const list = ytLiked.get('tracks', []).filter((t) => t.uri !== uri);
  if (on) {
    const t = {};
    for (const k of YT_TRACK_KEYS) if (track[k] != null) t[k] = track[k];
    list.unshift({ ...t, uri, type: 'ytm', addedAt: new Date().toISOString() });
  }
  ytLiked.set('tracks', list.slice(0, 20000));
  return list.length;
}
const downloadsStore = new JsonStore(userData, 'downloads', {});
let downloads = null;
let downloadCache = null;
const lyricsCache = new JsonStore(userData, 'lyrics', {});
const lyrics = new Lyrics({ store: lyricsCache, log });
const { LocalPlaylists, PlaylistExtras } = require('./local-playlists');
const localPlaylists = new LocalPlaylists(new JsonStore(userData, 'my-playlists', { lists: [] }));
const extrasStore = new JsonStore(userData, 'playlist-extras', { lists: {} });
const playlistExtras = new PlaylistExtras(extrasStore);
let audio = null;
let songCache = null;

function createWindow() {
  nativeTheme.themeSource = 'dark';
  win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#000000',
    title: 'FreeTune',
    icon: path.join(resourcesDir, 'icon.png'),
    titleBarStyle: 'hidden',
    titleBarOverlay: { color: '#000000', symbolColor: '#e9e9ee', height: 40 },
    show: false,
    webPreferences: {
      preload: path.join(__dirname, '..', 'preload.js'),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      backgroundThrottling: false, // keep the next track queued while minimized
    },
  });
  win.once('ready-to-show', () => {
    win.show();
    if (global.__bootOk) global.__bootOk(); // this version starts fine
  });
  // Closing the main window always quits FreeTune completely, including any hidden
  // Spotify helper windows, so nothing is left running in the background.
  win.on('closed', () => {
    win = null;
    quitCleanly();
  });
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  // Record everything the window reports, so problems show up in freetune.log.
  win.webContents.on('console-message', (e, level, message, line, sourceId) => {
    const lv = typeof e === 'object' && e && e.level != null ? e.level : level;
    const msg = typeof e === 'object' && e && e.message != null ? e.message : message;
    const ln = typeof e === 'object' && e && e.lineNumber != null ? e.lineNumber : line;
    const src = typeof e === 'object' && e && e.sourceId != null ? e.sourceId : sourceId;
    log(`renderer[${lv}]`, msg, `(${String(src || '').split(/[\\/]/).pop()}:${ln})`);
  });
  win.webContents.on('preload-error', (_e, p, err) => log('preload error', p, err && err.stack));
  win.webContents.on('did-fail-load', (_e, code, desc, url) => log('load failed', code, desc, url));
  win.webContents.on('render-process-gone', (_e, d) => log('renderer crashed', d.reason));
  win.webContents.on('before-input-event', (_e, input) => {
    if (input.type === 'keyDown' && (input.key === 'F12' || (input.control && input.shift && input.key.toLowerCase() === 'i'))) {
      win.webContents.toggleDevTools();
    }
  });
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
}

// Opening FreeTune while it's already running brings the existing window forward
// (or reopens it if it was closed) instead of showing an error.
app.on('second-instance', () => {
  if (!win || win.isDestroyed()) {
    createWindow();
    return;
  }
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
});

// Every IPC call returns { ok, data } or { ok: false, error, code } so the UI can
// show a friendly message instead of a broken screen.
function handle(channel, fn) {
  ipcMain.handle(channel, async (_e, ...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      log(`ipc ${channel} failed:`, e && e.message);
      return { ok: false, error: (e && e.message) || String(e), code: e && e.status };
    }
  });
}

function registerIpc() {
  handle('auth:status', async () => {
    const signedIn = await spotify.isSignedIn();
    if (!signedIn) return { signedIn: false };
    let user = null;
    try {
      user = await spotify.me();
    } catch (e) {
      if (e.status === 401) return { signedIn: false };
      throw e;
    }
    return { signedIn: true, user };
  });
  handle('auth:login', async () => {
    await spotify.login(win);
    return { signedIn: true, user: await spotify.me() };
  });
  handle('auth:logout', () => spotify.logout());

  handle('sp:home', () => spotify.home());
  handle('sp:playlists', () => spotify.libraryPlaylists());
  handle('sp:artists', () => spotify.libraryArtists());
  handle('sp:playlist', (id, offset) => spotify.playlistPage(id, offset || 0, 100));
  handle('sp:liked', (offset) => spotify.likedPage(offset || 0, 50));
  handle('sp:album', (id) => spotify.album(id));
  handle('sp:artist', (id) => spotify.artist(id));
  handle('sp:search', (q) => spotify.search(String(q || '').slice(0, 200)));
  handle('sp:setLiked', (uris, liked) => spotify.setLiked(uris, !!liked));
  handle('sp:show', (id, offset) => {
    if (!/^[A-Za-z0-9]{22}$/.test(String(id))) throw new Error('Not a valid podcast');
    return spotify.show(id, Number(offset) || 0);
  });
  handle('sp:episode', (id) => {
    if (!/^[A-Za-z0-9]{22}$/.test(String(id))) throw new Error('Not a valid episode');
    return spotify.episode(id);
  });
  handle('sp:shows', () => spotify.libraryShows());
  handle('sp:discography', (id) => {
    if (!/^[A-Za-z0-9]{22}$/.test(String(id))) throw new Error('Not a valid artist');
    return spotify.discography(id);
  });

  // ── YouTube Music's own catalog ──
  const ytId = (id) => {
    if (!isYtId(id)) throw new Error('Not a valid YouTube Music link');
    return String(id);
  };
  handle('yt:search', (q) => ytmusic.search(String(q || '').slice(0, 200)));
  handle('yt:artist', (id) => ytmusic.artist(ytId(id)));
  handle('yt:album', (id) => ytmusic.album(ytId(id)));
  handle('yt:playlist', (id) => ytmusic.playlist(ytId(id)));
  handle('yt:song', (link) => {
    const id = parseYouTubeLink(link);
    if (!id) throw new Error('That isn’t a YouTube or YouTube Music link');
    return ytmusic.song(id);
  });
  handle('yt:findArtist', (name) => ytmusic.findArtist(String(name || '')));
  handle('yt:liked', () => ytLiked.get('tracks', []));
  handle('yt:like', (track, on) => ytLike(track, !!on));
  handle('yt:library', () => ytLibrary.get('items', []));
  handle('yt:librarySave', (item) => {
    if (!item || !['ytplaylist', 'ytalbum'].includes(item.type)) throw new Error('Only YouTube Music playlists and albums can be saved');
    const clean = { type: item.type, id: ytId(item.id), name: String(item.name || '').slice(0, 200), image: typeof item.image === 'string' ? item.image : null, owner: String(item.owner || '').slice(0, 100), savedAt: Date.now() };
    const items = ytLibrary.get('items', []).filter((x) => !(x.type === clean.type && x.id === clean.id));
    items.unshift(clean);
    ytLibrary.set('items', items.slice(0, 500));
    return ytLibrary.get('items');
  });
  handle('yt:libraryRemove', (type, id) => {
    ytLibrary.set('items', ytLibrary.get('items', []).filter((x) => !(x.type === type && x.id === id)));
    return ytLibrary.get('items');
  });

  // Where you stopped in each episode (on this PC only), so long episodes pick up again.
  handle('ep:progress', (uri) => episodeProgress.get(String(uri), null));
  handle('ep:saveProgress', (uri, pos, dur) => {
    if (!/^spotify:episode:\w+$/.test(String(uri))) return false;
    const p = Number(pos) || 0;
    const d = Number(dur) || 0;
    // Finished (or nearly): forget it, so it starts from the beginning next time.
    if (!d || p < 15 || p > d - 30) episodeProgress.delete(uri);
    else episodeProgress.set(uri, { pos: Math.round(p), dur: Math.round(d), at: Date.now() });
    const keys = Object.keys(episodeProgress.data);
    if (keys.length > 500) {
      keys.sort((a, b) => (episodeProgress.data[a].at || 0) - (episodeProgress.data[b].at || 0));
      for (const k of keys.slice(0, keys.length - 500)) episodeProgress.delete(k);
    }
    return true;
  });

  // ── your own playlists: in your Spotify account, or only on this PC ──
  // `ref` is { local: true|false, id }.
  const isRef = (r) => r && typeof r.id === 'string' && /^[\w-]{6,64}$/.test(r.id);
  const uriList = (tracks) => (Array.isArray(tracks) ? tracks : []).map((t) => t && t.uri).filter((u) => /^spotify:(track|episode):[\w]+$/.test(u || '')).slice(0, 500);
  handle('pl:me', () => spotify.myId().catch(() => ''));
  handle('pl:local', () => localPlaylists.list());
  handle('pl:extras', () => playlistExtras.all());
  handle('pl:extrasAdd', (id, tracks) => playlistExtras.add(id, tracks));
  handle('pl:extrasRemove', (id, uris) => playlistExtras.remove(id, uris));
  handle('pl:localGet', (id) => localPlaylists.get(String(id)));
  handle('pl:create', async (name, description, where) => {
    const n = String(name || '').trim().slice(0, 100) || 'My playlist';
    const d = String(description || '').slice(0, 300);
    if (where === 'local') return localPlaylists.create(n, d);
    const p = await spotify.createPlaylist(n, d);
    log('playlists: created a Spotify playlist');
    return p;
  });
  handle('pl:edit', (ref, changes) => {
    if (!isRef(ref)) throw new Error('Not a valid playlist');
    const c = { name: changes && changes.name != null ? String(changes.name).trim().slice(0, 100) : undefined, description: changes && changes.description != null ? String(changes.description).slice(0, 300) : undefined };
    return ref.local ? localPlaylists.edit(ref.id, c) : spotify.editPlaylist(ref.id, c);
  });
  handle('pl:delete', (ref) => {
    if (!isRef(ref)) throw new Error('Not a valid playlist');
    return ref.local ? localPlaylists.remove(ref.id) : spotify.deletePlaylist(ref.id);
  });
  handle('pl:add', async (ref, tracks) => {
    if (!isRef(ref)) throw new Error('Not a valid playlist');
    if (ref.local) return localPlaylists.addTracks(ref.id, (Array.isArray(tracks) ? tracks : []).slice(0, 500));
    const uris = uriList(tracks);
    if (!uris.length) throw new Error('Those songs can’t be added to a Spotify playlist');
    await spotify.addToPlaylist(ref.id, uris);
    return { added: uris.length, skipped: 0 };
  });
  handle('pl:remove', (ref, uids) => {
    if (!isRef(ref)) throw new Error('Not a valid playlist');
    const list = (Array.isArray(uids) ? uids : []).map(String).filter(Boolean).slice(0, 500);
    return ref.local ? localPlaylists.removeTracks(ref.id, list) : spotify.removeFromPlaylist(ref.id, list);
  });
  handle('pl:move', (ref, uids, beforeUid) => {
    if (!isRef(ref)) throw new Error('Not a valid playlist');
    const list = (Array.isArray(uids) ? uids : []).map(String).filter(Boolean).slice(0, 500);
    const before = beforeUid ? String(beforeUid) : null;
    return ref.local ? localPlaylists.moveTracks(ref.id, list, before) : spotify.movePlaylistItems(ref.id, list, before);
  });

  // Find the YouTube match for a track and return a local URL the player can stream.
  handle('play:prepare', async (track, { warm = false } = {}) => {
    // Downloaded: plays from this PC with no internet needed.
    const dl = track && downloads.fileFor(track);
    if (dl && dl.kind === 'song') return { videoId: dl.id, src: `${audio.base}/audio/${dl.id}`, cached: true, downloaded: true };
    if (dl && dl.kind === 'episode') return { src: audio.addFile(episodeFile(dl.id)), downloaded: true };
    if (track && /^spotify:episode:/.test(track.uri || '')) return prepareEpisode(track, warm);
    if (warm && ytdlp.blocked()) return null; // don't poke YouTube while it's blocking us
    const m = await matcher.find(track);
    // Already saved on this PC: starts instantly, no need to ask YouTube anything.
    if (songCache.file(m.videoId)) return { videoId: m.videoId, score: m.score, src: `${audio.base}/audio/${m.videoId}`, cached: true };
    if (warm) ytdlp.resolve(m.videoId).catch(() => {});
    // Look the stream up and make sure YouTube will send it, so a real reason (like the
    // bot check) reaches the player instead of a vague "format error". Cached for the audio server.
    else await audio.check(m.videoId);
    return { videoId: m.videoId, score: m.score, src: `${audio.base}/audio/${m.videoId}` };
  });
  // A podcast episode: from the show's own public feed, or (for shows that only post on
  // YouTube) a close YouTube match. Never streamed from Spotify.
  async function prepareEpisode(ep, warm) {
    let found = null;
    try {
      found = await podcasts.find(ep);
    } catch (e) {
      log('podcasts: feed lookup failed for', ep.name, '-', e.message);
    }
    if (found) return { src: audio.addEpisode(ep.uri, found.url), feed: true };
    if (warm) return null;
    const yt = await matcher.findEpisode(ep).catch((e) => {
      log('podcasts: YouTube search failed', e.message);
      return null;
    });
    if (yt) {
      await audio.check(yt.videoId);
      return { videoId: yt.videoId, score: yt.score, src: `${audio.base}/audio/${yt.videoId}` };
    }
    throw new Error('this show is only on Spotify (it has no public feed), so FreeTune can’t play it without streaming from Spotify');
  }

  // Save the songs around the one playing (next first, then previous) so skipping is instant.
  let preloadSeq = 0;
  handle('play:preload', async (tracks) => {
    const mine = ++preloadSeq;
    for (const t of (Array.isArray(tracks) ? tracks : []).slice(0, 3)) {
      if (mine !== preloadSeq || ytdlp.blocked()) return false; // the queue moved on, or YouTube is blocking
      if (!t || t.playable === false || !t.name) continue;
      // Episodes are long: they stream from the podcast's host instead of being saved ahead.
      // Their feed is looked up now, so they still start right away.
      if (/^spotify:episode:/.test(t.uri || '')) {
        await podcasts.find(t).catch(() => null);
        continue;
      }
      try {
        const m = await matcher.find(t);
        await songCache.fetch(m.videoId);
      } catch (e) {
        log('preload: skipped', t.name, '-', e.message);
      }
    }
    return true;
  });
  handle('play:override', (uri, link) => {
    const id = parseYouTubeLink(link);
    if (!id) throw new Error('That doesn’t look like a YouTube link');
    matcher.setManual(uri, id);
    downloads.replaced(uri);
    return { videoId: id, src: `${audio.base}/audio/${id}` };
  });

  // ── downloads ──
  handle('dl:status', () => downloads.status());
  handle('dl:list', () => downloads.list());
  handle('dl:set', (key, info, tracks) => downloads.set(String(key), info || {}, tracks));
  handle('dl:remove', (key) => downloads.remove(String(key)));
  handle('dl:removeAll', () => downloads.removeAll());
  handle('dl:tracks', (key) => downloads.tracks(String(key)));
  handle('dl:usage', () => downloads.usage());
  handle('dl:openFolder', () => shell.openPath(path.join(userData, 'downloads')));

  // ── the saved copy of the screens ──
  handle('ui:cacheGet', () => uiCache.data);
  handle('ui:cacheSet', (data) => {
    if (!data || typeof data !== 'object') {
      uiCache.clear();
      return true;
    }
    uiCache.data = data;
    uiCache.saveSoon();
    return true;
  });

  handle('lyrics:get', async (track, { refresh = false } = {}) => {
    if (track && /^spotify:episode:/.test(track.uri || '')) return { episode: true }; // nothing is looked up for podcasts
    if (refresh) lyrics.forget(track);
    const m = matcher.cached(track.uri);
    return lyrics.get(track, track.videoId || (m && m.videoId));
  });

  handle('engine:status', () => ({ installed: ytdlp.installed() }));
  handle('engine:ensure', () => ytdlp.ensure().then(() => true));
  handle('engine:update', () => ytdlp.update());

  // Last resort for repeated bot checks: a cookies.txt exported from a spare Google
  // account. Kept in FreeTune's own folder and only sent to YouTube by the engine.
  handle('cookies:status', () => !!ytdlp.cookiesFile());
  handle('cookies:choose', async () => {
    const r = await dialog.showOpenDialog(win, {
      title: 'Choose a cookies.txt file (from a spare Google account)',
      filters: [{ name: 'Cookies file', extensions: ['txt'] }],
      properties: ['openFile'],
    });
    if (r.canceled || !r.filePaths[0]) return null;
    const text = fs.readFileSync(r.filePaths[0], 'utf8');
    if (!/^# (Netscape )?HTTP Cookie File/m.test(text) && !/\tTRUE\t|\tFALSE\t/.test(text)) throw new Error('That doesn’t look like a cookies.txt file. Export one with a “Get cookies.txt” style browser extension.');
    if (!/youtube\.com/.test(text)) throw new Error('That cookies file has no YouTube cookies in it. Export it while on youtube.com.');
    const dest = path.join(userData, 'cookies.txt');
    fs.writeFileSync(dest, text);
    settings.set('cookiesFile', dest);
    ytdlp.botUntil = 0;
    ytdlp.cache.clear();
    return true;
  });
  handle('cookies:clear', () => {
    const f = settings.get('cookiesFile', null);
    if (f) fs.rmSync(f, { force: true });
    settings.set('cookiesFile', null);
    ytdlp.cache.clear();
    return true;
  });

  handle('settings:get', (k) => settings.get(k));
  handle('settings:set', (k, v) => {
    if (['volume', 'shuffle', 'repeat', 'lastQueue', 'discordEnabled', 'discordClientId'].includes(k)) settings.set(k, v);
    if (k === 'discordEnabled' || k === 'discordClientId') {
      discord.configure({ enabled: settings.get('discordEnabled', false), clientId: settings.get('discordClientId', '') });
    }
    return true;
  });
  handle('app:clearMatches', () => matcher.clear());
  handle('app:openLogs', () => shell.showItemInFolder(logFile));
  handle('app:openExternal', (url) => {
    if (/^https:\/\//.test(url)) shell.openExternal(url);
  });
  handle('app:version', () => global.__APP_VERSION__ || app.getVersion());
  // ── updates ──
  handle('update:check', () => updater.check());
  handle('update:pick', async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Choose an update file', filters: [{ name: 'FreeTune update', extensions: ['update'] }], properties: ['openFile'] });
    if (r.canceled || !r.filePaths[0]) return null;
    return updater.checkFile(r.filePaths[0]);
  });
  handle('update:apply', async () => {
    await updater.apply();
    setTimeout(() => quitCleanly(), 300);
    return true;
  });

}

app.whenReady().then(async () => {
  Menu.setApplicationMenu(null);
  log('FreeTune', global.__APP_VERSION__ || app.getVersion(), 'starting on', process.platform, process.getSystemVersion());
  spotify.setupSession();
  songCache = new AudioCache({ dir: path.join(app.getPath('userData'), 'song-cache'), ytdlp, log });
  downloadCache = new AudioCache({ dir: path.join(userData, 'downloads', 'songs'), ytdlp, log, limit: Infinity });
  fs.mkdirSync(path.join(userData, 'downloads', 'episodes'), { recursive: true });
  // Songs you downloaded first, then the ones saved ahead while listening.
  const anyCache = { file: (id) => downloadCache.file(id) || songCache.file(id) };
  audio = await createAudioServer({ ytdlp, cache: anyCache, log });
  downloads = new Downloads({
    store: downloadsStore,
    matcher,
    podcasts,
    log,
    onChange: (st) => win && !win.isDestroyed() && win.webContents.send('downloads-change', st),
    storage: {
      hasSong: (id) => !!downloadCache.file(id),
      // A song already saved ahead while listening is copied over instead of downloaded again.
      fetchSong: async (id) => {
        const ahead = songCache.file(id);
        if (ahead) {
          fs.copyFileSync(ahead, path.join(downloadCache.dir, path.basename(ahead)));
          return true;
        }
        return !!(await downloadCache.fetch(id));
      },
      removeSong: (id) => downloadCache.remove(id),
      hasEpisode: (key) => fs.existsSync(episodeFile(key)),
      fetchEpisode: (key, url) => saveEpisode(key, url),
      removeEpisode: (key) => fs.rmSync(episodeFile(key), { force: true }),
      usage: () => {
        let n = downloadCache.usage();
        try {
          const d = path.join(userData, 'downloads', 'episodes');
          for (const f of fs.readdirSync(d)) n += fs.statSync(path.join(d, f)).size;
        } catch {}
        return n;
      },
      paused: () => (ytdlp.blocked() ? 'YouTube is blocking downloads on this connection for now. They’ll carry on by themselves later.' : ''),
    },
  });
  setTimeout(() => downloads.resume(), 8000);
  registerIpc();
  createWindow();
  spotify.refreshHashes().catch(() => {});
  ytdlp.ensure().catch((e) => log('ytdlp ensure failed:', e.message));
  updater.watch();
  discord.configure({ enabled: settings.get('discordEnabled', false), clientId: settings.get('discordClientId', '') });
  handle('discord:update', (now) => discord.update(now));
  handle('discord:status', () => discord.status);
});

// Downloaded podcast episodes: <userData>/downloads/episodes/<episodeId>.audio
function episodeFile(key) {
  return path.join(userData, 'downloads', 'episodes', `${String(key).replace(/^ep:/, '').replace(/[^\w-]/g, '')}.audio`);
}
async function saveEpisode(key, url) {
  const final = episodeFile(key);
  const part = `${final}.part`;
  const res = await streamRequest(url, { headers: { 'User-Agent': 'FreeTune/podcast-player', Accept: 'audio/*,*/*;q=0.5' }, maxHops: 10, timeoutMs: 30000 });
  if (res.status !== 200 && res.status !== 206) {
    res.cancel();
    throw new Error(`the podcast’s server answered ${res.status}`);
  }
  const out = fs.createWriteStream(part);
  try {
    for await (const chunk of res.body) if (!out.write(chunk)) await new Promise((r) => out.once('drain', r));
    await new Promise((r, j) => out.end((e) => (e ? j(e) : r())));
  } catch (e) {
    out.destroy();
    fs.rmSync(part, { force: true });
    throw e;
  }
  if (fs.statSync(part).size < 64 * 1024) {
    fs.rmSync(part, { force: true });
    throw new Error('what the podcast’s server sent wasn’t an episode');
  }
  fs.renameSync(part, final);
  log('downloads: saved episode', key);
  return true;
}

let quitting = false;
function quitCleanly() {
  if (quitting) return;
  quitting = true;
  try { settings.saveNow(); matches.saveNow(); lyricsCache.saveNow(); uiCache.saveNow(); downloadsStore.saveNow(); episodeProgress.saveNow(); ytLibrary.saveNow(); ytLiked.saveNow(); extrasStore.saveNow(); } catch {}
  try { discord.shutdown(); } catch {}
  for (const w of BrowserWindow.getAllWindows()) {
    try { w.destroy(); } catch {}
  }
  try { audio && audio.server.close(); } catch {}
  app.quit();
  // Last resort: if something still holds the process open, force it to exit.
  setTimeout(() => app.exit(0), 3000).unref();
}
app.on('window-all-closed', quitCleanly);
process.on('uncaughtException', (e) => {
  log('main error:', e && e.stack);
  if (quitting) app.exit(0);
});
