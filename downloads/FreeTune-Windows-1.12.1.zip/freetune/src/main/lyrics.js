// Finds lyrics for the song that's playing, from free public sources, in this order:
//   1. LRCLIB (lrclib.net) — open, community-run database of time-synced lyrics
//   2. KuGou — large lyrics catalogue with time-synced lyrics, good for non-English songs
//   3. YouTube Music — the lyrics YouTube shows for the matched recording (not synced)
// Synced lyrics are preferred; plain lyrics are kept as a fallback. Approach adapted from
// Meld (GPL-3.0). No account or cookies are sent to any of these services.

const UA = 'FreeTune/1.0 (desktop music player)';
const TIMEOUT_MS = 9000;

async function getJson(url, opts = {}) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { ...opts, signal: ctrl.signal, headers: { 'User-Agent': UA, Accept: 'application/json', ...(opts.headers || {}) } });
    if (res.status === 404) return null;
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

// ── text helpers ───────────────────────────────────────────────────────────────
const NOISE = /\s*[([](?:[^)\]]*?)(?:official|video|audio|lyrics?|visuali[sz]er|remaster(?:ed)?|hd|hq|4k|explicit|clean|radio edit|mono|stereo)(?:[^)\]]*?)[)\]]/gi;

function cleanTitle(t) {
  return String(t || '')
    .replace(NOISE, '')
    .replace(/\s*[([]\s*(?:feat|ft|with)\.?\s[^)\]]*[)\]]/gi, '')
    .replace(/\s+-\s+(?:\d{4}\s+)?remaster(?:ed)?.*$/i, '')
    .replace(/\s+-\s+(?:live|radio edit|single version|mono|stereo).*$/i, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function norm(s) {
  return String(s || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim();
}

function similar(a, b) {
  a = norm(a);
  b = norm(b);
  if (!a || !b) return 0;
  if (a === b) return 1;
  if (a.includes(b) || b.includes(a)) return 0.85;
  const A = new Set(a.split(' '));
  const B = new Set(b.split(' '));
  let inter = 0;
  for (const w of A) if (B.has(w)) inter++;
  return inter / Math.max(A.size, B.size);
}

// ── LRC parsing ────────────────────────────────────────────────────────────────
// Handles multiple timestamps per line, [offset:], and strips word-level <mm:ss.xx> tags.
function parseLrc(text) {
  if (!text) return null;
  let offset = 0;
  const out = [];
  for (const raw of String(text).split(/\r?\n/)) {
    const off = /^\[offset:\s*([+-]?\d+)\s*]/i.exec(raw);
    if (off) {
      offset = Number(off[1]) / 1000;
      continue;
    }
    const stamps = [];
    let rest = raw;
    let m;
    const re = /^\s*\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]/;
    while ((m = re.exec(rest))) {
      const frac = m[3] ? Number(m[3]) / Math.pow(10, m[3].length) : 0;
      stamps.push(Number(m[1]) * 60 + Number(m[2]) + frac);
      rest = rest.slice(m[0].length);
    }
    if (!stamps.length) continue;
    const words = rest.replace(/<\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?>/g, '').replace(/\s+/g, ' ').trim();
    for (const s of stamps) out.push({ t: Math.max(0, s - offset), text: words });
  }
  out.sort((a, b) => a.t - b.t);
  // Drop credit lines at the very start (e.g. "Composer: …", "作词 : …").
  const CREDIT = /^\s*(?:作词|作曲|编曲|制作人?|词|曲|演唱|混音|和声|吉他|贝斯|鼓|composer|composed by|lyricist|lyrics by|written by|writer|producer|produced by|arranger|arranged by|mix(?:ed|ing)?(?: by)?|master(?:ed|ing)?(?: by)?|vocals?|guitar|bass|drums|keys)\s*[:：]/i;
  while (out.length && out[0].t < 30 && CREDIT.test(out[0].text)) out.shift();
  // Merge leading blank lines, keep inner blanks as instrumental breaks.
  while (out.length && !out[0].text) out.shift();
  const hasText = out.filter((l) => l.text).length;
  return hasText >= 2 ? out : null;
}

function plainToLines(text) {
  const lines = String(text || '')
    .replace(/\r/g, '')
    .split('\n')
    .map((l) => l.trim());
  while (lines.length && !lines[0]) lines.shift();
  while (lines.length && !lines[lines.length - 1]) lines.pop();
  return lines.filter(Boolean).length >= 2 ? lines.map((text) => ({ text })) : null;
}

// ── 1. LRCLIB ──────────────────────────────────────────────────────────────────
async function fromLrclib({ title, artist, album, durationSec }) {
  const pick = (rec) => {
    if (!rec || rec.instrumental) return rec && rec.instrumental ? { instrumental: true } : null;
    const synced = parseLrc(rec.syncedLyrics);
    if (synced) return { synced: true, lines: synced };
    const plain = plainToLines(rec.plainLyrics);
    return plain ? { synced: false, lines: plain } : null;
  };
  const q = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v != null && v !== '')).toString();

  // Exact lookup first (LRCLIB matches duration within ±2 s).
  if (durationSec) {
    try {
      const exact = await getJson(`https://lrclib.net/api/get?${q({ track_name: title, artist_name: artist, album_name: album, duration: Math.round(durationSec) })}`);
      const r = pick(exact);
      if (r && (r.synced || r.instrumental)) return r;
    } catch {
      /* fall through to search */
    }
  }
  const searches = [
    q({ track_name: title, artist_name: artist }),
    q({ q: `${artist} ${title}` }),
  ];
  let plainFallback = null;
  for (const s of searches) {
    let list;
    try {
      list = await getJson(`https://lrclib.net/api/search?${s}`);
    } catch {
      continue;
    }
    if (!Array.isArray(list) || !list.length) continue;
    const scored = list
      .map((rec) => {
        const dur = rec.duration && durationSec ? Math.abs(rec.duration - durationSec) : 0;
        const score =
          similar(rec.trackName, title) * 0.5 +
          similar(rec.artistName, artist) * 0.35 +
          (dur <= 2 ? 0.15 : dur <= 5 ? 0.1 : dur <= 10 ? 0.04 : -0.3) +
          (rec.syncedLyrics ? 0.05 : 0);
        return { rec, score };
      })
      .filter((x) => x.score >= 0.55)
      .sort((a, b) => b.score - a.score);
    for (const { rec } of scored) {
      const r = pick(rec);
      if (r && (r.synced || r.instrumental)) return r;
      if (r && !plainFallback) plainFallback = r;
    }
  }
  return plainFallback;
}

// ── 2. KuGou ───────────────────────────────────────────────────────────────────
async function fromKugou({ title, artist, durationSec }) {
  const keyword = `${title.replace(/[(（「『<《〈＜].*?[)）」』>》〉＞]/g, '').trim()} - ${artist}`;
  const params = new URLSearchParams({ ver: '1', man: 'yes', client: 'pc', keyword });
  if (durationSec) params.set('duration', String(Math.round(durationSec * 1000)));
  const res = await getJson(`https://lyrics.kugou.com/search?${params}`);
  const cands = (res && res.candidates) || [];
  const good = cands.filter((c) => !durationSec || !c.duration || Math.abs(c.duration / 1000 - durationSec) <= 8);
  for (const c of good.slice(0, 3)) {
    const dl = await getJson(
      `https://lyrics.kugou.com/download?${new URLSearchParams({ fmt: 'lrc', charset: 'utf8', client: 'pc', ver: '1', id: String(c.id), accesskey: c.accesskey })}`
    );
    if (!dl || !dl.content) continue;
    const text = Buffer.from(dl.content, 'base64').toString('utf8');
    const lines = parseLrc(text);
    if (lines) return { synced: true, lines };
  }
  return null;
}

// ── 3. YouTube Music (plain text) ──────────────────────────────────────────────
const YTM = 'https://music.youtube.com/youtubei/v1/';
const YTM_CTX = { client: { clientName: 'WEB_REMIX', clientVersion: '1.20250929.03.00', hl: 'en', gl: 'US' } };
async function ytm(endpoint, body) {
  return getJson(`${YTM}${endpoint}?prettyPrint=false`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
      Origin: 'https://music.youtube.com',
      Referer: 'https://music.youtube.com/',
    },
    body: JSON.stringify({ context: YTM_CTX, ...body }),
  });
}
function findKey(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 25) return undefined;
  if (key in obj) return obj[key];
  for (const k of Object.keys(obj)) {
    const r = findKey(obj[k], key, depth + 1);
    if (r !== undefined) return r;
  }
  return undefined;
}
async function fromYouTubeMusic({ videoId }) {
  if (!videoId) return null;
  const next = await ytm('next', { videoId, isAudioOnly: true });
  const tabs = findKey(next, 'tabs') || [];
  const tab = tabs.find((t) => {
    const be = t.tabRenderer && t.tabRenderer.endpoint && t.tabRenderer.endpoint.browseEndpoint;
    return be && /^MPLY/.test(be.browseId || '');
  });
  if (!tab) return null;
  const page = await ytm('browse', { browseId: tab.tabRenderer.endpoint.browseEndpoint.browseId });
  const shelf = findKey(page, 'musicDescriptionShelfRenderer');
  const runs = shelf && shelf.description && shelf.description.runs;
  if (!runs) return null;
  const lines = plainToLines(runs.map((r) => r.text).join(''));
  return lines ? { synced: false, lines } : null;
}

// ── orchestration with caching ─────────────────────────────────────────────────
class Lyrics {
  constructor({ store, log = console.log }) {
    this.store = store; // persistent cache: key -> result
    this.log = log;
    this.inflight = new Map();
  }

  async get(track, videoId) {
    const artist = (track.artists && track.artists[0] && track.artists[0].name) || '';
    const title = cleanTitle(track.name);
    const durationSec = track.durationMs ? track.durationMs / 1000 : null;
    const key = track.uri || `${norm(artist)}|${norm(title)}`;
    const hit = this.store.get(key, null);
    // Cached "not found" results expire after a week so newly added lyrics get picked up.
    if (hit && (hit.lines || hit.instrumental || Date.now() - (hit.at || 0) < 7 * 864e5)) return hit;
    if (this.inflight.has(key)) return this.inflight.get(key);

    const job = (async () => {
      const q = { title, artist, album: track.album && track.album.name, durationSec, videoId };
      let plain = null;
      const sources = [
        ['LRCLIB', fromLrclib],
        ['KuGou', fromKugou],
        ['YouTube Music', fromYouTubeMusic],
      ];
      for (const [name, fn] of sources) {
        try {
          const r = await fn(q);
          if (r && r.instrumental) return this._save(key, { instrumental: true, source: name });
          if (r && r.synced) return this._save(key, { ...r, source: name });
          if (r && !plain) plain = { ...r, source: name };
        } catch (e) {
          this.log(`lyrics: ${name} failed for "${artist} - ${title}":`, e.message);
        }
      }
      return this._save(key, plain || { none: true });
    })().finally(() => this.inflight.delete(key));
    this.inflight.set(key, job);
    return job;
  }

  _save(key, result) {
    const r = { ...result, at: Date.now() };
    this.store.set(key, r);
    // Keep the cache to the most recent ~600 songs.
    const keys = Object.keys(this.store.data);
    if (keys.length > 600) {
      keys
        .sort((a, b) => (this.store.data[a].at || 0) - (this.store.data[b].at || 0))
        .slice(0, keys.length - 600)
        .forEach((k) => this.store.delete(k));
    }
    return r;
  }

  forget(track) {
    const artist = (track.artists && track.artists[0] && track.artists[0].name) || '';
    this.store.delete(track.uri || `${norm(artist)}|${norm(cleanTitle(track.name))}`);
  }
}

module.exports = { Lyrics, parseLrc, cleanTitle, plainToLines, fromLrclib, fromKugou, fromYouTubeMusic };
