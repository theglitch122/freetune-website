// Discord Rich Presence: shows the song you're playing on your Discord profile.
// Talks only to the Discord app already running on this PC, through its local
// connection (a named pipe). Off unless you turn it on in Settings.

const net = require('net');
const path = require('path');

const OP = { HANDSHAKE: 0, FRAME: 1, CLOSE: 2, PING: 3, PONG: 4 };
const MIN_GAP_MS = 4500; // Discord allows ~5 updates per 20 seconds

function pipePath(i) {
  if (process.platform === 'win32') return `\\\\?\\pipe\\discord-ipc-${i}`;
  const base = process.env.XDG_RUNTIME_DIR || process.env.TMPDIR || process.env.TMP || process.env.TEMP || '/tmp';
  return path.join(base, `discord-ipc-${i}`);
}

function encode(op, data) {
  const json = Buffer.from(JSON.stringify(data));
  const head = Buffer.alloc(8);
  head.writeInt32LE(op, 0);
  head.writeInt32LE(json.length, 4);
  return Buffer.concat([head, json]);
}

const clip = (s, n = 128) => {
  s = String(s || '').trim();
  if (s.length < 2) s = (s + '  ').slice(0, 2); // Discord rejects 1-character strings
  return s.length > n ? s.slice(0, n - 1) + '…' : s;
};

class DiscordPresence {
  constructor({ log = console.log, onStatus = () => {} } = {}) {
    this.log = log;
    this.onStatus = onStatus;
    this.clientId = null;
    this.enabled = false;
    this.sock = null;
    this.ready = false;
    this.status = 'off';
    this.pending = undefined; // latest activity waiting to be sent (null = clear)
    this.lastSent = 0;
    this.sendTimer = null;
    this.retryTimer = null;
    this.retryMs = 5000;
    this.buf = Buffer.alloc(0);
  }

  configure({ enabled, clientId }) {
    const id = String(clientId || '').trim();
    const changed = id !== this.clientId || !!enabled !== this.enabled;
    this.enabled = !!enabled && /^\d{15,22}$/.test(id);
    this.clientId = id;
    if (!changed) return;
    this._disconnect();
    if (this.enabled) this._connect();
    else this._setStatus(enabled && id ? 'bad-id' : 'off');
  }

  _setStatus(s) {
    if (s === this.status) return;
    this.status = s;
    this.onStatus(s);
  }

  _connect(i = 0) {
    if (!this.enabled || this.sock) return;
    if (i > 9) {
      this._setStatus('no-discord');
      this._scheduleRetry();
      return;
    }
    const sock = net.createConnection(pipePath(i));
    let opened = false;
    sock.once('connect', () => {
      opened = true;
      this.sock = sock;
      this.buf = Buffer.alloc(0);
      sock.write(encode(OP.HANDSHAKE, { v: 1, client_id: this.clientId }));
    });
    sock.on('data', (d) => this._onData(d));
    sock.on('error', () => {
      if (!opened) this._connect(i + 1);
    });
    sock.on('close', () => {
      if (!opened) return;
      if (this.sock === sock) {
        this.sock = null;
        this.ready = false;
        if (this.enabled) {
          this._setStatus('no-discord');
          this._scheduleRetry();
        }
      }
    });
  }

  _scheduleRetry() {
    clearTimeout(this.retryTimer);
    this.retryTimer = setTimeout(() => this._connect(), this.retryMs);
    this.retryMs = Math.min(this.retryMs * 2, 60000);
  }

  _onData(d) {
    this.buf = Buffer.concat([this.buf, d]);
    while (this.buf.length >= 8) {
      const op = this.buf.readInt32LE(0);
      const len = this.buf.readInt32LE(4);
      if (this.buf.length < 8 + len) break;
      let msg = null;
      try {
        msg = JSON.parse(this.buf.subarray(8, 8 + len).toString('utf8'));
      } catch {}
      this.buf = this.buf.subarray(8 + len);
      if (op === OP.PING && this.sock) this.sock.write(encode(OP.PONG, msg));
      else if (op === OP.CLOSE) {
        this.log('discord: closed by Discord:', msg && msg.message);
        if (msg && /client id|invalid/i.test(msg.message || '')) {
          this.enabled = false;
          this._setStatus('bad-id');
        }
        this._disconnect();
      } else if (msg && msg.evt === 'READY') {
        this.ready = true;
        this.retryMs = 5000;
        this._setStatus('connected');
        this.log('discord: connected');
        if (this.pending !== undefined) this._flush();
      } else if (msg && msg.evt === 'ERROR') {
        this.log('discord: error', msg.data && msg.data.message);
      }
    }
  }

  _disconnect() {
    clearTimeout(this.retryTimer);
    clearTimeout(this.sendTimer);
    if (this.sock) {
      try {
        this.sock.end();
        this.sock.destroy();
      } catch {}
    }
    this.sock = null;
    this.ready = false;
  }

  // Called by the player. `now` = { title, artists, album, image, durationMs, positionMs, playing, uri } or null.
  update(now) {
    this.pending = now ? this._activity(now) : null;
    if (!this.enabled) return;
    this._flush();
  }

  _activity(n) {
    const a = {
      type: 2, // "Listening to"
      status_display_type: 2, // show the song name in the member list
      details: clip(n.title),
      state: clip(n.playing ? `by ${n.artists}` : `Paused · ${n.artists}`),
      assets: {},
      instance: false,
    };
    if (n.image && /^https:\/\//.test(n.image)) {
      a.assets.large_image = n.image;
      if (n.album) a.assets.large_text = clip(n.album);
    }
    if (n.playing && n.durationMs) {
      const start = Date.now() - Math.max(0, n.positionMs || 0);
      a.timestamps = { start, end: start + n.durationMs };
    }
    const id = String(n.uri || '').split(':').pop();
    if (/^[A-Za-z0-9]{22}$/.test(id)) a.buttons = [{ label: 'Open in Spotify', url: `https://open.spotify.com/track/${id}` }];
    if (!Object.keys(a.assets).length) delete a.assets;
    return a;
  }

  _flush() {
    if (!this.ready || !this.sock || this.pending === undefined) return;
    const wait = this.lastSent + MIN_GAP_MS - Date.now();
    clearTimeout(this.sendTimer);
    if (wait > 0) {
      this.sendTimer = setTimeout(() => this._flush(), wait);
      return;
    }
    const activity = this.pending;
    this.pending = undefined;
    this.lastSent = Date.now();
    this.sock.write(encode(OP.FRAME, { cmd: 'SET_ACTIVITY', args: { pid: process.pid, activity }, nonce: `${Date.now()}${Math.random()}` }));
  }

  clear() {
    this.update(null);
  }

  shutdown() {
    if (this.ready && this.sock) {
      try {
        this.sock.write(encode(OP.FRAME, { cmd: 'SET_ACTIVITY', args: { pid: process.pid }, nonce: 'bye' }));
      } catch {}
    }
    this.enabled = false;
    this._disconnect();
  }
}

module.exports = { DiscordPresence, encode, pipePath };
