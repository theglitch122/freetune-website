// Spotify data layer.
//
// FreeTune never streams audio from Spotify and never shows Spotify's ads. It signs in
// through Spotify's own login page (inside an app window), borrows the same short-lived
// access token the Spotify web player uses, and calls Spotify's data API for your
// library, playlists, home feed and search. Audio comes from YouTube Music instead.
//
// The GraphQL operations, variables and response shapes below are ported from the
// open-source Meld project (GPL-3.0): https://github.com/FrancescoGrazioso/Meld
// Spotify identifies each GraphQL query by a hash that changes every few weeks; Meld
// publishes an automatically verified list of current hashes, which FreeTune reads.

const { BrowserWindow, session } = require('electron');
const path = require('path');
const fs = require('fs');
const { isBlocked } = require('./privacy');

const GQL_URL = 'https://api-partner.spotify.com/pathfinder/v2/query';
const REST_BASE = 'https://api.spotify.com/v1/';
const SPCLIENT = 'https://spclient.wg.spotify.com/';
const HASH_SOURCES = [
  'https://francescograzioso.github.io/Meld/spotify-gql-hashes.json',
  'https://raw.githubusercontent.com/FrancescoGrazioso/Meld/main/docs/spotify-gql-hashes.json',
];
const PARTITION = 'persist:spotify';
const TOKEN_MAX_AGE_MS = 45 * 60 * 1000;
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36';

class SpotifyError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

// ── small JSON helpers ─────────────────────────────────────────────────────────
const o = (x, k) => (x && typeof x === 'object' && x[k] != null ? x[k] : undefined);
const arr = (x, k) => (Array.isArray(o(x, k)) ? x[k] : []);
const idOf = (uri) => (uri ? String(uri).split(':').pop() : '');

function pickImage(sources, prefer = 300) {
  if (!Array.isArray(sources) || !sources.length) return null;
  const withSize = sources.filter((s) => s && s.url);
  if (!withSize.length) return null;
  // Pick the smallest image that is at least `prefer` px wide, else the largest.
  const sized = withSize.filter((s) => (s.width || s.maxWidth || 0) >= prefer);
  if (sized.length) {
    return sized.sort((a, b) => (a.width || a.maxWidth || 0) - (b.width || b.maxWidth || 0))[0].url;
  }
  return withSize.sort((a, b) => (b.width || b.maxWidth || 0) - (a.width || a.maxWidth || 0))[0].url;
}

function largestImage(sources) {
  return pickImage(sources, 600);
}

function parseArtist(a) {
  const uri = o(a, 'uri') || '';
  return { uri, id: idOf(uri), name: o(o(a, 'profile'), 'name') || o(a, 'name') || '' };
}

function durationMs(t) {
  const d = o(t, 'duration');
  if (d && typeof d === 'object' && d.totalMilliseconds > 0) return d.totalMilliseconds;
  if (o(t, 'trackDuration') && t.trackDuration.totalMilliseconds > 0) return t.trackDuration.totalMilliseconds;
  if (t && t.durationMs > 0) return t.durationMs;
  if (t && t.duration_ms > 0) return t.duration_ms;
  return 0;
}

// The common GraphQL "Track" shape used by playlists, liked songs, search, artists.
function parseTrack(t, { albumOverride, uriOverride } = {}) {
  const uri = uriOverride || o(t, 'uri') || o(t, '_uri') || '';
  const artists = arr(o(t, 'artists'), 'items').map(parseArtist).filter((a) => a.name);
  let album = albumOverride;
  if (!album) {
    const a = o(t, 'albumOfTrack') || {};
    const sources = arr(o(a, 'coverArt'), 'sources');
    album = {
      uri: o(a, 'uri') || '',
      id: idOf(o(a, 'uri')),
      name: o(a, 'name') || '',
      image: pickImage(sources, 300),
      imageLarge: largestImage(sources),
    };
  }
  return {
    uri,
    id: idOf(uri),
    name: o(t, 'name') || '',
    artists,
    album,
    durationMs: durationMs(t),
    image: album.image,
    imageLarge: album.imageLarge || album.image,
    playable: o(o(t, 'playability'), 'playable') !== false,
  };
}

// REST track shape (used only by fallbacks).
function parseRestTrack(t) {
  const imgs = (o(o(t, 'album'), 'images') || []).map((i) => ({ url: i.url, width: i.width }));
  const album = {
    uri: o(o(t, 'album'), 'uri') || '',
    id: o(o(t, 'album'), 'id') || '',
    name: o(o(t, 'album'), 'name') || '',
    image: pickImage(imgs, 300),
    imageLarge: largestImage(imgs),
  };
  return {
    uri: t.uri,
    id: t.id,
    name: t.name,
    artists: (t.artists || []).map((a) => ({ uri: a.uri, id: a.id, name: a.name })),
    album,
    durationMs: t.duration_ms || 0,
    image: album.image,
    imageLarge: album.imageLarge,
    playable: true,
  };
}

function playlistImage(imagesObj) {
  const first = arr(imagesObj, 'items')[0];
  return pickImage(arr(first, 'sources'), 300);
}

function parsePlaylistData(data, uri) {
  const owner = o(o(data, 'ownerV2'), 'data') || {};
  const u = uri || o(data, 'uri') || '';
  return {
    type: 'playlist',
    uri: u,
    id: idOf(u),
    name: o(data, 'name') || '',
    description: stripHtml(o(data, 'description') || ''),
    image: playlistImage(o(data, 'images')),
    owner: o(owner, 'name') || '',
    ownerId: idOf(o(owner, 'uri')),
    total: o(o(data, 'content'), 'totalCount') || 0,
  };
}

function parseAlbumData(data) {
  const uri = o(data, 'uri') || '';
  const sources = arr(o(data, 'coverArt'), 'sources');
  return {
    type: 'album',
    uri,
    id: idOf(uri),
    name: o(data, 'name') || '',
    artists: arr(o(data, 'artists'), 'items').map(parseArtist),
    image: pickImage(sources, 300),
    year: o(o(data, 'date'), 'year') || (o(o(data, 'date'), 'isoString') || '').slice(0, 4) || '',
    albumType: (o(data, 'type') || o(data, 'albumType') || '').toLowerCase(),
  };
}

function parseArtistData(data, uriOverride) {
  const uri = uriOverride || o(data, 'uri') || '';
  return {
    type: 'artist',
    uri,
    id: idOf(uri),
    name: o(o(data, 'profile'), 'name') || o(data, 'name') || '',
    image: pickImage(arr(o(o(data, 'visuals'), 'avatarImage'), 'sources'), 300),
  };
}

// Podcasts. A show ("Podcast" in GraphQL) and its episodes. An episode is shaped like a
// song (name, artists, album, image) so every list, queue and player view shows it as is:
// the show stands in for both the artist and the album.
function parseShowData(data, uriOverride) {
  const uri = uriOverride || o(data, 'uri') || '';
  const sources = arr(o(data, 'coverArt'), 'sources').length ? data.coverArt.sources : (o(data, 'images') || []).map((i) => ({ url: i.url, width: i.width }));
  return {
    type: 'show',
    uri,
    id: idOf(uri) || o(data, 'id') || '',
    name: o(data, 'name') || '',
    publisher: o(o(data, 'publisher'), 'name') || (typeof o(data, 'publisher') === 'string' ? data.publisher : '') || '',
    image: pickImage(sources, 300),
    imageLarge: largestImage(sources),
    description: stripHtml(o(data, 'description') || ''),
  };
}

function parseEpisode(d, showOverride) {
  const uri = o(d, 'uri') || o(d, '_uri') || (o(d, 'id') ? `spotify:episode:${d.id}` : '');
  const showRaw = o(o(d, 'podcastV2'), 'data') || o(d, 'podcast') || o(d, 'show') || {};
  const show = showOverride || parseShowData(showRaw);
  const own = arr(o(d, 'coverArt'), 'sources').length ? d.coverArt.sources : (o(d, 'images') || []).map((i) => ({ url: i.url, width: i.width }));
  const image = pickImage(own, 300) || show.image || null;
  const iso = o(o(d, 'releaseDate'), 'isoString') || (typeof o(d, 'release_date') === 'string' ? d.release_date : '') || '';
  const showRef = { uri: show.uri, id: show.id, name: show.name, type: 'show' };
  return {
    type: 'episode',
    uri,
    id: idOf(uri),
    name: o(d, 'name') || '',
    artists: show.name ? [showRef] : [],
    album: { ...showRef, image: show.image, imageLarge: show.imageLarge || show.image },
    show: { ...showRef, publisher: show.publisher || '' },
    releaseDate: iso,
    addedAt: iso || null,
    description: stripHtml(o(d, 'description') || o(d, 'htmlDescription') || '').slice(0, 600),
    durationMs: durationMs(d),
    image,
    imageLarge: largestImage(own) || show.imageLarge || image,
    playable: o(o(d, 'playability'), 'playable') !== false,
  };
}

function stripHtml(s) {
  return String(s)
    .replace(/<[^>]*>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#x27;|&#39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');
}

// ── The client ─────────────────────────────────────────────────────────────────
class SpotifyClient {
  constructor({ userDataDir, resourcesDir, log = console.log }) {
    this.log = log;
    this.token = null;
    this.tokenAt = 0;
    this.clientToken = null;
    this._refreshing = null;
    this.hashFile = path.join(userDataDir, 'spotify-hashes.json');
    this.learnedHashes = {}; // seen live in the web player's own requests; most trustworthy
    this.hashes = this._loadHashes(path.join(resourcesDir, 'default-hashes.json'));
    this._sessionReady = false;
  }

  // ── hashes ──
  _loadHashes(defaultFile) {
    let best = null;
    for (const f of [this.hashFile, defaultFile]) {
      try {
        const j = JSON.parse(fs.readFileSync(f, 'utf8'));
        if (j && j.operations && (!best || (j.last_updated || '') > (best.last_updated || ''))) best = j;
      } catch {
        /* ignore */
      }
    }
    return best || { operations: {} };
  }

  async refreshHashes({ force = false } = {}) {
    const age = Date.now() - Date.parse(this.hashes.fetched_at || 0);
    if (!force && age < 6 * 3600 * 1000) return;
    for (const url of HASH_SOURCES) {
      try {
        const r = await fetch(url, { headers: { 'Cache-Control': 'no-cache' } });
        if (!r.ok) continue;
        const j = await r.json();
        if (!j || !j.operations) continue;
        j.fetched_at = new Date().toISOString();
        this.hashes = j;
        fs.writeFileSync(this.hashFile, JSON.stringify(j));
        this.log('spotify: query list updated', j.last_updated);
        return;
      } catch (e) {
        this.log('spotify: query list fetch failed', url, e.message);
      }
    }
  }

  _hashCandidates(op) {
    const out = [];
    if (this.learnedHashes[op]) out.push(this.learnedHashes[op]);
    const e = this.hashes.operations[op];
    if (e && e.hash && !out.includes(e.hash)) out.push(e.hash);
    if (e && e.previous_hash && !out.includes(e.previous_hash)) out.push(e.previous_hash);
    return out;
  }

  // ── session / sign-in ──
  get session() {
    return session.fromPartition(PARTITION);
  }

  // One-time setup of the Spotify browser session: block trackers/ads, and watch the
  // web player's own API calls to pick up its token and current query hashes.
  setupSession() {
    if (this._sessionReady) return;
    this._sessionReady = true;
    const s = this.session;
    s.setUserAgent(UA);
    s.setPermissionRequestHandler((_wc, _perm, cb) => cb(false));

    s.webRequest.onBeforeRequest({ urls: ['<all_urls>'] }, (details, cb) => {
      if (isBlocked(details.url)) return cb({ cancel: true });
      if (details.url.startsWith(GQL_URL) && details.uploadData && details.uploadData[0]) {
        try {
          const body = JSON.parse(Buffer.from(details.uploadData[0].bytes).toString('utf8'));
          const op = body.operationName;
          const h = body.extensions && body.extensions.persistedQuery && body.extensions.persistedQuery.sha256Hash;
          if (op && h) this.learnedHashes[op] = h;
        } catch {
          /* not JSON */
        }
      }
      cb({});
    });

    s.webRequest.onBeforeSendHeaders(
      { urls: ['https://*.spotify.com/*'] },
      (details, cb) => {
        const h = details.requestHeaders;
        const auth = h.Authorization || h.authorization;
        if (auth && /^Bearer\s+/i.test(auth)) {
          const tok = auth.replace(/^Bearer\s+/i, '');
          if (tok.length > 40) {
            if (tok !== this.token) {
              this.token = tok;
              this.tokenAt = Date.now();
            }
            if (this._onToken) this._onToken(tok);
          }
        }
        const ct = h['client-token'] || h['Client-Token'];
        if (ct) this.clientToken = ct;
        cb({ requestHeaders: h });
      }
    );
  }

  async isSignedIn() {
    this.setupSession();
    const cookies = await this.session.cookies.get({ name: 'sp_dc' });
    return cookies.some((c) => c.value && (!c.expirationDate || c.expirationDate * 1000 > Date.now()));
  }

  // Opens Spotify's real login page in an app window. Resolves when signed in.
  login(parent) {
    this.setupSession();
    return new Promise((resolve, reject) => {
      const win = new BrowserWindow({
        width: 480,
        height: 720,
        parent,
        modal: !!parent,
        title: 'Sign in to Spotify',
        autoHideMenuBar: true,
        backgroundColor: '#121212',
        webPreferences: { partition: PARTITION, contextIsolation: true, sandbox: true },
      });
      let done = false;
      const finish = async (ok) => {
        if (done) return;
        done = true;
        this.session.cookies.removeListener('changed', onCookie);
        if (!win.isDestroyed()) win.close();
        if (ok) {
          this.token = null;
          resolve(true);
        } else reject(new SpotifyError(401, 'Sign-in window was closed'));
      };
      const onCookie = (_e, cookie, _cause, removed) => {
        if (!removed && cookie.name === 'sp_dc' && cookie.value) setTimeout(() => finish(true), 600);
      };
      this.session.cookies.on('changed', onCookie);
      win.on('closed', async () => {
        if (!done) finish(await this.isSignedIn());
      });
      win.webContents.setWindowOpenHandler(({ url }) => {
        // Google/Apple/Facebook sign-in pop-ups: allow them inside the same session.
        if (/^https:\/\/(accounts\.google\.com|appleid\.apple\.com|www\.facebook\.com|accounts\.spotify\.com)/.test(url)) {
          return { action: 'allow', overrideBrowserWindowOptions: { webPreferences: { partition: PARTITION } } };
        }
        return { action: 'deny' };
      });
      win.loadURL('https://accounts.spotify.com/en/login?continue=https%3A%2F%2Fopen.spotify.com%2F');
    });
  }

  async logout() {
    this.token = null;
    this.tokenAt = 0;
    this.clientToken = null;
    await this.session.clearStorageData();
    await this.session.clearCache();
  }

  // Loads the Spotify web player in a hidden, muted window just long enough to see
  // which access token it uses, then closes it again.
  async _captureToken() {
    if (!(await this.isSignedIn())) throw new SpotifyError(401, 'NOT_SIGNED_IN');
    return new Promise((resolve, reject) => {
      const win = new BrowserWindow({
        show: false,
        width: 1200,
        height: 800,
        webPreferences: { partition: PARTITION, contextIsolation: true, sandbox: true, backgroundThrottling: false },
      });
      win.webContents.setAudioMuted(true);
      const cleanup = () => {
        clearTimeout(timer);
        this._onToken = null;
        // Give the player a moment so its first GraphQL calls (and their hashes) are seen.
        setTimeout(() => {
          if (!win.isDestroyed()) win.destroy();
        }, 4000);
      };
      const timer = setTimeout(() => {
        cleanup();
        reject(new SpotifyError(504, 'Timed out waiting for Spotify to respond'));
      }, 30000);
      this._onToken = (tok) => {
        cleanup();
        resolve(tok);
      };
      win.loadURL('https://open.spotify.com/').catch(() => {});
    });
  }

  async getToken(force = false) {
    if (!force && this.token && Date.now() - this.tokenAt < TOKEN_MAX_AGE_MS) return this.token;
    if (!this._refreshing) {
      if (force) this.token = null;
      this._refreshing = this._captureToken()
        .then((tok) => {
          this.token = tok;
          this.tokenAt = Date.now();
          return tok;
        })
        .finally(() => {
          this._refreshing = null;
        });
    }
    return this._refreshing;
  }

  // ── transport ──
  _headers(token) {
    const h = {
      Authorization: `Bearer ${token}`,
      'app-platform': 'WebPlayer',
      Origin: 'https://open.spotify.com',
      Referer: 'https://open.spotify.com/',
      'User-Agent': UA,
      Accept: 'application/json',
      'Accept-Language': 'en',
    };
    if (this.clientToken) h['client-token'] = this.clientToken;
    return h;
  }

  async gql(op, variables = {}, _retried = false) {
    const token = await this.getToken();
    const hashes = this._hashCandidates(op);
    if (!hashes.length) throw new SpotifyError(412, `No query id known for ${op}`);
    for (const hash of hashes) {
      const body = JSON.stringify({
        variables,
        operationName: op,
        extensions: { persistedQuery: { version: 1, sha256Hash: hash } },
      });
      let res;
      for (let attempt = 0; attempt < 3; attempt++) {
        res = await fetch(GQL_URL, {
          method: 'POST',
          headers: { ...this._headers(token), 'Content-Type': 'application/json;charset=UTF-8' },
          body,
        });
        if (res.status !== 429) break;
        const wait = Math.min(Number(res.headers.get('retry-after')) || 2 * (attempt + 1), 8);
        await new Promise((r) => setTimeout(r, wait * 1000));
      }
      if (res.status === 401) {
        if (_retried) throw new SpotifyError(401, 'Spotify rejected the session');
        await this.getToken(true);
        return this.gql(op, variables, true);
      }
      if (res.status === 412) continue; // hash rotated; try the next candidate
      const text = await res.text();
      if (!res.ok) throw new SpotifyError(res.status, `Spotify ${op} failed (${res.status}): ${text.slice(0, 160)}`);
      let json;
      try {
        json = JSON.parse(text);
      } catch {
        throw new SpotifyError(502, `Spotify ${op} returned invalid data`);
      }
      const err = json.errors && json.errors[0];
      if (err) {
        if (/PersistedQueryNotFound/i.test(err.message || '')) continue;
        if (!json.data) throw new SpotifyError(400, `Spotify ${op}: ${err.message}`);
      }
      return json;
    }
    // Every known hash failed — fetch the newest list once and retry.
    if (!_retried) {
      delete this.learnedHashes[op];
      await this.refreshHashes({ force: true });
      return this.gql(op, variables, true);
    }
    throw new SpotifyError(412, `Spotify changed its ${op} query; an update to the query list is needed`);
  }

  async rest(pathAndQuery, _retried = false) {
    const token = await this.getToken();
    const res = await fetch(REST_BASE + pathAndQuery, { headers: this._headers(token) });
    if (res.status === 401 && !_retried) {
      await this.getToken(true);
      return this.rest(pathAndQuery, true);
    }
    if (!res.ok) throw new SpotifyError(res.status, `Spotify REST ${pathAndQuery} failed (${res.status})`);
    return res.json();
  }

  // ── API ──
  async me() {
    try {
      const j = await this.gql('profileAttributes');
      const p = o(o(o(j, 'data'), 'me'), 'profile') || {};
      return { id: idOf(p.uri), name: p.name || '', image: pickImage(arr(o(p, 'avatar'), 'sources'), 64) };
    } catch (e) {
      const r = await this.rest('me');
      return { id: r.id, name: r.display_name || r.id, image: (r.images && r.images[0] && r.images[0].url) || null };
    }
  }

  async home() {
    const vars = {
      homeEndUserIntegration: 'INTEGRATION_WEB_PLAYER',
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
      sp_t: '',
      facet: '',
      sectionItemsLimit: 12,
      includeEpisodeContentRatingsV2: false,
    };
    const j = await this.gql('home', vars);
    const home = o(o(j, 'data'), 'home') || {};
    const greeting = o(o(home, 'greeting'), 'transformedLabel') || '';
    const sections = arr(o(o(home, 'sectionContainer'), 'sections'), 'items')
      .map((sec) => {
        const d = o(sec, 'data') || {};
        const t = o(d, 'title') || {};
        const title = t.transformedLabel || t.translatedBaseText || t.text || '';
        const items = arr(o(sec, 'sectionItems'), 'items')
          .map((it) => {
            const c = o(it, 'content') || {};
            const data = o(c, 'data');
            if (!data) return null;
            if (c.__typename === 'PlaylistResponseWrapper') return parsePlaylistData(data);
            if (c.__typename === 'AlbumResponseWrapper') return parseAlbumData(data);
            if (c.__typename === 'ArtistResponseWrapper') return parseArtistData(data);
            return null;
          })
          .filter((x) => x && x.uri && x.name);
        return { title, items };
      })
      .filter((s) => s.items.length);
    return { greeting, sections };
  }

  async libraryPlaylists() {
    const out = [];
    for (let offset = 0; offset < 2000; offset += 50) {
      const j = await this.gql('libraryV3', {
        filters: ['Playlists'],
        order: null,
        textFilter: '',
        features: ['LIKED_SONGS', 'YOUR_EPISODES_V2', 'PRERELEASES', 'EVENTS'],
        limit: 50,
        offset,
        flatten: true,
        expandedFolders: [],
        folderUri: null,
        includeFoldersWhenFlattening: false,
      });
      const lib = o(o(o(j, 'data'), 'me'), 'libraryV3') || {};
      const items = arr(lib, 'items');
      for (const it of items) {
        const w = o(it, 'item') || {};
        const tn = w.__typename || '';
        if (!/playlist/i.test(tn)) continue;
        const data = o(w, 'data');
        if (!data || data.__typename !== 'Playlist') continue;
        out.push(parsePlaylistData(data, w._uri));
      }
      const total = lib.totalCount || 0;
      if (!items.length || offset + 50 >= total) break;
    }
    return out;
  }

  async libraryArtists() {
    const j = await this.gql('libraryV3', {
      filters: ['Artists'],
      order: null,
      textFilter: '',
      features: ['LIKED_SONGS', 'YOUR_EPISODES_V2', 'PRERELEASES', 'EVENTS'],
      limit: 50,
      offset: 0,
      flatten: false,
      expandedFolders: [],
      folderUri: null,
      includeFoldersWhenFlattening: true,
    });
    const lib = o(o(o(j, 'data'), 'me'), 'libraryV3') || {};
    return arr(lib, 'items')
      .map((it) => {
        const w = o(it, 'item') || {};
        if (!/artist/i.test(w.__typename || '')) return null;
        return parseArtistData(o(w, 'data') || {}, w._uri);
      })
      .filter((a) => a && a.name);
  }

  // One page of a playlist (Spotify returns up to 100 per request).
  async playlistPage(id, offset = 0, limit = 100) {
    const j = await this.gql('fetchPlaylist', {
      uri: `spotify:playlist:${id}`,
      offset,
      limit,
      enableWatchFeedEntrypoint: false,
    });
    const p = o(o(j, 'data'), 'playlistV2');
    if (!p || p.__typename === 'NotFound') throw new SpotifyError(404, 'Playlist not found');
    const content = o(p, 'content') || {};
    const tracks = arr(content, 'items')
      .map((el) => {
        const w = o(el, 'itemV2') || {};
        const d = o(w, 'data');
        if (!d || (d.__typename && d.__typename !== 'Track' && d.__typename !== 'Episode')) return null;
        const t = d.__typename === 'Episode' || /^spotify:episode:/.test(w._uri || w.uri || '') ? parseEpisode({ ...d, uri: w._uri || w.uri || d.uri }) : parseTrack(d, { uriOverride: w._uri || w.uri });
        t.uid = o(el, 'uid') || o(w, 'uid') || null; // needed to remove or move this exact entry
        t.addedAt = o(o(el, 'addedAt'), 'isoString') || null;
        return t;
      })
      .filter((t) => t && t.name);
    return {
      info: { ...parsePlaylistData(p, `spotify:playlist:${id}`), total: content.totalCount || 0 },
      tracks,
      total: content.totalCount || 0,
    };
  }

  async likedPage(offset = 0, limit = 50) {
    const j = await this.gql('fetchLibraryTracks', { offset, limit });
    const t = o(o(o(o(j, 'data'), 'me'), 'library'), 'tracks') || {};
    const tracks = arr(t, 'items')
      .map((el) => {
        const w = o(el, 'track') || {};
        const d = o(w, 'data');
        return d ? parseTrack(d, { uriOverride: w._uri || w.uri }) : null;
      })
      .filter((x) => x && x.name);
    return { tracks, total: t.totalCount || 0 };
  }

  async album(id) {
    const j = await this.gql('getAlbum', { uri: `spotify:album:${id}`, locale: '', offset: 0, limit: 50 });
    const a = o(o(j, 'data'), 'albumUnion');
    if (!a) throw new SpotifyError(404, 'Album not found');
    const info = parseAlbumData({ ...a, uri: `spotify:album:${id}` });
    const sources = arr(o(a, 'coverArt'), 'sources');
    const albumRef = {
      uri: info.uri,
      id,
      name: info.name,
      image: pickImage(sources, 300),
      imageLarge: largestImage(sources),
    };
    const tracks = arr(o(a, 'tracksV2'), 'items')
      .map((el) => {
        const t = o(el, 'track');
        return t ? parseTrack(t, { albumOverride: albumRef }) : null;
      })
      .filter((t) => t && t.name);
    return { info: { ...info, total: o(o(a, 'tracksV2'), 'totalCount') || tracks.length }, tracks };
  }

  async artist(id) {
    const j = await this.gql('queryArtistOverview', { uri: `spotify:artist:${id}`, locale: '' });
    const a = o(o(j, 'data'), 'artistUnion');
    if (!a) throw new SpotifyError(404, 'Artist not found');
    const info = parseArtistData(a, `spotify:artist:${id}`);
    info.imageLarge = largestImage(arr(o(o(a, 'visuals'), 'avatarImage'), 'sources'));
    const hi = o(o(a, 'visuals'), 'headerImage');
    info.header = largestImage(arr(hi, 'sources').length ? hi.sources : arr(o(hi, 'data'), 'sources'));
    info.monthlyListeners = o(o(a, 'stats'), 'monthlyListeners') || null;
    const topTracks = arr(o(o(a, 'discography'), 'topTracks'), 'items')
      .map((el) => (o(el, 'track') ? parseTrack(el.track) : null))
      .filter((t) => t && t.name);
    const related = arr(o(o(a, 'relatedContent'), 'relatedArtists'), 'items')
      .map((r) => parseArtistData(r))
      .filter((r) => r.name);
    const releases = [];
    for (const key of ['popularReleasesAlbums', 'albums', 'singles']) {
      for (const el of arr(o(o(a, 'discography'), key), 'items')) {
        const rel = o(o(el, 'releases'), 'items') ? el.releases.items[0] : el;
        if (rel && rel.uri && !releases.some((x) => x.uri === rel.uri)) releases.push(parseAlbumData(rel));
      }
    }
    return { info, topTracks, related, releases: releases.filter((r) => r.name) };
  }

  // Every album, single, EP and compilation by an artist (Spotify's "Discography"),
  // newest first. The songs of each one are loaded with album() as they're shown.
  async discography(id) {
    const out = [];
    try {
      for (let offset = 0; offset < 600; offset += 50) {
        const r = await this.rest(`artists/${id}/albums?include_groups=album,single,compilation&limit=50&offset=${offset}&market=from_token`);
        for (const a of o(r, 'items') || []) {
          if (!a || !a.id) continue;
          const imgs = (a.images || []).map((i) => ({ url: i.url, width: i.width }));
          out.push({
            type: 'album',
            uri: a.uri,
            id: a.id,
            name: a.name,
            image: pickImage(imgs, 300),
            imageLarge: largestImage(imgs),
            artists: (a.artists || []).map((x) => ({ uri: x.uri, id: x.id, name: x.name })),
            year: (a.release_date || '').slice(0, 4),
            date: a.release_date || '',
            albumType: a.album_group === 'compilation' || a.album_type === 'compilation' ? 'compilation' : a.album_type === 'single' ? (a.total_tracks > 3 ? 'ep' : 'single') : 'album',
            total: a.total_tracks || 0,
          });
        }
        if (!o(r, 'next')) break;
      }
    } catch (e) {
      // The plain list isn't available: use the releases on the artist's page instead.
      this.log('spotify: full discography failed, using the artist page releases', e.message);
      const a = await this.artist(id);
      return a.releases.map((r) => ({ ...r, total: 0, date: String(r.year || '') }));
    }
    // The same release is often listed twice (for different countries): keep one.
    const seen = new Set();
    return out
      .filter((r) => {
        const k = `${r.albumType}|${r.name.toLowerCase()}|${r.total}`;
        if (seen.has(k)) return false;
        seen.add(k);
        return true;
      })
      .sort((x, y) => (y.date || '').localeCompare(x.date || ''));
  }

  async search(query) {
    try {
      const j = await this.gql('searchDesktop', {
        searchTerm: query,
        offset: 0,
        limit: 20,
        numberOfTopResults: 5,
        includeAudiobooks: false,
        includeArtistHasConcertsField: false,
        includePreReleases: false,
        includeLocalConcertsField: false,
        includeAuthors: false,
      });
      const s = o(o(j, 'data'), 'searchV2') || {};
      const tracks = arr(o(s, 'tracksV2'), 'items')
        .map((el) => {
          const w = o(el, 'item') || {};
          const d = o(w, 'data');
          if (!d || d.__typename !== 'Track') return null;
          return parseTrack(d, { uriOverride: w._uri || w.uri });
        })
        .filter(Boolean);
      // Accept the result whether Spotify labels the wrapper or only the item inside it.
      const pick = (sec, tn, fn) =>
        arr(o(s, sec), 'items')
          .filter((w) => o(w, 'data') && (w.__typename === tn || (w.data.__typename && tn.startsWith(w.data.__typename))))
          .map((w) => fn(w.data))
          .filter((x) => x.name);
      const out = {
        tracks,
        artists: pick('artists', 'ArtistResponseWrapper', (d) => parseArtistData(d)),
        albums: pick('albumsV2', 'AlbumResponseWrapper', parseAlbumData),
        playlists: pick('playlists', 'PlaylistResponseWrapper', (d) => parsePlaylistData(d)),
        shows: pick('podcasts', 'PodcastResponseWrapper', (d) => parseShowData(d)),
        episodes: pick('episodes', 'EpisodeResponseWrapper', (d) => parseEpisode(d)).filter((e) => e.uri),
      };
      // Older search answers leave podcasts out: ask the plain search for them.
      if (!out.shows.length && !out.episodes.length) Object.assign(out, await this._searchPodcasts(query).catch(() => ({})));
      return out;
    } catch (e) {
      this.log('spotify: GraphQL search failed, using REST search', e.message);
      const q = encodeURIComponent(query);
      const r = await this.rest(`search?q=${q}&type=track,artist,album,playlist&limit=10`);
      const img = (imgs) => pickImage((imgs || []).map((i) => ({ url: i.url, width: i.width })), 300);
      return {
        tracks: (o(r.tracks, 'items') || []).filter(Boolean).map(parseRestTrack),
        artists: (o(r.artists, 'items') || []).filter(Boolean).map((a) => ({ type: 'artist', uri: a.uri, id: a.id, name: a.name, image: img(a.images) })),
        albums: (o(r.albums, 'items') || []).filter(Boolean).map((a) => ({
          type: 'album', uri: a.uri, id: a.id, name: a.name, image: img(a.images),
          artists: (a.artists || []).map((x) => ({ uri: x.uri, id: x.id, name: x.name })),
          year: (a.release_date || '').slice(0, 4), albumType: a.album_type,
        })),
        playlists: (o(r.playlists, 'items') || []).filter(Boolean).map((p) => ({
          type: 'playlist', uri: p.uri, id: p.id, name: p.name, image: img(p.images),
          owner: o(p.owner, 'display_name') || '', description: stripHtml(p.description || ''),
        })),
        ...(await this._searchPodcasts(query).catch(() => ({}))),
      };
    }
  }

  async _searchPodcasts(query) {
    const r = await this.rest(`search?q=${encodeURIComponent(query)}&type=show,episode&limit=10&market=from_token`);
    return {
      shows: (o(r.shows, 'items') || []).filter(Boolean).map((sh) => parseShowData(sh, sh.uri)).filter((x) => x.name),
      episodes: (o(r.episodes, 'items') || []).filter(Boolean).map((e) => parseEpisode(e)).filter((x) => x.name && x.uri),
    };
  }

  // ── podcasts ──
  // A show and its episodes, newest first (50 per page).
  async show(id, offset = 0) {
    const sh = await this.rest(`shows/${id}?market=from_token`);
    const info = parseShowData(sh, sh.uri || `spotify:show:${id}`);
    const page = offset ? await this.rest(`shows/${id}/episodes?market=from_token&limit=50&offset=${offset}`) : o(sh, 'episodes') || {};
    const episodes = (o(page, 'items') || [])
      .filter(Boolean)
      .map((e) => parseEpisode(e, info))
      .filter((e) => e.name && e.uri);
    return { info: { ...info, total: o(page, 'total') || o(o(sh, 'episodes'), 'total') || episodes.length }, episodes, total: o(page, 'total') || episodes.length };
  }

  async episode(id) {
    const e = await this.rest(`episodes/${id}?market=from_token`);
    return parseEpisode(e);
  }

  // Podcasts you follow.
  async libraryShows() {
    try {
      const j = await this.gql('libraryV3', {
        filters: ['Podcasts & Shows'],
        order: null,
        textFilter: '',
        features: ['LIKED_SONGS', 'YOUR_EPISODES_V2', 'PRERELEASES', 'EVENTS'],
        limit: 50,
        offset: 0,
        flatten: false,
        expandedFolders: [],
        folderUri: null,
        includeFoldersWhenFlattening: true,
      });
      const lib = o(o(o(j, 'data'), 'me'), 'libraryV3') || {};
      const shows = arr(lib, 'items')
        .map((it) => {
          const w = o(it, 'item') || {};
          if (!/podcast|show/i.test(w.__typename || '') && !/^spotify:show:/.test(w._uri || '')) return null;
          return parseShowData(o(w, 'data') || {}, w._uri);
        })
        .filter((x) => x && x.name);
      if (shows.length) return shows;
    } catch (e) {
      this.log('spotify: podcasts from the library list failed, using the plain list', e.message);
    }
    const r = await this.rest('me/shows?limit=50');
    return (o(r, 'items') || []).map((it) => o(it, 'show')).filter(Boolean).map((sh) => parseShowData(sh, sh.uri)).filter((x) => x.name);
  }

  // ── your own playlists ──
  // Editing songs uses the same GraphQL operations as Meld. Creating and deleting go
  // through the playlist service the web player itself uses (spclient).
  async myId() {
    if (!this._meId) this._meId = (await this.me()).id;
    return this._meId;
  }

  async spclient(method, pathAndQuery, body, _retried = false) {
    const token = await this.getToken();
    const res = await fetch(SPCLIENT + pathAndQuery, {
      method,
      headers: { ...this._headers(token), 'Content-Type': 'application/json;charset=UTF-8' },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (res.status === 401 && !_retried) {
      await this.getToken(true);
      return this.spclient(method, pathAndQuery, body, true);
    }
    const text = await res.text();
    if (!res.ok) throw new SpotifyError(res.status, `Spotify playlist service ${res.status}: ${text.slice(0, 160)}`);
    try {
      return text ? JSON.parse(text) : {};
    } catch {
      return {};
    }
  }

  async _rootlist(ops) {
    const user = encodeURIComponent(await this.myId());
    return this.spclient('POST', `playlist/v2/user/${user}/rootlist/changes`, {
      deltas: [{ ops, info: { source: { client: 5 } } }],
      wantResultingRevisions: false,
      wantSyncResult: false,
      nonces: [],
    });
  }

  async createPlaylist(name, description = '') {
    const created = await this.spclient('POST', 'playlist/v2/playlist', {
      ops: [{ kind: 6, updateListAttributes: { newAttributes: { values: { name, formatAttributes: [], pictureSize: [] }, noValue: [] } } }],
    });
    const uri = created.uri || (created.revision && created.uri);
    if (!uri || !/^spotify:playlist:/.test(uri)) throw new SpotifyError(502, 'Spotify didn’t create the playlist');
    // Put it in Your Library (top of the list), like Spotify does.
    await this._rootlist([{ kind: 2, add: { items: [{ uri, attributes: { timestamp: Date.now(), formatAttributes: [], availableSignals: [] } }], addFirst: true } }]);
    if (description) await this.editPlaylist(idOf(uri), { description }).catch(() => {});
    const me = await this.me().catch(() => ({ id: '', name: '' }));
    return { type: 'playlist', uri, id: idOf(uri), name, description, image: null, owner: me.name, ownerId: me.id, total: 0 };
  }

  // "Delete" in Spotify removes the playlist from your library (others who follow it keep it).
  async deletePlaylist(id) {
    await this._rootlist([{ kind: 3, rem: { items: [{ uri: `spotify:playlist:${id}` }], itemsAsKey: true } }]);
    return true;
  }

  async addToPlaylist(id, uris) {
    await this.gql('addToPlaylist', {
      playlistUri: `spotify:playlist:${id}`,
      playlistItemUris: uris,
      newPosition: { moveType: 'BOTTOM_OF_PLAYLIST', fromUid: null },
    });
    return true;
  }

  async removeFromPlaylist(id, uids) {
    await this.gql('removeFromPlaylist', { playlistUri: `spotify:playlist:${id}`, uids });
    return true;
  }

  async movePlaylistItems(id, uids, beforeUid) {
    await this.gql('moveItemsInPlaylist', {
      playlistUri: `spotify:playlist:${id}`,
      uids,
      newPosition: beforeUid ? { moveType: 'BEFORE_UID', fromUid: beforeUid } : { moveType: 'BOTTOM_OF_PLAYLIST', fromUid: null },
    });
    return true;
  }

  async editPlaylist(id, { name, description } = {}) {
    const vars = { playlistUri: `spotify:playlist:${id}` };
    if (name != null) vars.newName = name;
    if (description != null) vars.newDescription = description;
    await this.gql('editPlaylistAttributes', vars);
    return true;
  }

  async setLiked(uris, liked) {
    await this.gql(liked ? 'addToLibrary' : 'removeFromLibrary', { libraryItemUris: uris });
    return true;
  }
}

module.exports = { SpotifyClient, SpotifyError, _parsers: { parseTrack, parsePlaylistData, parseAlbumData, parseArtistData, parseShowData, parseEpisode, pickImage } };
