// Streaming HTTP(S) requests for YouTube's video servers, with control over which kind
// of internet address is used (IPv4 or IPv6). YouTube ties every stream link to the
// address that looked it up, so a stream has to be fetched over the same kind of address
// as its lookup. family 0 lets the computer choose, as a browser would.

const http = require('http');
const https = require('https');

const agents = {
  'http:': new http.Agent({ keepAlive: true, maxSockets: 8 }),
  'https:': new https.Agent({ keepAlive: true, maxSockets: 8 }),
};

// Resolves to a small fetch-like response: { status, ok, headers.get(), body, cancel() }.
// `body` is a Node readable stream (also async-iterable).
// YouTube's video servers often redirect to another server, so redirects are followed
// (keeping the same headers and kind of address).
async function streamRequest(url, opts = {}) {
  let current = url;
  for (let hops = 0; ; hops++) {
    const res = await requestOnce(current, opts);
    const loc = res.headers.get('location');
    if (![301, 302, 303, 307, 308].includes(res.status) || !loc || hops >= (opts.maxHops || 5)) return res;
    res.cancel();
    current = new URL(loc, current).href;
  }
}

function requestOnce(url, { headers = {}, family = 0, signal, method = 'GET', timeoutMs = 20000 } = {}) {
  return new Promise((resolve, reject) => {
    let u;
    try {
      u = new URL(url);
    } catch (e) {
      reject(e);
      return;
    }
    const mod = u.protocol === 'http:' ? http : https;
    const opts = { method, headers, agent: agents[u.protocol] };
    if (family === 4 || family === 6) opts.family = family;
    const req = mod.request(u, opts, (res) => {
      clearTimeout(timer);
      const cancel = () => {
        res.destroy();
        req.destroy();
      };
      if (signal) signal.addEventListener('abort', cancel, { once: true });
      resolve({
        status: res.statusCode,
        ok: res.statusCode >= 200 && res.statusCode < 300,
        headers: { get: (name) => {
          const v = res.headers[String(name).toLowerCase()];
          return Array.isArray(v) ? v.join(', ') : v == null ? null : String(v);
        } },
        body: res,
        cancel,
      });
    });
    const timer = setTimeout(() => req.destroy(new Error('Timed out connecting to YouTube')), timeoutMs);
    req.on('error', (e) => {
      clearTimeout(timer);
      reject(e);
    });
    if (signal) {
      if (signal.aborted) {
        req.destroy(new Error('aborted'));
        return;
      }
      signal.addEventListener('abort', () => req.destroy(new Error('aborted')), { once: true });
    }
    req.end();
  });
}

module.exports = { streamRequest };
