// Downloads, like Spotify's: turn on "Download" for a playlist, album or your Liked Songs
// and every song in it is saved on this device, so it plays with no internet connection.
// New songs added to a downloaded playlist are downloaded the next time it's opened (or
// when the app starts); songs taken out of it are removed unless another download has them.
//
// This file only keeps track of what should be downloaded and works through the list. The
// saving itself is done by a "storage" the app hands in (the PC and the phones save files
// differently):
//   storage.hasSong(videoId)            -> bool
//   storage.fetchSong(videoId)          -> Promise<bool>   (true when saved)
//   storage.removeSong(videoId)
//   storage.hasEpisode(key)             -> bool            (key: "ep:<episodeId>")
//   storage.fetchEpisode(key, url)      -> Promise<bool>
//   storage.removeEpisode(key)
//   storage.usage()                     -> bytes (or a Promise of it)
//   storage.paused()                    -> a reason to wait (e.g. YouTube's bot check), or ''

const KEY_RE = /^(playlist|album|mine|ytplaylist|ytalbum):[\w-]{2,80}$|^(liked|ytliked):me$/;
const SLIM_KEYS = ['type', 'uri', 'id', 'videoId', 'name', 'artists', 'album', 'show', 'image', 'durationMs', 'releaseDate', 'playable', 'extra'];

const isEpisode = (t) => !!t && /^spotify:episode:/.test(t.uri || '');
// Local-playlist songs have no Spotify address; they're known by name and artist.
const uriOf = (t) => (t && t.uri) || (t && t.name ? `local:${t.name}|${((t.artists || [])[0] || {}).name || ''}` : '');

function slim(t) {
  const o = {};
  for (const k of SLIM_KEYS) if (t[k] != null) o[k] = t[k];
  if (o.album && typeof o.album === 'object') o.album = { name: o.album.name, id: o.album.id, uri: o.album.uri, type: o.album.type, image: o.album.image };
  return o;
}

class Downloads {
  constructor({ store, storage, matcher, podcasts, log = console.log, onChange = () => {} }) {
    this.store = store; // { collections: { key: {...info, tracks: [...] } }, files: { uri: { kind, id } }, failed: { uri: msg } }
    this.storage = storage;
    this.matcher = matcher;
    this.podcasts = podcasts;
    this.log = log;
    this.onChange = onChange;
    this.queue = []; // uris still to download, in order
    this.working = 0;
    this.current = null;
    this.paused = '';
    this.version = 0;
    this._notifyTimer = null;
    this._sizeAt = 0;
    this._size = 0;
    if (!this.store.get('collections')) this.store.set('collections', {});
    if (!this.store.get('files')) this.store.set('files', {});
    this.failed = {};
  }

  get collections() {
    return this.store.get('collections', {});
  }
  get files() {
    return this.store.get('files', {});
  }
  _save() {
    this.store.set('collections', this.collections);
    this.store.set('files', this.files);
  }

  // ── what the app shows ──
  isOn(key) {
    return !!this.collections[key];
  }

  // The saved audio for a song or episode, or null.
  fileFor(track) {
    const f = this.files[uriOf(track)];
    if (!f) return null;
    const ok = f.kind === 'episode' ? this.storage.hasEpisode(f.id) : this.storage.hasSong(f.id);
    return ok ? f : null;
  }

  // Everything the screens need: each download's progress and which songs are saved.
  status() {
    const files = this.files;
    const done = (t) => !!files[uriOf(t)];
    const collections = {};
    for (const [key, c] of Object.entries(this.collections)) {
      const playable = c.tracks.filter((t) => t.playable !== false);
      collections[key] = { total: playable.length, done: playable.filter(done).length, failed: playable.filter((t) => this.failed[uriOf(t)]).length };
    }
    return {
      version: this.version,
      collections,
      uris: Object.keys(files),
      downloading: this.current ? { name: this.current.name, left: this.queue.length + this.working } : null,
      paused: this.paused,
    };
  }

  list() {
    const st = this.status().collections;
    return Object.values(this.collections)
      .map((c) => ({ key: c.key, type: c.kind, id: c.id, name: c.name, image: c.image || null, owner: c.owner || '', local: c.kind === 'mine', ...st[c.key], addedAt: c.addedAt }))
      .sort((a, b) => (b.addedAt || 0) - (a.addedAt || 0));
  }

  tracks(key) {
    const c = this.collections[key];
    return c ? c.tracks : null;
  }

  async usage() {
    if (Date.now() - this._sizeAt < 3000) return this._size;
    this._size = await this.storage.usage();
    this._sizeAt = Date.now();
    return this._size;
  }

  // ── changes ──
  // Turn on (or bring up to date) the download of a collection with its current songs.
  set(key, info, tracks) {
    if (!KEY_RE.test(String(key))) throw new Error('This can’t be downloaded');
    const list = (Array.isArray(tracks) ? tracks : []).filter((t) => t && t.name).slice(0, 10000).map(slim);
    const before = this.collections[key];
    const c = {
      key,
      kind: key.split(':')[0],
      id: key.split(':')[1],
      name: String((info && info.name) || (before && before.name) || 'Download').slice(0, 200),
      image: (info && info.image) || (before && before.image) || (list[0] && list[0].image) || null,
      owner: String((info && info.owner) || (before && before.owner) || '').slice(0, 100),
      addedAt: (before && before.addedAt) || Date.now(),
      tracks: list,
    };
    this.collections[key] = c;
    if (before) this._dropUnused(before.tracks);
    for (const t of list) {
      const u = uriOf(t);
      if (t.playable === false || this.files[u] || this.queue.includes(u)) continue;
      this.queue.push(u);
    }
    this._save();
    this._changed();
    this._pump();
    return this.status();
  }

  remove(key) {
    const c = this.collections[key];
    if (!c) return this.status();
    delete this.collections[key];
    this._dropUnused(c.tracks);
    this._save();
    this._changed();
    return this.status();
  }

  removeAll() {
    const all = Object.values(this.collections).flatMap((c) => c.tracks);
    this.store.set('collections', {});
    this.queue = [];
    this._dropUnused(all);
    this._save();
    this._changed();
    return this.status();
  }

  // A song now plays from a different YouTube recording: download that one instead.
  replaced(uri) {
    const f = this.files[uri];
    if (!f || f.kind !== 'song') return;
    delete this.files[uri];
    if (!this._usedElsewhere(f)) this.storage.removeSong(f.id);
    if (Object.values(this.collections).some((c) => c.tracks.some((t) => uriOf(t) === uri))) this.queue.unshift(uri);
    this._save();
    this._changed();
    this._pump();
  }

  // Anything left to do from last time (or that failed): carry on.
  resume() {
    for (const c of Object.values(this.collections)) {
      for (const t of c.tracks) {
        const u = uriOf(t);
        const f = this.files[u];
        // A file that disappeared (cleared by the system) is downloaded again.
        if (f && !(f.kind === 'episode' ? this.storage.hasEpisode(f.id) : this.storage.hasSong(f.id))) delete this.files[u];
        if (t.playable !== false && !this.files[u] && !this.queue.includes(u)) this.queue.push(u);
      }
    }
    this.failed = {};
    this._save();
    this._changed();
    this._pump();
  }

  _usedElsewhere(f, except = null) {
    return Object.entries(this.files).some(([u, g]) => u !== except && g.kind === f.kind && g.id === f.id);
  }

  _dropUnused(tracks) {
    const keep = new Set(Object.values(this.collections).flatMap((c) => c.tracks.map(uriOf)));
    for (const t of tracks) {
      const u = uriOf(t);
      if (keep.has(u)) continue;
      this.queue = this.queue.filter((q) => q !== u);
      const f = this.files[u];
      if (!f) continue;
      delete this.files[u];
      if (this._usedElsewhere(f)) continue;
      if (f.kind === 'episode') this.storage.removeEpisode(f.id);
      else this.storage.removeSong(f.id);
    }
  }

  _track(u) {
    for (const c of Object.values(this.collections)) {
      const t = c.tracks.find((x) => uriOf(x) === u);
      if (t) return t;
    }
    return null;
  }

  // ── the work ──
  _pump() {
    while (this.working < 2 && this.queue.length) {
      const reason = this.storage.paused ? this.storage.paused() : '';
      if (reason) {
        if (this.paused !== reason) {
          this.paused = reason;
          this._changed();
        }
        clearTimeout(this._retry);
        this._retry = setTimeout(() => this._pump(), 5 * 60 * 1000);
        if (this._retry && this._retry.unref) this._retry.unref(); // never keeps the PC app from closing
        return;
      }
      this.paused = '';
      const u = this.queue.shift();
      const t = this._track(u);
      if (!t || this.files[u]) continue;
      this.working++;
      this.current = t;
      this._changed();
      this._one(u, t)
        .then((f) => {
          if (f && this._track(u)) {
            this.files[u] = f;
            delete this.failed[u];
            this._save();
          }
        })
        .catch((e) => {
          this.failed[u] = e.message || String(e);
          this.log('downloads: couldn’t download', t.name, '-', this.failed[u]);
        })
        .finally(() => {
          this.working--;
          if (!this.working) this.current = null;
          this._changed();
          this._pump();
        });
    }
  }

  async _one(u, t) {
    if (isEpisode(t)) {
      const key = `ep:${t.id || u.split(':').pop()}`;
      const found = this.podcasts ? await this.podcasts.find(t).catch(() => null) : null;
      if (found) {
        if (this.storage.hasEpisode(key) || (await this.storage.fetchEpisode(key, found.url))) return { kind: 'episode', id: key };
        throw new Error('the podcast’s server didn’t send the episode');
      }
      const yt = this.matcher.findEpisode ? await this.matcher.findEpisode(t).catch(() => null) : null;
      if (!yt) throw new Error('only on Spotify');
      if (this.storage.hasSong(yt.videoId) || (await this.storage.fetchSong(yt.videoId))) return { kind: 'song', id: yt.videoId };
      throw new Error('YouTube didn’t send it');
    }
    const m = await this.matcher.find(t);
    if (this.storage.hasSong(m.videoId) || (await this.storage.fetchSong(m.videoId))) return { kind: 'song', id: m.videoId };
    throw new Error('YouTube didn’t send it');
  }

  _changed() {
    this.version++;
    if (this._notifyTimer) return;
    this._notifyTimer = setTimeout(() => {
      this._notifyTimer = null;
      try {
        this.onChange(this.status());
      } catch {}
    }, 250);
  }
}

module.exports = { Downloads, uriOf, isDownloadKey: (k) => KEY_RE.test(String(k)) };
