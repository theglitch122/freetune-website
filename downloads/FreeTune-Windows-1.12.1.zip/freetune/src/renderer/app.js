'use strict';
/* FreeTune renderer: views, track lists, queue and player. Talks to the main process
   only through window.ft (see preload.js). */

// window.ft is provided by preload.js (contextBridge); it is already a global, so don't redeclare it.
const $ = (sel, root = document) => root.querySelector(sel);

// ── tiny DOM helper: h('div.cls', {attrs}, ...children) ─────────────────────────
function h(spec, attrs, ...kids) {
  const [tag, ...classes] = spec.split('.');
  const el = document.createElement(tag || 'div');
  if (classes.length) el.className = classes.join(' ');
  if (attrs && (typeof attrs !== 'object' || attrs instanceof Node || Array.isArray(attrs))) {
    kids.unshift(attrs);
    attrs = null;
  }
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'text') el.textContent = v;
    else if (k === 'html') el.innerHTML = v; // only ever used with static icon strings
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat(Infinity)) {
    if (k == null || k === false) continue;
    el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
  return el;
}

const ICONS = {
  play: '<svg viewBox="0 0 24 24" class="filled"><path d="M8 5v14l11-7z"/></svg>',
  pause: '<svg viewBox="0 0 24 24" class="filled"><path d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>',
  heart: '<svg viewBox="0 0 24 24"><path d="M12 20s-7-4.4-9.2-8.6C1.4 8.5 3.2 5 6.6 5c2 0 3.4 1.1 4.4 2.5C12 6.1 13.4 5 15.4 5c3.4 0 5.2 3.5 3.8 6.4C19 15.6 12 20 12 20z"/></svg>',
  shuffle: '<svg viewBox="0 0 24 24"><path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/></svg>',
  more: '<svg viewBox="0 0 24 24" class="filled"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg>',
  spotify: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5"/><path d="M7 9.5c3.5-1 7.3-.6 10 1M7.6 12.6c2.8-.8 5.8-.4 8 .9M8.3 15.5c2.2-.6 4.4-.3 6.1.7"/></svg>',
  plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
  plusCircle: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5"/><path d="M12 8v8M8 12h8"/></svg>',
  clock: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  pc: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M8 20h8M12 16v4"/></svg>',
  cloud: '<svg viewBox="0 0 24 24"><path d="M7 18h10a4 4 0 0 0 .6-8A6 6 0 0 0 6.2 9.3 4.4 4.4 0 0 0 7 18z"/></svg>',
  note: '<svg viewBox="0 0 24 24"><path d="M9 18V6l11-2v12"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></svg>',
  pencil: '<svg viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M14 6l4 4"/></svg>',
  trash: '<svg viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>',
  minusCircle: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5"/><path d="M8 12h8"/></svg>',
  queue: '<svg viewBox="0 0 24 24"><path d="M3 6h13M3 12h13M3 18h9M19 14v7M16 18l3 3 3-3"/></svg>',
  next: '<svg viewBox="0 0 24 24"><path d="M5 12h11M12 6l6 6-6 6"/></svg>',
  album: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5"/><circle cx="12" cy="12" r="2.5"/></svg>',
  artist: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c1-4.5 4.2-6.5 8-6.5s7 2 8 6.5"/></svg>',
  link: '<svg viewBox="0 0 24 24"><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/></svg>',
  search: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
  // Where something comes from (shown small, in your library and on pages)
  ytm: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5"/><circle cx="12" cy="12" r="5.5"/><path d="M10.6 9.6v4.8l3.8-2.4z" fill="currentColor" stroke="none"/></svg>',
  check: '<svg viewBox="0 0 24 24" class="filled"><circle cx="12" cy="12" r="10.5"/><path d="M7.5 12.5l3 3 6-6.5" fill="none" stroke="#000" stroke-width="2.2"/></svg>',
  download: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5"/><path d="M12 7v9M8 12.5l4 4 4-4"/></svg>',
  downloaded: '<svg viewBox="0 0 24 24" class="filled"><circle cx="12" cy="12" r="10.5"/><path d="M12 7v9M8 12.5l4 4 4-4" fill="none" stroke="#000" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  speaker: '<svg viewBox="0 0 24 24" class="filled"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16 8.5a5 5 0 0 1 0 7" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>',
};
const icon = (name) => h('span', { html: ICONS[name], style: 'display:contents' });

const fmtTime = (s) => {
  if (!isFinite(s) || s < 0) s = 0;
  s = Math.floor(s);
  const hh = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = String(s % 60).padStart(2, '0');
  return hh ? `${hh}:${String(m).padStart(2, '0')}:${sec}` : `${m}:${sec}`;
};
const fmtCount = (n) => new Intl.NumberFormat('en', { notation: n >= 10000 ? 'compact' : 'standard' }).format(n);
const plural = (n, w) => `${fmtCount(n)} ${w}${n === 1 ? '' : 's'}`;
const idOf = (uri) => String(uri || '').split(':').pop();

function artistLinks(artists) {
  const frag = document.createDocumentFragment();
  (artists || []).forEach((a, i) => {
    if (i) frag.append(', ');
    const route = a.type === 'show' ? 'show' : a.type === 'ytartist' ? 'ytartist' : 'artist';
    frag.append(a.id ? h('a', { href: `#${route}/${a.id}`, text: a.name, onclick: (e) => e.stopPropagation() }) : a.name);
  });
  return frag;
}

let toastTimer;
function toast(msg, isError = false) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.toggle('error', isError);
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), isError ? 5200 : 2600);
}

class ApiError extends Error {
  constructor(msg, code) {
    super(msg);
    this.code = code;
  }
}
async function api(name, ...args) {
  const r = await ft[name](...args);
  if (!r || !r.ok) {
    const err = new ApiError((r && r.error) || 'Something went wrong', r && r.code);
    if (name !== 'login' && (err.code === 401 || /NOT_SIGNED_IN/.test(err.message))) {
      showSignIn();
    }
    throw err;
  }
  return r.data;
}

// ── state ──────────────────────────────────────────────────────────────────────
const state = {
  user: null,
  myId: '',
  playlists: [], // from Spotify (followed + yours)
  local: [], // playlists saved only on this PC
  libFilter: (() => { try { return localStorage.getItem('ft.libFilter') || ''; } catch { return ''; } })(),
  liked: new Set(),
  cache: new Map(), // view data cache: key -> { at, data }
  queue: { tracks: [], original: [], pos: -1, source: null, sourceName: '' },
  shuffle: false,
  repeat: 'off', // off | all | one
  // Downloads: progress of each downloaded collection and which songs are saved.
  dl: { version: -1, collections: {}, uris: new Set(), list: [], downloading: null, paused: '' },
  ytlib: [], // YouTube Music playlists and albums saved to Your Library
  ytLiked: [], // YouTube Music songs you liked (kept on this device, newest first)
  extras: {}, // YouTube songs added to your Spotify playlists, kept on this device: id -> [track]
};
// Liked Songs: your Spotify likes and the YouTube songs you liked, newest first.
const withYtLikes = (tracks) => {
  const base = (tracks || []).filter((t) => !isYt(t));
  if (!state.ytLiked.length) return base;
  const at = (t) => Date.parse(t.addedAt || '') || 0;
  return [...base, ...state.ytLiked].sort((a, b) => at(b) - at(a));
};
// A Spotify playlist's songs plus the YouTube songs you added to it on this device (at the end).
const withExtras = (id, tracks) => {
  const more = state.extras[id] || [];
  const base = (tracks || []).filter((t) => !t.extra);
  return more.length ? [...base, ...more] : base;
};
const YT_LIKED = 'Liked YouTube Music songs';

// Page data, shown at once whenever there's a copy (even an old one) and quietly brought up
// to date behind it: pages never sit on a loading screen just to show what you saw before.
// A page whose data changed while you look at it is redrawn in place (same scroll spot).
let viewKeys = new Set(); // data the current page was drawn from
const refreshing = new Map();
function cached(key, maxAgeMs, loader, { forView = true } = {}) {
  if (forView) viewKeys.add(key);
  const hit = state.cache.get(key);
  if (hit && !hit.partial && Date.now() - hit.at < maxAgeMs) return Promise.resolve(hit.data);
  if (hit && !(hit.partial && !forView)) {
    refreshBehind(key, loader);
    return Promise.resolve(hit.data);
  }
  if (refreshing.has(key)) return refreshing.get(key);
  return fetchInto(key, loader);
}
function fetchInto(key, loader) {
  const job = loader()
    .then((data) => {
      state.cache.set(key, { at: Date.now(), data });
      saveSnapshotSoon();
      return data;
    })
    .finally(() => refreshing.delete(key));
  refreshing.set(key, job);
  return job;
}
function refreshBehind(key, loader) {
  if (refreshing.has(key)) return;
  const before = state.cache.get(key);
  fetchInto(key, loader)
    .then((data) => {
      if (before && JSON.stringify(before.data) === JSON.stringify(data)) return;
      if (viewKeys.has(key)) route({ keepScroll: true });
    })
    .catch(() => {}); // offline or Spotify hiccup: the copy on screen stays
}
// Fill the cache ahead of time (hovering a link, or just after start) so a page opens at once.
function warm(key, maxAgeMs, loader) {
  const hit = state.cache.get(key);
  if ((hit && !hit.partial && Date.now() - hit.at < maxAgeMs) || refreshing.has(key)) return Promise.resolve();
  return fetchInto(key, loader).catch(() => {});
}

// ── saved copy of the screens (opened instantly on the next start) ─────────────
const SNAPSHOT_KEYS = /^(home$|liked$|playlist:|album:|artist:|show:|discography:|ytartist:|ytalbum:|ytplaylist:)/;
let snapshotTimer = null;
function saveSnapshotSoon() {
  if (!state.user || snapshotTimer) return;
  snapshotTimer = setTimeout(() => {
    snapshotTimer = null;
    saveSnapshot();
  }, 2500);
}
function saveSnapshot() {
  if (!state.user) return;
  const pages = {};
  let budget = 2_500_000;
  const entries = [...state.cache.entries()].filter(([k]) => SNAPSHOT_KEYS.test(k)).sort((a, b) => b[1].at - a[1].at).slice(0, 30);
  for (const [k, v] of entries) {
    let data = v.data;
    let partial = !!v.partial;
    // Long lists: keep the first few hundred; the rest loads when the page is opened.
    if (data && Array.isArray(data.tracks) && data.tracks.length > 300) {
      data = { ...data, tracks: data.tracks.slice(0, 300) };
      partial = true;
    }
    const size = JSON.stringify(data).length;
    if (size > budget) continue;
    budget -= size;
    pages[k] = { at: v.at, data, partial };
  }
  ft.uiCacheSet({
    v: 1,
    user: state.user,
    myId: state.myId,
    playlists: state.playlists,
    local: state.local,
    artists: state.artists || null,
    shows: state.shows || null,
    ytlib: state.ytlib,
    liked: [...state.liked].slice(0, 5000),
    pages,
  }).catch(() => {});
}
function applySnapshot(snap) {
  state.myId = snap.myId || '';
  state.playlists = Array.isArray(snap.playlists) ? snap.playlists : [];
  state.local = Array.isArray(snap.local) ? snap.local : [];
  if (snap.artists) state.artists = snap.artists;
  if (snap.shows) state.shows = snap.shows;
  if (Array.isArray(snap.ytlib)) state.ytlib = snap.ytlib;
  (snap.liked || []).forEach((u) => { if (!/^ytm:/.test(u)) state.liked.add(u); });
  for (const [k, v] of Object.entries(snap.pages || {})) if (!state.cache.has(k)) state.cache.set(k, v);
}

// ── colour from artwork (drives the player tint and page headers) ──────────────
const colorCache = new Map();
function artColor(url) {
  if (!url) return Promise.resolve(null);
  if (colorCache.has(url)) return Promise.resolve(colorCache.get(url));
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const c = document.createElement('canvas');
        c.width = c.height = 24;
        const ctx = c.getContext('2d', { willReadFrequently: true });
        ctx.drawImage(img, 0, 0, 24, 24);
        const d = ctx.getImageData(0, 0, 24, 24).data;
        // Weight saturated, mid-bright pixels more so greys don't win.
        let r = 0, g = 0, b = 0, wsum = 0;
        for (let i = 0; i < d.length; i += 4) {
          const [hh, s, l] = rgbToHsl(d[i], d[i + 1], d[i + 2]);
          const w = 0.15 + s * s * (1 - Math.abs(l - 0.5) * 1.6);
          r += d[i] * w; g += d[i + 1] * w; b += d[i + 2] * w; wsum += w;
        }
        const res = [r / wsum, g / wsum, b / wsum];
        colorCache.set(url, res);
        resolve(res);
      } catch {
        colorCache.set(url, null);
        resolve(null);
      }
    };
    img.onerror = () => resolve(null);
    img.src = url;
  });
}
function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let hh = 0, s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    hh = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
    hh /= 6;
  }
  return [hh, s, l];
}
function hslToRgb(hh, s, l) {
  if (!s) return [l * 255, l * 255, l * 255];
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  const f = (t) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };
  return [f(hh + 1 / 3) * 255, f(hh) * 255, f(hh - 1 / 3) * 255];
}
function shade(rgb, minL, maxL, maxS = 0.85) {
  const [hh, s, l] = rgbToHsl(...rgb);
  return hslToRgb(hh, Math.min(s, maxS), Math.max(minL, Math.min(maxL, l))).map(Math.round);
}
async function applyPlayerTint(url) {
  const c = await artColor(url);
  const root = document.documentElement.style;
  if (!c) {
    root.removeProperty('--tint');
    return;
  }
  root.setProperty('--tint', shade(c, 0.42, 0.6).join(' '));
}
async function tintHero(el, url) {
  const c = await artColor(url);
  if (c && el.isConnected) {
    const rgb = shade(c, 0.3, 0.42).join(' ');
    el.style.setProperty('--hero', rgb);
    const wrap = el.nextElementSibling;
    if (wrap && wrap.classList.contains('actions-wrap')) wrap.style.setProperty('--hero', rgb);
  }
}

// ── context menu & dialog ──────────────────────────────────────────────────────
function openMenu(x, y, items) {
  const m = $('#menu');
  m.replaceChildren(
    ...items.filter(Boolean).map((it) =>
      it === '-'
        ? h('hr')
        : it.heading
        ? h('div.mhead', { text: it.heading })
        : h('button', { role: 'menuitem', onclick: () => { if (!it.keepOpen) closeMenu(); it.run(); } },
            it.icon ? icon(it.icon) : null, h('span', { text: it.label }), it.side ? h('span.ms', { text: it.side }) : null)
    )
  );
  m.hidden = false;
  const r = m.getBoundingClientRect();
  m.style.left = Math.min(x, innerWidth - r.width - 8) + 'px';
  m.style.top = Math.min(y, innerHeight - r.height - 8) + 'px';
  m.querySelector('button')?.focus();
}
function closeMenu() {
  $('#menu').hidden = true;
}
document.addEventListener('mousedown', (e) => {
  if (!$('#menu').contains(e.target)) closeMenu();
});
document.addEventListener('scroll', closeMenu, true);

function prompt({ title, body, label, placeholder, confirm }) {
  return new Promise((resolve) => {
    const d = $('#dialog');
    const input = h('input', { type: 'text', placeholder, 'aria-label': label });
    const form = h('form', { method: 'dialog' },
      h('h2', { text: title }),
      h('p', { text: body }),
      input,
      h('div.btns',
        h('button.pill', { type: 'button', text: 'Cancel', onclick: () => { d.close(); resolve(null); } }),
        h('button.pill.primary', { type: 'submit', text: confirm })
      )
    );
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      d.close();
      resolve(input.value.trim() || null);
    });
    d.replaceChildren(form);
    d.showModal();
    input.focus();
  });
}

// ── track list ─────────────────────────────────────────────────────────────────
// ctx (optional): { ref, uid, onRemove } when the song is shown inside one of your playlists.
const isEpisode = (t) => !!t && (t.type === 'episode' || /^spotify:episode:/.test(t.uri || ''));
// A song from YouTube Music's own catalog (not on Spotify): it plays as itself.
const isYt = (t) => !!t && (t.type === 'ytm' || /^ytm:track:/.test(t.uri || ''));
const srcMark = (kind) => h(`span.src.${kind === 'ytm' ? 'ytm' : 'spotify'}`, { role: 'img', title: kind === 'ytm' ? 'YouTube Music' : 'Spotify', 'aria-label': kind === 'ytm' ? 'YouTube Music' : 'Spotify' });

// ── downloads ──────────────────────────────────────────────────────────────────
// Like Spotify's: the download button on a playlist, album or Liked Songs saves every song
// on this device so it plays without internet. Downloaded songs get a small green arrow.
const dlKeyOf = (p) => (p.type === 'liked' ? 'liked:me' : p.type === 'ytliked' ? 'ytliked:me' : p.local ? `mine:${p.id}` : ['album', 'playlist', 'ytalbum', 'ytplaylist'].includes(p.type) ? `${p.type}:${p.id}` : null);

function downloadButton(key, getInfo, getTracks) {
  const b = h('button.act-icon.dl-btn', { dataset: { key } }, h('span.dl-ring'), h('span.dl-off', { html: ICONS.download }), h('span.dl-on', { html: ICONS.downloaded }));
  b.onclick = async () => {
    if (b.disabled) return;
    if (state.dl.collections[key]) {
      const ok = await confirmDialog({ title: 'Remove from Downloads?', body: `You won’t be able to play “${getInfo().name}” without an internet connection.`, confirm: 'Remove' });
      if (!ok) return;
      try {
        applyDownloads(await api('downloadRemove', key));
        toast('Removed from Downloads');
      } catch (e) {
        toast(e.message, true);
      }
      return;
    }
    b.disabled = true;
    try {
      const tracks = await getTracks();
      if (!tracks.length) return toast('There’s nothing to download here yet', true);
      applyDownloads(await api('downloadSet', key, getInfo(), tracks));
      lastSync.set(key, syncSig(tracks));
      toast(`Downloading “${getInfo().name}”. It’ll play without internet once it’s done.`);
    } catch (e) {
      toast(`Couldn’t start the download: ${e.message}`, true);
    } finally {
      b.disabled = false;
      paintDl(b);
    }
  };
  paintDl(b);
  return b;
}

function paintDl(b) {
  const c = state.dl.collections[b.dataset.key];
  const on = !!c;
  const done = on && c.done >= c.total;
  b.classList.toggle('on', on);
  b.classList.toggle('done', done);
  b.setAttribute('aria-pressed', String(on));
  b.style.setProperty('--p', on ? (c.total ? c.done / c.total : 1) : 0);
  const label = !on ? 'Download' : done ? 'Downloaded. Click to remove the download' : `Downloading ${c.done} of ${c.total}${state.dl.paused ? ' (paused)' : ''}`;
  b.title = label;
  b.setAttribute('aria-label', label);
}

// Keep a downloaded collection in step with its songs (new songs get downloaded too).
const lastSync = new Map();
const syncSig = (tracks) => tracks.length + ':' + tracks.map((t) => t.uri || t.name).join('|').length + ':' + (tracks[0] && tracks[0].uri) + ':' + (tracks[tracks.length - 1] && tracks[tracks.length - 1].uri);
function syncDownload(key, info, tracks) {
  if (!state.dl.collections[key] || !Array.isArray(tracks)) return;
  const sig = syncSig(tracks);
  if (lastSync.get(key) === sig) return;
  lastSync.set(key, sig);
  api('downloadSet', key, { name: info && info.name, image: info && info.image, owner: info && info.owner }, tracks).then(applyDownloads).catch(() => {});
}

// No internet: draw a downloaded collection from its saved song list.
async function offlineCopy(key, live, draw) {
  if (!state.dl.collections[key]) return false;
  const tracks = await api('downloadTracks', key).catch(() => null);
  if (!tracks || !live()) return !!tracks;
  const item = state.dl.list.find((x) => x.key === key) || {};
  draw(tracks, { name: item.name || 'Download', image: item.image || null, owner: item.owner || '', id: key.split(':')[1], total: tracks.length });
  toast('You’re offline. Showing your downloaded copy.');
  return true;
}

function applyDownloads(st) {
  if (!st || !st.collections) return;
  const keysBefore = Object.keys(state.dl.collections).sort().join(',');
  state.dl.collections = st.collections;
  state.dl.downloading = st.downloading;
  state.dl.paused = st.paused || '';
  state.dl.version = st.version;
  const uris = new Set(st.uris || []);
  const changed = uris.size !== state.dl.uris.size || [...uris].some((u) => !state.dl.uris.has(u));
  state.dl.uris = uris;
  if (changed) document.querySelectorAll('.row[data-uri]').forEach((r) => r.classList.toggle('saved', uris.has(r.dataset.uri)));
  document.querySelectorAll('.dl-btn').forEach(paintDl);
  document.querySelectorAll('a[data-dl]').forEach(paintLibDl);
  if (Object.keys(st.collections).sort().join(',') !== keysBefore) {
    api('downloadsList').then((l) => {
      state.dl.list = l;
      if (state.libFilter === 'downloaded') renderLibrary();
      else document.querySelectorAll('a[data-dl]').forEach(paintLibDl);
    }).catch(() => {});
  }
  const ds = document.querySelector('.downloads-status');
  if (ds) ds.textContent = downloadsLine();
}
function paintLibDl(a) {
  const c = state.dl.collections[a.dataset.dl];
  a.classList.toggle('dl-on', !!c);
  a.classList.toggle('dl-busy', !!c && c.done < c.total);
}
function downloadsLine() {
  const n = state.dl.uris.size;
  const lists = Object.keys(state.dl.collections).length;
  if (!lists) return 'Nothing downloaded yet. Use the download button on a playlist, album or Liked Songs.';
  let line = `${plural(n, 'song')} downloaded from ${lists === 1 ? '1 playlist or album' : `${lists} playlists and albums`}.`;
  if (state.dl.paused) line += ` ${state.dl.paused}`;
  else if (state.dl.downloading) line += ` Downloading “${state.dl.downloading.name}” (${state.dl.downloading.left} left).`;
  const failed = Object.values(state.dl.collections).reduce((a, c) => a + (c.failed || 0), 0);
  if (failed) line += ` ${plural(failed, 'song')} couldn’t be downloaded (they’ll be tried again next time FreeTune starts).`;
  return line;
}

function trackMenu(track, e, ctx = null) {
  const x = e.clientX, y = e.clientY;
  if (isYt(track)) {
    return openMenu(x, y, [
      { icon: 'plus', label: 'Add to playlist', side: '›', keepOpen: true, run: () => addToPlaylistMenu([track], x, y) },
      ctx && ctx.ref ? { icon: 'trash', label: 'Remove from this playlist', run: () => ctx.onRemove && ctx.onRemove() } : null,
      track.videoId ? { icon: 'heart', label: likeLabel(track), run: () => toggleLike(track) } : null,
      { icon: 'next', label: 'Play next', run: () => player.playNext(track) },
      { icon: 'queue', label: 'Add to queue', run: () => player.enqueue(track) },
      '-',
      track.artists[0] && track.artists[0].id ? { icon: 'artist', label: 'Go to artist', run: () => go(`ytartist/${track.artists[0].id}`) } : null,
      track.album && track.album.id ? { icon: 'album', label: 'Go to album', run: () => go(`ytalbum/${track.album.id}`) } : null,
      { icon: 'link', label: 'Open on YouTube Music', run: () => api('openExternal', `https://music.youtube.com/watch?v=${track.videoId}`) },
    ]);
  }
  if (isEpisode(track)) {
    return openMenu(x, y, [
      { icon: 'plus', label: 'Add to playlist', side: '›', keepOpen: true, run: () => addToPlaylistMenu([track], x, y) },
      ctx && ctx.ref ? { icon: 'trash', label: 'Remove from this playlist', run: () => ctx.onRemove && ctx.onRemove() } : null,
      { icon: 'next', label: 'Play next', run: () => player.playNext(track) },
      { icon: 'queue', label: 'Add to queue', run: () => player.enqueue(track) },
      '-',
      track.show && track.show.id ? { icon: 'album', label: 'Go to podcast', run: () => go(`show/${track.show.id}`) } : null,
    ]);
  }
  const items = [
    track.uri ? { icon: 'plus', label: 'Add to playlist', side: '›', keepOpen: true, run: () => addToPlaylistMenu([track], x, y) } : null,
    ctx && ctx.ref ? { icon: 'trash', label: 'Remove from this playlist', run: () => ctx.onRemove && ctx.onRemove() } : null,
    track.uri ? { icon: 'heart', label: likeLabel(track), run: () => toggleLike(track) } : null,
    { icon: 'next', label: 'Play next', run: () => player.playNext(track) },
    { icon: 'queue', label: 'Add to queue', run: () => player.enqueue(track) },
    '-',
    track.artists[0] && track.artists[0].id ? { icon: 'artist', label: 'Go to artist', run: () => go(`artist/${track.artists[0].id}`) } : null,
    track.album && track.album.id ? { icon: 'album', label: 'Go to album', run: () => go(`album/${track.album.id}`) } : null,
    '-',
    { icon: 'link', label: 'Wrong song? Use a different YouTube link…', run: () => fixMatch(track) },
  ];
  openMenu(x, y, items);
}

async function fixMatch(track) {
  const link = await prompt({
    title: 'Use a different recording',
    body: `Paste a YouTube or YouTube Music link for “${track.name}”. FreeTune will always play that one for this song.`,
    label: 'YouTube link',
    placeholder: 'https://music.youtube.com/watch?v=…',
    confirm: 'Use this recording',
  });
  if (!link) return;
  try {
    await api('override', track.uri, link);
    toast('Saved. This song will use that recording from now on.');
    if (player.current() && player.current().uri === track.uri) player.reload();
  } catch (e) {
    toast(e.message, true);
  }
}

// Spotify songs go to your Spotify Liked Songs; YouTube Music songs go to "Liked YouTube
// Music songs", which is kept on this device (FreeTune never signs in to Google).
const likeLabel = (t) => (state.liked.has(t.uri) ? 'Remove from ' : 'Save to ') + (isYt(t) ? YT_LIKED : 'Liked songs');
async function toggleLike(track) {
  const was = state.liked.has(track.uri);
  setLiked(track.uri, !was);
  if (isYt(track)) {
    try {
      await api('ytLike', track, !was);
      setYtLiked(await api('ytLiked'));
      toast(was ? `Removed from ${YT_LIKED}` : `Saved to ${YT_LIKED}`);
    } catch (e) {
      setLiked(track.uri, was);
      toast(`Couldn't update ${YT_LIKED}: ${e.message}`, true);
    }
    return;
  }
  try {
    await api('setLiked', [track.uri], !was);
    toast(was ? 'Removed from Liked songs' : 'Saved to Liked songs');
    state.cache.delete('liked');
  } catch (e) {
    setLiked(track.uri, was);
    toast(`Couldn't update Liked songs: ${e.message}`, true);
  }
}
function setLiked(uri, on) {
  if (on) state.liked.add(uri);
  else state.liked.delete(uri);
  document.querySelectorAll(`.like[data-uri="${CSS.escape(uri)}"]`).forEach((b) => b.setAttribute('aria-pressed', String(on)));
  syncNowPlayingLike();
}
// The liked YouTube Music songs changed (or were read at start): hearts, the library entry,
// its download and its page follow.
function setYtLiked(list) {
  if (!Array.isArray(list)) return;
  const before = state.ytLiked;
  state.ytLiked = list;
  for (const u of [...state.liked]) if (/^ytm:/.test(u)) state.liked.delete(u);
  for (const t of list) state.liked.add(t.uri);
  document.querySelectorAll('.like[data-uri^="ytm:"]').forEach((b) => b.setAttribute('aria-pressed', String(state.liked.has(b.dataset.uri))));
  syncNowPlayingLike();
  if (!!before.length !== !!list.length) renderPinned();
  else document.querySelectorAll('#side-pinned .yt-count').forEach((el) => (el.textContent = plural(list.length, 'song')));
  syncDownload('ytliked:me', { name: YT_LIKED }, list);
  if ((location.hash === '#ytliked' || location.hash === '#liked') && before !== list) route({ keepScroll: true });
}

function fmtAdded(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d)) return '';
  const days = Math.floor((Date.now() - d) / 864e5);
  if (days < 1) return 'Today';
  if (days < 7) return `${days} day${days === 1 ? '' : 's'} ago`;
  if (days < 30) { const w = Math.floor(days / 7); return `${w} week${w === 1 ? '' : 's'} ago`; }
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

function trackRow(t, i, list, opts) {
  const menuCtx = () => (opts.edit ? { ref: opts.edit.ref, uid: t.uid, onRemove: () => opts.edit.remove(t) } : null);
  const like = h('button.icon-btn.like', {
    'aria-label': isYt(t) ? `Save to ${YT_LIKED}` : 'Save to Liked songs',
    'aria-pressed': String(state.liked.has(t.uri)),
    dataset: { uri: t.uri || '' },
    onclick: (e) => { e.stopPropagation(); toggleLike(t); },
  }, icon('heart'));
  const row = h('div.row', {
    role: 'row',
    tabindex: '0',
    dataset: { uri: t.uri || '', idx: i },
    ondblclick: () => player.playList(list, i, opts.source, opts.sourceName),
    onkeydown: (e) => { if (e.key === 'Enter') player.playList(list, i, opts.source, opts.sourceName); },
    oncontextmenu: (e) => { e.preventDefault(); trackMenu(t, e, menuCtx()); },
    draggable: t.uri ? 'true' : null,
    ondragstart: (e) => {
      // Drag a song onto one of your playlists in the sidebar to add it, or within your
      // own playlist to move it.
      dragData = { tracks: [t], uid: t.uid || null, list: opts.edit ? opts.edit.ref : null };
      e.dataTransfer.effectAllowed = 'copyMove';
      e.dataTransfer.setData('text/plain', `${t.name} – ${t.artists.map((a) => a.name).join(', ')}`);
      row.classList.add('dragging');
    },
    ondragend: () => { row.classList.remove('dragging'); dragData = null; document.querySelectorAll('.drop, .drop-before, .drop-after').forEach((el) => el.classList.remove('drop', 'drop-before', 'drop-after')); },
  },
    h('div.n',
      h('span.num', { text: String(i + 1) }),
      h('button.pbtn', { 'aria-label': `Play ${t.name}`, onclick: (e) => { e.stopPropagation(); player.playList(list, i, opts.source, opts.sourceName); } }, icon('play'))
    ),
    h('div.main',
      opts.showArt !== false ? h('img', { src: t.image || '', alt: '', loading: 'lazy', decoding: 'async' }) : null,
      h('div.tt', h('div.name', { text: t.name }), h('div.by', h('span.dl-mark', { 'aria-label': 'Downloaded', title: 'Downloaded' }), t.extra || (isYt(t) && opts.source === 'liked:me') ? h('span.src.ytm', { role: 'img', 'aria-label': 'From YouTube, only on this device', title: 'From YouTube, only on this device' }) : null, artistLinks(t.artists)))
    ),
    opts.showAlbum !== false
      ? h('div.alb', t.album && t.album.id ? h('a', { href: `#${t.album.type === 'show' ? 'show' : t.album.type === 'ytalbum' ? 'ytalbum' : 'album'}/${t.album.id}`, text: t.album.name }) : (t.album && t.album.name) || '')
      : null,
    opts.showAdded ? h('div.added', { text: fmtAdded(t.addedAt) }) : null,
    t.uri && !isEpisode(t) ? like : h('span.like-slot'),
    h('div.dur', { text: t.durationMs ? fmtTime(t.durationMs / 1000) : '' }),
    h('button.icon-btn.more', { 'aria-label': `More options for ${t.name}`, onclick: (e) => { e.stopPropagation(); trackMenu(t, e, menuCtx()); } }, icon('more'))
  );
  if (opts.edit && t.uid) enableReorder(row, t, opts.edit);
  if (t.uri && state.dl.uris.has(t.uri)) row.classList.add('saved');
  if (t.uri && player.current() && player.current().uri === t.uri) row.classList.add('current');
  if (t.playable === false) row.classList.add('unplayable');
  return row;
}

function trackList(list, opts = {}) {
  const wrap = h('div.tracks', { role: 'table', 'aria-label': opts.label || 'Songs' });
  if (opts.showAlbum === false && !opts.addedLabel) { wrap.classList.add('no-album'); opts.showAdded = false; }
  else if (opts.showAlbum === false) wrap.classList.add('no-album', 'with-date');
  else if (!opts.showAdded) wrap.classList.add('no-date');
  if (opts.header !== false) {
    const mark = h('div.stick-mark');
    stickWatch.observe(mark);
    wrap.append(
      mark,
      h('div.head', { role: 'row' },
        h('span.r', { text: '#' }),
        h('span', { text: 'Title' }),
        opts.showAlbum !== false ? h('span.h-alb', { text: 'Album' }) : null,
        opts.showAdded ? h('span.h-added', { text: opts.addedLabel || 'Date added' }) : null,
        h('span'),
        h('span.clock', { title: 'Duration', html: ICONS.clock }),
        h('span')
      )
    );
  }
  const body = h('div');
  wrap.append(body);
  // The first screenful is drawn right away; the rest follows in small batches between
  // frames, so even a 5,000-song playlist opens without a pause.
  let drawn = 0;
  let pending = false;
  let group = null;
  const pump = () => {
    pending = false;
    if (!wrap.isConnected && drawn > 0) return;
    const end = Math.min(list.length, drawn + (drawn ? 150 : 40));
    // Rows go in groups of 50; a group that's off screen isn't laid out or painted.
    for (let i = drawn; i < end; i++) {
      if (!group || group.childElementCount >= 50) {
        group = h('div.rows');
        body.append(group);
      }
      group.append(trackRow(list[i], i, list, opts));
    }
    drawn = end;
    if (drawn < list.length) {
      pending = true;
      requestAnimationFrame(() => setTimeout(pump, 0));
    } else requestAnimationFrame(markCurrent);
  };
  const appendRows = () => {
    if (!pending) pump();
  };
  pump();
  wrap.appendFrom = appendRows; // used when more pages arrive (they're added to the same list)
  return wrap;
}

function markCurrent() {
  const cur = player.current();
  document.querySelectorAll('.row.current, .qrow.current').forEach((r) => r.classList.remove('current'));
  if (!cur) return;
  document.querySelectorAll(`.row[data-uri="${CSS.escape(cur.uri || '')}"]`).forEach((r) => {
    r.classList.add('current');
    const num = r.querySelector('.num');
    if (num && !num.querySelector('.eq')) num.replaceChildren(h('span.eq', h('i'), h('i'), h('i')));
  });
  document.querySelectorAll('.row:not(.current) .num .eq').forEach((eq) => {
    const row = eq.closest('.row');
    eq.parentElement.textContent = String(Number(row.dataset.idx) + 1);
  });
  document.querySelectorAll('.side-list a').forEach((a) => a.classList.toggle('playing', a.dataset.source === state.queue.source));
}

// ── tiles & shelves ────────────────────────────────────────────────────────────
function subtitle(item) {
  if (item.type === 'artist' || item.type === 'ytartist') return 'Artist';
  if (item.type === 'ytalbum') {
    const who = (item.artists || []).map((a) => a.name).join(', ');
    const kind = item.albumType === 'single' ? 'Single' : item.albumType === 'ep' ? 'EP' : '';
    return [kind, item.year, who].filter(Boolean).join(' • ') || 'Album';
  }
  if (item.type === 'ytplaylist') return item.owner ? `By ${item.owner}` : 'Playlist';
  if (item.type === 'show') return item.publisher || 'Podcast';
  if (item.type === 'album') {
    const who = (item.artists || []).map((a) => a.name).join(', ');
    return [item.year, who].filter(Boolean).join(', ') || 'Album';
  }
  return item.description || (item.owner ? `By ${item.owner}` : 'Playlist');
}
function coverEl(p, cls = 'cov') {
  if (p.type === 'liked') return h(`div.${cls}.liked-cov`, { html: ICONS.heart });
  if (p.type === 'ytliked') return h(`div.${cls}.liked-cov.yt`, { html: ICONS.heart });
  if (p.local && p.covers && p.covers.length >= 4) return h(`div.${cls}.mosaic`, p.covers.slice(0, 4).map((src) => h('img', { src, alt: '', loading: 'lazy' })));
  if (p.image) return h(`img.${cls}${p.type === 'artist' ? '.round' : ''}`, { src: p.image, alt: '', loading: 'lazy' });
  return h(`div.${cls}.note-cov${p.type === 'artist' ? '.round' : ''}`, { html: p.type === 'artist' ? ICONS.artist : ICONS.note });
}

function tile(item) {
  const href = item.local ? `#mine/${item.id}` : `#${item.type}/${item.id}`;
  const quick = item.type !== 'artist' && item.type !== 'ytartist'
    ? h('button.quick', {
        'aria-label': `Play ${item.name}`,
        onclick: (e) => { e.preventDefault(); e.stopPropagation(); playCollection(item); },
      }, icon('play'))
    : null;
  return h(`a.tile.${item.type}${item.type === 'ytartist' ? '.artist' : ''}`, { href, title: item.name },
    h('div.art', item.local ? coverEl(item, 'cover-fill') : item.image ? h('img', { src: item.image, alt: '', loading: 'lazy', decoding: 'async' }) : null, quick),
    h('div.t', { text: item.name }),
    h('div.s', item.source === 'ytm' ? srcMark('ytm') : null, subtitle(item))
  );
}
const shelf = (title, items) => (items && items.length ? [h('h2', { text: title }), h('div.shelf', items.map(tile))] : []);

async function playCollection(item, { shuffle = false } = {}) {
  try {
    let tracks = [];
    if (item.type === 'playlist' && item.local) tracks = (await api('localPlaylist', item.id)).tracks;
    else if (item.type === 'playlist') tracks = withExtras(item.id, (await cached(`playlist:${item.id}`, PLAYLIST_TTL, () => loadPlaylistAll(item.id, null), { forView: false })).tracks);
    else if (item.type === 'album') tracks = (await cached(`album:${item.id}`, 30 * 60 * 1000, () => api('album', item.id), { forView: false })).tracks;
    else if (item.type === 'artist') tracks = (await cached(`artist:${item.id}`, 30 * 60 * 1000, () => api('artist', item.id), { forView: false })).topTracks;
    else if (item.type === 'liked') tracks = withYtLikes((await cached('liked', LIKED_TTL, () => loadLikedAll(null), { forView: false })).tracks);
    else if (item.type === 'ytliked') tracks = state.ytLiked.slice();
    else if (item.type === 'show') tracks = (await api('show', item.id)).episodes; // newest first
    else if (item.type === 'ytalbum') tracks = (await cached(`ytalbum:${item.id}`, 60 * 60 * 1000, () => api('ytAlbum', item.id), { forView: false })).tracks;
    else if (item.type === 'ytplaylist') tracks = (await cached(`ytplaylist:${item.id}`, 15 * 60 * 1000, () => api('ytPlaylist', item.id), { forView: false })).tracks;
    else if (item.type === 'ytartist') tracks = (await cached(`ytartist:${item.id}`, 30 * 60 * 1000, () => api('ytArtist', item.id), { forView: false })).topSongs;
    if (!tracks.length) return toast('Nothing to play here', true);
    if (shuffle && !state.shuffle) player.setShuffle(true);
    player.playList(tracks, shuffle ? Math.floor(Math.random() * tracks.length) : 0, item.local ? `mine:${item.id}` : `${item.type}:${item.id}`, item.name);
  } catch (e) {
    // Offline: a downloaded collection still plays from its saved song list.
    const key = dlKeyOf(item);
    const saved = key && state.dl.collections[key] ? await api('downloadTracks', key).catch(() => null) : null;
    if (saved && saved.length) return player.playList(saved, shuffle ? Math.floor(Math.random() * saved.length) : 0, item.local ? `mine:${item.id}` : `${item.type}:${item.id}`, item.name);
    toast(`Couldn't load “${item.name}”: ${e.message}`, true);
  }
}


// ── your own playlists ─────────────────────────────────────────────────────────
// Two kinds: in your Spotify account (show up on your phone too) or only on this PC.
// A "ref" points at one: { local: true|false, id }.
let dragData = null;
const refOf = (p) => ({ local: !!p.local, id: p.id });
const hrefOf = (p) => (p.local ? `#mine/${p.id}` : `#playlist/${p.id}`);
const isMineSpotify = (p) => !!(p && !p.local && state.myId && p.ownerId === state.myId);
function editableLists() {
  return [...state.local, ...state.playlists.filter(isMineSpotify)];
}

async function addTracksTo(p, tracks, { reroute = true } = {}) {
  try {
    let r;
    if (!p.local && tracks.some(isYt)) {
      // Spotify can't hold YouTube songs: those are kept on this device and shown at the end.
      const yt = tracks.filter(isYt);
      const sp = tracks.filter((t) => !isYt(t));
      const x = await api('playlistExtrasAdd', p.id, yt);
      state.extras[p.id] = x.list;
      r = sp.length ? await api('addToPlaylist', refOf(p), sp) : { added: 0, skipped: 0 };
      r = { added: r.added + x.added, skipped: (r.skipped || 0) + x.skipped };
    } else r = await api('addToPlaylist', refOf(p), tracks);
    if (r.added === 0) toast(tracks.length === 1 ? `Already in “${p.name}”` : `Those are already in “${p.name}”`);
    else toast(`Added to “${p.name}”${r.skipped ? ` (${r.skipped} already there)` : ''}`);
    state.cache.delete(`pl:${p.id}`);
    if (reroute && location.hash === hrefOf(p)) route();
    refreshLibrary();
  } catch (e) {
    toast(`Couldn't add to “${p.name}”: ${e.message}`, true);
  }
}

async function likeYouTubeLink() {
  const link = await prompt({
    title: 'Like a song from YouTube',
    body: 'Paste a YouTube or YouTube Music link. The song goes in your Liked songs here (and Liked YouTube Music songs), kept on this device. Spotify isn’t told.',
    label: 'YouTube link',
    placeholder: 'https://www.youtube.com/watch?v=…',
    confirm: 'Like song',
  });
  if (!link) return;
  try {
    const t = await api('ytSong', link);
    if (state.liked.has(t.uri)) return toast('Already in your Liked songs');
    await toggleLike(t);
  } catch (e) {
    toast(`Couldn’t add that link: ${e.message}`, true);
  }
}

async function addYouTubeLink(p, after) {
  const link = await prompt({
    title: 'Add a song from YouTube',
    body: p.local
      ? `Paste a YouTube or YouTube Music link. The song is added to “${p.name}” and plays like any other song.`
      : `Paste a YouTube or YouTube Music link. The song shows at the end of “${p.name}” in FreeTune on this device. Spotify isn’t told about it.`,
    label: 'YouTube link',
    placeholder: 'https://www.youtube.com/watch?v=…',
    confirm: 'Add song',
  });
  if (!link) return;
  try {
    const t = await api('ytSong', link);
    await addTracksTo(p, [t], { reroute: false });
    if (after) after();
  } catch (e) {
    toast(`Couldn’t add that link: ${e.message}`, true);
  }
}

function addToPlaylistMenu(tracks, x, y) {
  // YouTube songs can go in any of your playlists; in a Spotify one they're kept on this device.
  const lists = editableLists();
  openMenu(x, y, [
    { icon: 'plus', label: 'New playlist', run: async () => { const p = await createPlaylistDialog(); if (p) addTracksTo(p, tracks); } },
    lists.length ? '-' : null,
    ...lists.slice(0, 60).map((p) => ({ icon: p.local ? 'pc' : 'note', label: p.name, side: p.local ? 'This PC' : '', run: () => addTracksTo(p, tracks) })),
    !lists.length ? { heading: 'Playlists you make show up here' } : null,
  ]);
}

// The "Create playlist" dialog: a name, an optional description, and where it lives.
function createPlaylistDialog({ where = localStorage.getItem('ft.newWhere') || 'spotify' } = {}) {
  return new Promise((resolve) => {
    const d = $('#dialog');
    const n = editableLists().length + 1;
    const name = h('input', { type: 'text', value: `My Playlist #${n}`, 'aria-label': 'Name', maxlength: '100' });
    const desc = h('textarea', { placeholder: 'Add an optional description', 'aria-label': 'Description', maxlength: '300' });
    const opt = (value, title, sub, iconName) =>
      h('label', h('input', { type: 'radio', name: 'where', value, checked: where === value ? true : null }), h('span', h('b', icon(iconName), ' ', title), h('small', { text: sub })));
    const form = h('form', { method: 'dialog' },
      h('h2', { text: 'Create playlist' }),
      name,
      desc,
      h('div.where', { role: 'radiogroup', 'aria-label': 'Save to' },
        opt('spotify', 'Your Spotify', 'Shows up on your phone and in Spotify too.', 'cloud'),
        opt('local', 'This PC only', 'Private. Saved only in FreeTune on this computer.', 'pc')
      ),
      h('div.btns',
        h('button.pill', { type: 'button', text: 'Cancel', onclick: () => { d.close(); resolve(null); } }),
        h('button.pill.primary', { type: 'submit', text: 'Create' })
      )
    );
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const w = form.querySelector('input[name="where"]:checked').value;
      const btn = form.querySelector('.pill.primary');
      btn.disabled = true;
      btn.textContent = 'Creating…';
      try {
        const p = await api('createPlaylist', name.value.trim() || `My Playlist #${n}`, desc.value.trim(), w);
        localStorage.setItem('ft.newWhere', w);
        if (p.local) state.local.unshift(p);
        else state.playlists.unshift(p);
        renderLibrary();
        d.close();
        toast(p.local ? `Created “${p.name}” on this PC` : `Created “${p.name}” in your Spotify`);
        resolve(p);
      } catch (err) {
        btn.disabled = false;
        btn.textContent = 'Create';
        toast(`Couldn't create the playlist: ${err.message}${w === 'spotify' ? '. You can make it on this PC instead.' : ''}`, true);
      }
    });
    d.replaceChildren(form);
    d.showModal();
    name.focus();
    name.select();
  });
}

async function createAndOpen(where) {
  const p = await createPlaylistDialog(where ? { where } : undefined);
  if (p) go(hrefOf(p).slice(1));
}

function editDetailsDialog(p) {
  return new Promise((resolve) => {
    const d = $('#dialog');
    const name = h('input', { type: 'text', value: p.name, 'aria-label': 'Name', maxlength: '100' });
    const desc = h('textarea', { 'aria-label': 'Description', placeholder: 'Add an optional description', maxlength: '300' });
    desc.value = p.description || '';
    const form = h('form', { method: 'dialog' },
      h('h2', { text: 'Edit details' }), name, desc,
      h('div.btns',
        h('button.pill', { type: 'button', text: 'Cancel', onclick: () => { d.close(); resolve(null); } }),
        h('button.pill.primary', { type: 'submit', text: 'Save' })
      )
    );
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const changes = { name: name.value.trim() || p.name, description: desc.value.trim() };
      try {
        await api('editPlaylist', refOf(p), changes);
        Object.assign(p, changes);
        for (const x of [...state.local, ...state.playlists]) if (x.id === p.id) Object.assign(x, changes);
        renderLibrary();
        d.close();
        resolve(changes);
      } catch (err) {
        toast(`Couldn't save: ${err.message}`, true);
      }
    });
    d.replaceChildren(form);
    d.showModal();
    name.focus();
  });
}

async function deletePlaylist(p) {
  const ok = await confirmDialog({
    title: `Delete “${p.name}”?`,
    body: p.local ? 'It will be removed from this PC. This can’t be undone.' : 'It will be removed from Your Library in Spotify, on all your devices.',
    confirm: 'Delete',
  });
  if (!ok) return;
  try {
    await api('deletePlaylist', refOf(p));
    if (p.local) state.local = state.local.filter((x) => x.id !== p.id);
    else state.playlists = state.playlists.filter((x) => x.id !== p.id);
    renderLibrary();
    toast(`Deleted “${p.name}”`);
    if (location.hash === hrefOf(p)) go('home');
  } catch (e) {
    toast(`Couldn't delete: ${e.message}`, true);
  }
}

function confirmDialog({ title, body, confirm }) {
  return new Promise((resolve) => {
    const d = $('#dialog');
    const form = h('form', { method: 'dialog' },
      h('h2', { text: title }), h('p', { text: body }),
      h('div.btns',
        h('button.pill', { type: 'button', text: 'Cancel', onclick: () => { d.close(); resolve(false); } }),
        h('button.pill.primary', { type: 'submit', text: confirm })
      )
    );
    form.addEventListener('submit', (e) => { e.preventDefault(); d.close(); resolve(true); });
    d.replaceChildren(form);
    d.showModal();
    form.querySelector('.pill.primary').focus();
  });
}

function playlistMenu(p, x, y) {
  const mine = p.local || isMineSpotify(p);
  openMenu(x, y, [
    { icon: 'play', label: 'Play', run: () => playCollection(p) },
    { icon: 'shuffle', label: 'Shuffle play', run: () => playCollection(p, { shuffle: true }) },
    mine ? '-' : null,
    mine ? { icon: 'pencil', label: 'Edit details', run: async () => { if (await editDetailsDialog(p)) { if (location.hash === hrefOf(p)) route(); } } } : null,
    mine ? { icon: 'trash', label: 'Delete', run: () => deletePlaylist(p) } : null,
    '-',
    { icon: 'plus', label: 'Create playlist', run: () => createAndOpen() },
  ]);
}

// Drag to reorder inside your own playlist.
function enableReorder(row, t, edit) {
  row.addEventListener('dragover', (e) => {
    if (!dragData || !dragData.uid || !dragData.list || dragData.list.id !== edit.ref.id || dragData.uid === t.uid) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    const r = row.getBoundingClientRect();
    const after = e.clientY > r.top + r.height / 2;
    row.classList.toggle('drop-after', after);
    row.classList.toggle('drop-before', !after);
  });
  row.addEventListener('dragleave', () => row.classList.remove('drop-before', 'drop-after'));
  row.addEventListener('drop', (e) => {
    if (!dragData || !dragData.uid || dragData.uid === t.uid) return;
    e.preventDefault();
    const after = row.classList.contains('drop-after');
    row.classList.remove('drop-before', 'drop-after');
    edit.move(dragData.uid, t.uid, after);
  });
}

// Shared by Spotify playlists you own and playlists on this PC.
function editableHelpers(p, tracksRef, rerender) {
  const ref = refOf(p);
  return {
    ref,
    async remove(t) {
      if (t.extra) {
        try {
          state.extras[p.id] = await api('playlistExtrasRemove', p.id, [t.uri]);
          const i = tracksRef.list.findIndex((x) => x.extra && x.uri === t.uri);
          if (i >= 0) tracksRef.list.splice(i, 1);
          toast(`Removed from “${p.name}”`);
          rerender();
        } catch (e) {
          toast(`Couldn't remove it: ${e.message}`, true);
        }
        return;
      }
      try {
        await api('removeFromPlaylist', ref, [t.uid]);
        const i = tracksRef.list.findIndex((x) => x.uid === t.uid);
        if (i >= 0) tracksRef.list.splice(i, 1);
        toast(`Removed from “${p.name}”`);
        rerender();
        refreshLibrary();
      } catch (e) {
        toast(`Couldn't remove it: ${e.message}`, true);
      }
    },
    async move(uid, targetUid, after) {
      const list = tracksRef.list;
      const from = list.findIndex((x) => x.uid === uid);
      let to = list.findIndex((x) => x.uid === targetUid) + (after ? 1 : 0);
      if (from < 0 || to < 0) return;
      const beforeUid = list[to] ? list[to].uid : null;
      if (beforeUid === uid) return;
      const [item] = list.splice(from, 1);
      to = beforeUid ? list.findIndex((x) => x.uid === beforeUid) : list.length;
      list.splice(to, 0, item);
      rerender();
      try {
        await api('movePlaylistItems', ref, [uid], beforeUid);
      } catch (e) {
        toast(`Couldn't move it: ${e.message}`, true);
        route();
      }
    },
  };
}

// "Let's find something for your playlist": search right inside your own playlist.
function finder(p, onAdded) {
  const results = h('div.results');
  const input = h('input', { type: 'search', placeholder: 'Search for songs', 'aria-label': 'Search for songs to add' });
  let timer;
  let req = 0;
  input.addEventListener('input', () => {
    clearTimeout(timer);
    const q = input.value.trim();
    if (!q) { results.replaceChildren(); return; }
    timer = setTimeout(async () => {
      const mine = ++req;
      try {
        const r = await cached(`search:${q.toLowerCase()}`, 5 * 60 * 1000, () => api('search', q));
        if (mine !== req) return;
        results.replaceChildren(...r.tracks.slice(0, 10).map((t) =>
          h('div.frow', { ondblclick: () => player.playList([t], 0, `search:${q}`, q) },
            h('div.main', h('img', { src: t.image || '', alt: '', loading: 'lazy' }), h('div', { style: 'min-width:0' }, h('div.name', { text: t.name }), h('div.by', { text: t.artists.map((a) => a.name).join(', ') }))),
            h('div.alb', { text: (t.album && t.album.name) || '' }),
            h('button.pill', { text: 'Add', onclick: async (e) => { const b = e.currentTarget; b.disabled = true; await addTracksTo(p, [t], { reroute: false }); b.textContent = 'Added'; onAdded && onAdded(); } })
          )
        ));
        if (!r.tracks.length) results.replaceChildren(h('p.muted', { text: `No songs found for “${q}”` }));
      } catch (e) {
        results.replaceChildren(h('p.muted', { text: e.message }));
      }
    }, 300);
  });
  return h('section.finder',
    h('h2', { text: 'Let’s find something for your playlist' }),
    h('label.field', icon('search') || null, input),
    results
  );
}

// ── routing ────────────────────────────────────────────────────────────────────
const main = $('#main');
let renderToken = 0;
function go(route) {
  location.hash = route;
}
window.addEventListener('hashchange', route);
$('#back').onclick = () => history.back();
$('#fwd').onclick = () => history.forward();

// The song-list column headers get a background once they stick to the top.
// (A marker just above each header is watched instead of measuring on every scroll.)
const stickWatch = new IntersectionObserver((entries) => {
  for (const e of entries) {
    const hd = e.target.nextElementSibling;
    if (hd) hd.classList.toggle('stuck', !e.isIntersecting && e.boundingClientRect.top < (e.rootBounds ? e.rootBounds.top : 0) + 1);
  }
}, { root: document.getElementById('main'), threshold: 0 });

let keepScroll = false;
let skeletonTimer = null;
function setView(...nodes) {
  clearTimeout(skeletonTimer);
  const v = h('div.view', nodes);
  if (keepScroll) {
    const top = main.scrollTop;
    main.replaceChildren(v);
    main.scrollTop = top;
  } else {
    v.classList.add('enter');
    main.replaceChildren(v);
    main.scrollTop = 0;
  }
  return v;
}
// Placeholders only appear if a page takes a moment; most pages are drawn before they would.
function loadingView(kind = 'grid') {
  clearTimeout(skeletonTimer);
  if (keepScroll) return;
  skeletonTimer = setTimeout(() => {
    const tiles = Array.from({ length: 6 }, () => h('div', h('div.skeleton.sk-tile'), h('div.skeleton.sk-line')));
    const v = h('div.view', h('div.skeleton.sk-h'), kind === 'grid' ? h('div.grid', tiles) : h('div', Array.from({ length: 8 }, () => h('div.skeleton', { style: 'height:44px;margin:10px 0' }))));
    main.replaceChildren(v);
    main.scrollTop = 0;
  }, 180);
}
function errorView(title, err, retry) {
  setView(h('div.empty',
    h('h2', { text: title }),
    h('p', { text: err.message }),
    h('button.pill', { text: 'Try again', onclick: retry })
  ));
}

async function route(opts) {
  const inPlace = !!(opts && opts.keepScroll === true);
  if (!inPlace) closeMenu();
  if (!state.user) return;
  const [name, ...rest] = (location.hash.slice(1) || 'home').split('/');
  const arg = decodeURIComponent(rest.join('/'));
  document.querySelectorAll('[data-nav]').forEach((a) => a.classList.toggle('active', a.dataset.nav === name));
  document.querySelectorAll('.side-list a').forEach((a) => a.classList.toggle('active', a.getAttribute('href') === location.hash));
  const token = ++renderToken;
  const live = () => token === renderToken;
  viewKeys = new Set();
  const views = { home: viewHome, search: viewSearch, liked: viewLiked, ytliked: viewYtLiked, playlist: viewPlaylist, mine: viewMine, album: viewAlbum, artist: viewArtist, show: viewShow, episode: viewEpisode, settings: viewSettings, lyrics: viewLyrics, discography: viewDiscography, ytartist: viewYtArtist, ytalbum: viewYtAlbum, ytplaylist: viewYtPlaylist };
  main.classList.toggle('lyrics-mode', name === 'lyrics');
  $('#lyrics-btn').setAttribute('aria-pressed', String(name === 'lyrics'));
  if (name !== 'lyrics') lyricsUI.detach();
  const fn = views[name] || viewHome;
  if (name !== 'search' && !inPlace) $('#search-input').value = '';
  keepScroll = inPlace;
  try {
    await fn(arg, live);
  } finally {
    keepScroll = false;
  }
}

// ── views ──────────────────────────────────────────────────────────────────────
async function viewHome(_arg, live) {
  loadingView();
  try {
    const home = await cached('home', 10 * 60 * 1000, () => api('home'));
    if (!live()) return;
    const top = h('div.home-top', h('p.greeting', { text: home.greeting || `Hello, ${state.user.name}` }));
    const v = setView(top);
    const picks = [{ type: 'liked', id: 'me', name: 'Liked Songs' }, state.ytLiked.length ? { type: 'ytliked', id: 'me', name: YT_LIKED } : null, ...state.local.slice(0, 3), ...state.playlists].filter(Boolean).slice(0, 8);
    top.append(h('div.quick-grid', picks.map(quickTile)));
    const recent = [...state.local, ...state.playlists].slice(0, 10);
    if (recent.length) v.append(...shelf('Your playlists', recent));
    home.sections.forEach((s) => v.append(...shelf(s.title, s.items)));
    if (!home.sections.length && !recent.length) {
      v.append(h('p.lede', { text: 'Your Spotify home is empty. Search for something to play, or follow a few artists in Spotify to fill this page.' }));
    }
  } catch (e) {
    if (live()) errorView('Your home page didn’t load', e, () => { state.cache.delete('home'); route(); });
  }
}

// Compact tiles at the top of Home; hovering one tints the page with its cover colour.
function quickTile(p) {
  const href = p.type === 'liked' ? '#liked' : p.type === 'ytliked' ? '#ytliked' : hrefOf(p);
  const el = h('a.qtile', {
    href,
    title: p.name,
    onmouseenter: async () => {
      const c = p.image ? await artColor(p.image) : p.type === 'liked' ? [80, 60, 200] : p.type === 'ytliked' ? [190, 30, 40] : null;
      const top = el.closest('.home-top');
      if (c && top) top.style.setProperty('--home', shade(c, 0.3, 0.45).join(' '));
    },
    oncontextmenu: (e) => { if (p.type !== 'liked' && p.type !== 'ytliked') { e.preventDefault(); playlistMenu(p, e.clientX, e.clientY); } },
  },
    coverEl(p),
    h('span.nm', { text: p.name }),
    h('button.quick', { 'aria-label': `Play ${p.name}`, onclick: (e) => { e.preventDefault(); e.stopPropagation(); playCollection(p); } }, icon('play'))
  );
  return el;
}

let searchKind = 'all';
async function viewSearch(q, live) {
  const input = $('#search-input');
  if (input.value !== q) input.value = q;
  if (!q) {
    setView(h('div.empty', h('h2', { text: 'Search Spotify and YouTube Music' }), h('p', { text: 'Find any song, artist, album, playlist or podcast. Songs play ad-free through YouTube Music; podcasts play from their own public feeds. YouTube Music’s own catalog (songs, albums and playlists that aren’t on Spotify) shows up too.' })));
    input.focus();
    return;
  }
  // A pasted Spotify link opens that playlist, album, artist or song's album directly.
  const link = /(?:open\.spotify\.com\/(?:intl-\w+\/)?|spotify:)(playlist|album|artist|show|episode)[/:]([A-Za-z0-9]{22})/.exec(q);
  if (link) {
    location.replace(`#${link[1]}/${link[2]}`);
    return;
  }
  // A pasted YouTube Music (or YouTube) link to a playlist, album or artist opens it.
  const ytl = /(?:music\.)?youtube\.com\/.*[?&]list=((OLAK5uy_)?[\w-]{10,80})|youtube\.com\/browse\/(MPREb_[\w-]+)|youtube\.com\/(?:channel|browse)\/(UC[\w-]{22})/.exec(q);
  if (ytl) {
    location.replace(ytl[2] ? `#ytalbum/${ytl[1]}` : ytl[1] ? `#ytplaylist/${ytl[1]}` : ytl[3] ? `#ytalbum/${ytl[3]}` : `#ytartist/${ytl[4]}`);
    return;
  }
  loadingView('list');
  // YouTube Music is searched at the same time; its results join the page when they arrive.
  const ytP = cached(`yts:${q.toLowerCase()}`, 10 * 60 * 1000, () => api('ytSearch', q)).catch(() => null);
  try {
    let r;
    try {
      r = await cached(`search:${q.toLowerCase()}`, 5 * 60 * 1000, () => api('search', q));
    } catch (e) {
      // Spotify didn't answer: YouTube Music's results alone are still worth showing.
      if (!(await ytP)) throw e;
      r = { tracks: [], artists: [], albums: [], playlists: [] };
    }
    if (!live()) return;
    r.shows = r.shows || [];
    r.episodes = r.episodes || [];
    let ytr = null;
    if (!r.tracks.length && !r.artists.length && !r.albums.length && !r.playlists.length && !r.shows.length && !r.episodes.length) {
      ytr = await ytP;
      if (!live()) return;
      if (!ytr || !(ytr.songs.length || ytr.albums.length || ytr.playlists.length || ytr.artists.length)) {
        setView(h('div.empty', h('h2', { text: `No results for “${q}”` }), h('p', { text: 'Check the spelling, or try fewer words.' })));
        return;
      }
      searchKind = 'youtube';
    }
    const v = setView();
    const norm = (s) => s.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
    const topArtist = r.artists.find((a) => norm(a.name) === norm(q));
    const topShow = r.shows.find((x) => norm(x.name) === norm(q));
    const top = topArtist || topShow || r.tracks[0] || r.albums[0] || r.playlists[0] || r.artists[0] || r.shows[0] || r.episodes[0] || { name: q, image: '', artists: [] };
    const topEl = h(`a.top-result.${top.type || 'track'}`, {
      href: top.type === 'episode' ? (top.show && top.show.id ? `#show/${top.show.id}` : '#search/' + encodeURIComponent(q)) : top.type ? `#${top.type}/${top.id}` : top.album && top.album.id ? `#album/${top.album.id}` : '#search/' + encodeURIComponent(q),
    },
      h('img', { src: top.image || '', alt: '' }),
      h('div', h('div.t', { text: top.name }), h('div.muted', top.type === 'episode' ? ['Episode of ', artistLinks(top.artists)] : top.type ? subtitle(top) : ['Song by ', artistLinks(top.artists)])),
      h('button.big-play.quick', {
        'aria-label': `Play ${top.name}`,
        onclick: (e) => {
          e.preventDefault();
          if (top.type === 'episode') player.playList(r.episodes, r.episodes.indexOf(top), `search:${q}:episodes`, `Search: ${q}`);
          else if (!top.type) player.playList(r.tracks, 0, `search:${q}`, `Search: ${q}`);
          else playCollection(top);
        },
      }, icon('play'))
    );
    // Filter chips like Spotify's: everything, or just songs / playlists / artists / albums.
    const kinds = [['all', 'All'], ['songs', 'Songs', r.tracks], ['playlists', 'Playlists', r.playlists], ['artists', 'Artists', r.artists], ['albums', 'Albums', r.albums], ['podcasts', 'Podcasts', r.shows], ['episodes', 'Episodes', r.episodes]].filter((k) => k[0] === 'all' || k[2].length);
    const episodes = (list) => trackList(list, { source: `search:${q}:episodes`, sourceName: `Search: ${q}`, label: 'Episodes', showAlbum: false, header: false });
    const body = h('div.search-body');
    const chip = ([k, label]) => h('button.chip', { role: 'tab', 'data-kind': k, 'aria-selected': String(k === searchKind), onclick: () => { searchKind = k; draw(); } }, k === 'youtube' ? srcMark('ytm') : null, label);
    const chips = h('div.chips.search-chips', { role: 'tablist', 'aria-label': 'Show' }, kinds.map(chip));
    const songs = () => trackList(r.tracks, { source: `search:${q}`, sourceName: `Search: ${q}` });
    // YouTube Music's results: songs Spotify doesn't have, its albums, artists and playlists.
    const norm2 = (t) => norm(`${t.name}|${(t.artists[0] || {}).name || ''}`);
    const ytOnly = () => {
      const have = new Set(r.tracks.map(norm2));
      return ytr.songs.filter((t) => !have.has(norm2(t)));
    };
    const ytSection = () => {
      if (!ytr) return [];
      const extra = ytOnly();
      const out = [];
      if (extra.length) out.push(h('div.shelf-head', h('h2', srcMark('ytm'), 'More songs on YouTube Music'), h('button.show-all', { text: 'Show all', onclick: () => { searchKind = 'youtube'; draw(); } })), trackList(extra.slice(0, 5), { source: `yts:${q}`, sourceName: `YouTube Music: ${q}`, showAlbum: false, header: false }));
      out.push(...shelf('Playlists on YouTube Music', ytr.playlists), ...shelf('Albums on YouTube Music', ytr.albums));
      return out;
    };
    const ytAll = () => [
      ytr.songs.length ? [h('h2', { text: 'Songs' }), trackList(ytr.songs, { source: `yts:${q}`, sourceName: `YouTube Music: ${q}` })] : null,
      ...shelf('Playlists', ytr.playlists),
      ...shelf('Albums and singles', ytr.albums),
      ...shelf('Artists', ytr.artists),
      ytr.videos.length ? [h('h2', { text: 'Videos' }), trackList(ytr.videos, { source: `ytv:${q}`, sourceName: `YouTube Music: ${q}`, showAlbum: false, header: false })] : null,
    ];
    const draw = () => {
      if (!kinds.some((k) => k[0] === searchKind)) searchKind = 'all';
      chips.querySelectorAll('.chip').forEach((c) => c.setAttribute('aria-selected', String(c.dataset.kind === searchKind)));
      if (searchKind === 'youtube') return body.replaceChildren(...(ytr ? ytAll().flat().filter(Boolean) : [h('div.skeleton', { style: 'height:44px;margin:10px 0' })]));
      if (searchKind === 'songs') return body.replaceChildren(songs());
      if (searchKind === 'episodes') return body.replaceChildren(episodes(r.episodes));
      if (searchKind !== 'all') {
        const list = { playlists: r.playlists, artists: r.artists, albums: r.albums, podcasts: r.shows }[searchKind];
        return body.replaceChildren(h('div.grid', list.map(tile)));
      }
      body.replaceChildren(
        h('div.search-top',
          h('div', h('h2', { text: 'Top result' }), topEl),
          r.tracks.length ? h('div', h('h2', { text: 'Songs' }), trackList(r.tracks.slice(0, 4), { source: `search:${q}`, sourceName: `Search: ${q}`, showAlbum: false, header: false })) : h('div')
        ),
        ...shelf('Playlists', r.playlists),
        ...shelf('Artists', r.artists),
        ...shelf('Albums', r.albums),
        ...shelf('Podcasts', r.shows),
        ...(r.episodes.length ? [h('h2', { text: 'Episodes' }), episodes(r.episodes.slice(0, 5))] : [])
      );
      if (r.tracks.length > 4) {
        const more = trackList(r.tracks.slice(4), { source: `search:${q}:more`, sourceName: `Search: ${q}` });
        body.append(h('h2', { text: 'More songs' }), more);
      }
      body.append(...ytSection());
    };
    if (!r.tracks.length && !r.artists.length && !r.albums.length && !r.playlists.length && !r.shows.length && !r.episodes.length) {
      v.append(h('p.lede', { text: `Nothing on Spotify for “${q}”. Here’s what YouTube Music has.` }));
      topEl.hidden = true;
    }
    v.append(chips, body);
    if (!kinds.some((k) => k[0] === 'youtube') && ytr) {
      kinds.push(['youtube', 'YouTube Music']);
      chips.append(chip(kinds[kinds.length - 1]));
    }
    draw();
    if (!ytr) {
      ytP.then((y) => {
        if (!y || !live() || !body.isConnected) return;
        ytr = y;
        if (!(y.songs.length || y.albums.length || y.playlists.length || y.artists.length || y.videos.length)) return;
        kinds.push(['youtube', 'YouTube Music']);
        chips.append(chip(kinds[kinds.length - 1]));
        if (searchKind === 'all') body.append(...ytSection()); // added below, nothing above moves
        else if (searchKind === 'youtube') draw();
      });
    }
  } catch (e) {
    if (live()) errorView('Search didn’t work', e, route);
  }
}

// Load every page of a list, calling onPage as pages arrive.
async function loadPlaylistAll(id, onPage, max = 10000) {
  const first = await api('playlist', id, 0);
  const tracks = first.tracks.slice();
  onPage && onPage(first, tracks, 0);
  for (let off = 100; off < Math.min(first.total, max); off += 100) {
    const p = await api('playlist', id, off);
    const start = tracks.length;
    tracks.push(...p.tracks);
    onPage && onPage(first, tracks, start);
    if (!p.tracks.length) break;
  }
  return { info: first.info, tracks };
}
async function loadLikedAll(onPage) {
  const first = await api('liked', 0);
  const tracks = first.tracks.slice();
  first.tracks.forEach((t) => state.liked.add(t.uri));
  onPage && onPage(first, tracks, 0);
  for (let off = 50; off < Math.min(first.total, 10000); off += 50) {
    const p = await api('liked', off);
    const start = tracks.length;
    tracks.push(...p.tracks);
    p.tracks.forEach((t) => state.liked.add(t.uri));
    onPage && onPage(first, tracks, start);
    if (!p.tracks.length) break;
  }
  return { total: first.total, tracks };
}

function collectionHeader({ kind, title, titleEl, image, cover, desc, descEl, meta, round = false }) {
  const hero = h(`div.hero${round ? '.artist' : ''}`,
    cover || (image ? h('img.cover', { src: image, alt: '' }) : h('div.cover', { html: ICONS.note })),
    h('div', { style: 'min-width:0' },
      h('div.kind', { text: kind }),
      titleEl || h('h1', { text: title }),
      descEl || (desc ? h('p.desc', { text: desc }) : null),
      meta ? h('div.meta', meta.filter(Boolean)) : null)
  );
  if (image) tintHero(hero, image);
  return hero;
}
function actionsBar(onPlay, onShuffle, extra) {
  return h('div.actions-wrap', h('div.actions',
    h('button.big-play', { 'aria-label': 'Play', title: 'Play', onclick: onPlay }, icon('play')),
    onShuffle ? h('button.act-icon', { 'aria-label': 'Shuffle play', title: 'Shuffle play', onclick: onShuffle }, icon('shuffle')) : null,
    extra
  ));
}

// One playlist page. Playlists you made (in Spotify or on this PC) can be edited here:
// rename, delete, remove or drag songs, and search for songs to add at the bottom.
function playlistPage({ p, list, source, mine, load, dlKey }) {
  const ref = { list };
  let tracksEl = null;
  const countText = () => {
    const n = ref.list.length || (p.local ? 0 : p.total || 0);
    const eps = ref.list.filter(isEpisode).length;
    return plural(n, eps && eps === ref.list.length ? 'episode' : eps ? 'item' : 'song');
  };
  const countEl = h('span', { text: countText() });
  const edit = mine ? editableHelpers(p, ref, () => swap()) : null;
  const opts = { source, sourceName: p.name, showAdded: true, edit };
  const empty = () => h('div.empty', { style: 'padding:24px 0' }, h('h2', { text: mine ? 'Let’s add some songs' : 'This playlist is empty' }), h('p', { text: mine ? p.local ? 'Search below, paste a YouTube link with the link button, or drag a song onto this playlist in Your Library.' : 'Search below, right-click any song and choose Add to playlist, or drag a song onto this playlist in Your Library.' : 'Nothing here yet.' }));
  const swap = () => {
    const n = ref.list.length ? trackList(ref.list, opts) : empty();
    tracksEl.replaceWith(n);
    tracksEl = n;
    countEl.textContent = countText();
  };
  tracksEl = ref.list.length ? trackList(ref.list, opts) : empty();
  const title = h('h1', { text: p.name });
  const descEl = h('p.desc', { text: p.description || '' });
  if (!p.description) descEl.hidden = true;
  if (mine) {
    title.classList.add('editable');
    title.title = 'Edit details';
    title.onclick = async () => {
      if (await editDetailsDialog(p)) {
        title.textContent = p.name;
        descEl.textContent = p.description || '';
        descEl.hidden = !p.description;
        opts.sourceName = p.name;
      }
    };
  }
  const where = p.local ? h('span.badge', icon('pc'), 'On this PC') : mine ? h('span.badge', icon('cloud'), 'In your Spotify') : null;
  const hero = collectionHeader({
    kind: 'Playlist',
    titleEl: title,
    image: p.local ? (p.covers && p.covers[0]) : p.image,
    cover: p.local ? coverEl(p, 'cover') : null,
    descEl,
    meta: [where, h('b', { text: p.local ? state.user.name || 'You' : p.owner || '' }), countEl],
  });
  const play = () => ref.list.length && player.playList(ref.list, 0, source, p.name);
  const shuffle = () => { if (!ref.list.length) return; player.setShuffle(true); player.playList(ref.list, Math.floor(Math.random() * ref.list.length), source, p.name); };
  const more = h('button.act-icon', { 'aria-label': 'More options', title: 'More options', onclick: (e) => playlistMenu(p, e.clientX, e.clientY) }, icon('more'));
  const dl = dlKey ? downloadButton(dlKey, () => ({ name: p.name, image: p.local ? (p.covers && p.covers[0]) || p.image : p.image, owner: p.owner }), async () => {
    if (p.local || ref.list.filter((t) => !t.extra).length >= (p.total || 0)) return ref.list;
    return withExtras(p.id, (await loadPlaylistAll(p.id, null)).tracks);
  }) : null;
  // After adding from the search box: fetch the list again and swap just the songs.
  const reload = async () => {
    if (!load) return;
    try {
      ref.list = await load();
      swap();
      if (dlKey) syncDownload(dlKey, p, ref.list);
      if (p.local) {
        // Refresh the cover (first song, or a 2×2 mosaic once there are four different covers).
        p.covers = [...new Set(ref.list.map((t) => t.image).filter(Boolean))].slice(0, 4);
        p.image = p.covers[0] || null;
        const old = v.querySelector('.hero .cover');
        if (old) old.replaceWith(coverEl(p, 'cover'));
      }
    } catch {}
  };
  // Like Spotify's own files: any YouTube or YouTube Music video can go in a playlist on
  // this device by pasting its link.
  const addLink = p.local || mine ? h('button.act-icon.add-link', { 'aria-label': 'Add a song from a YouTube link', title: 'Add a song from a YouTube link', onclick: () => addYouTubeLink(p, reload) }, icon('link')) : null;
  const v = setView(hero, actionsBar(play, shuffle, [dl, addLink, more]), tracksEl, mine ? finder(p, reload) : null);
  return { v, ref, append: (from) => { if (tracksEl.appendFrom) tracksEl.appendFrom(from); countEl.textContent = countText(); } };
}

const PLAYLIST_TTL = 5 * 60 * 1000;
const loadPlaylistCached = (id) => cached(`playlist:${id}`, PLAYLIST_TTL, () => loadPlaylistAll(id, null));

async function viewPlaylist(id, live) {
  const key = `playlist:${id}`;
  const source = key;
  const draw = (data) => {
    const known = state.playlists.find((x) => x.id === id);
    const p = known ? Object.assign(known, { ...data.info, image: data.info.image || known.image }) : { ...data.info };
    return playlistPage({ p, list: data.tracks, source, mine: isMineSpotify(p), dlKey: key, load: async () => withExtras(id, (await loadPlaylistCached(id)).tracks) });
  };
  const hit = state.cache.get(key);
  if (hit) {
    // Saved copy: drawn now, brought up to date behind (redrawn only if something changed).
    const data = await loadPlaylistCached(id);
    if (live()) draw({ info: data.info, tracks: withExtras(id, data.tracks) });
    syncDownload(key, data.info, withExtras(id, data.tracks));
    return;
  }
  loadingView('list');
  let page = null;
  let shown = 0;
  viewKeys.add(key);
  try {
    const data = await loadPlaylistAll(id, (first, tracks) => {
      if (!live()) return;
      if (!page) {
        page = draw({ info: first.info, tracks });
        shown = tracks.length;
      } else if (tracks.length > shown) {
        page.ref.list = tracks;
        page.append(shown);
        shown = tracks.length;
      }
    });
    state.cache.set(key, { at: Date.now(), data });
    saveSnapshotSoon();
    syncDownload(key, data.info, withExtras(id, data.tracks));
    // YouTube songs you added on this device go at the end, once Spotify's songs are all in.
    if ((state.extras[id] || []).length && live()) route({ keepScroll: true });
  } catch (e) {
    if (page) {
      if (live()) toast(`Some songs didn't load: ${e.message}`, true);
    } else if (!(await offlineCopy(key, live, (tracks, info) => draw({ info, tracks: withExtras(id, tracks) })))) {
      if (live()) errorView('This playlist didn’t load', e, route);
    }
  }
}

async function viewMine(id, live) {
  loadingView('list');
  try {
    const r = await api('localPlaylist', id);
    if (!live()) return;
    const p = state.local.find((x) => x.id === id) || r.info;
    Object.assign(p, r.info);
    playlistPage({ p, list: r.tracks, source: `mine:${id}`, mine: true, dlKey: `mine:${id}`, load: async () => (await api('localPlaylist', id)).tracks });
    syncDownload(`mine:${id}`, p, r.tracks);
  } catch (e) {
    if (live()) errorView('This playlist didn’t load', e, route);
  }
}

const LIKED_TTL = 2 * 60 * 1000;
async function viewLiked(_arg, live) {
  const key = 'liked';
  const source = 'liked:me';
  let tracksEl = null;
  let shown = 0;
  let current = [];
  const draw = (total, tracks) => {
    current = tracks;
    tracksEl = trackList(tracks, { source, sourceName: 'Liked songs' });
    const hero = collectionHeader({ kind: 'Playlist', title: 'Liked songs', meta: [h('b', { text: state.user.name }), h('span', { text: plural(total + state.ytLiked.length, 'song') })] });
    hero.style.setProperty('--hero', '80 56 160');
    hero.querySelector('.cover').replaceWith(coverEl({ type: 'liked' }, 'cover'));
    const dl = downloadButton('liked:me', () => ({ name: 'Liked Songs' }), async () => (current.filter((t) => !isYt(t)).length >= total ? current : withYtLikes((await loadLikedAll(null)).tracks)));
    const addLink = h('button.act-icon.add-link', { 'aria-label': 'Like a song from a YouTube link', title: 'Like a song from a YouTube link', onclick: likeYouTubeLink }, icon('link'));
    const bar = actionsBar(() => player.playList(current, 0, source, 'Liked songs'), () => { player.setShuffle(true); player.playList(current, Math.floor(Math.random() * current.length), source, 'Liked songs'); }, [dl, addLink]);
    bar.style.setProperty('--hero', '80 56 160');
    setView(hero, bar,
      total || state.ytLiked.length ? tracksEl : h('div.empty', h('h2', { text: 'Songs you like will appear here' }), h('p', { text: 'Save songs with the heart button, here or in Spotify.' }))
    );
    shown = tracks.length;
  };
  if (state.cache.get(key)) {
    const data = await cached(key, LIKED_TTL, () => loadLikedAll(null));
    if (live()) draw(data.total, withYtLikes(data.tracks));
    syncDownload('liked:me', { name: 'Liked Songs' }, withYtLikes(data.tracks));
    return;
  }
  loadingView('list');
  viewKeys.add(key);
  try {
    const data = await loadLikedAll((first, tracks) => {
      if (!live()) return;
      if (!tracksEl) draw(first.total, tracks);
      else if (tracks.length > shown) {
        tracksEl.appendFrom(shown);
        shown = tracks.length;
      }
    });
    state.cache.set(key, { at: Date.now(), data });
    saveSnapshotSoon();
    syncDownload('liked:me', { name: 'Liked Songs' }, withYtLikes(data.tracks));
    // Liked YouTube songs are mixed in by date once Spotify's likes are all in.
    if (state.ytLiked.length && live()) route({ keepScroll: true });
  } catch (e) {
    if (!tracksEl && !(await offlineCopy('liked:me', live, (tracks) => { const t = withYtLikes(tracks); draw(t.length - state.ytLiked.length, t); })) && live()) errorView('Liked songs didn’t load', e, route);
  }
}

// Liked YouTube Music songs: kept on this device, so the page never waits on the internet.
function viewYtLiked() {
  const source = 'ytliked:me';
  const tracks = state.ytLiked.slice();
  const totalMs = tracks.reduce((a, t) => a + (t.durationMs || 0), 0);
  const hero = collectionHeader({
    kind: 'Playlist',
    title: YT_LIKED,
    cover: coverEl({ type: 'ytliked' }, 'cover'),
    meta: [srcMark('ytm'), h('b', { text: state.user ? state.user.name : 'You' }), h('span', { text: plural(tracks.length, 'song') }), totalMs ? h('span', { text: fmtTime(totalMs / 1000) }) : null],
  });
  hero.style.setProperty('--hero', '150 22 34');
  const dl = downloadButton('ytliked:me', () => ({ name: YT_LIKED }), async () => state.ytLiked.slice());
  const play = (i) => player.playList(tracks, i, source, YT_LIKED);
  const bar = actionsBar(() => play(0), () => { player.setShuffle(true); play(Math.floor(Math.random() * tracks.length)); }, dl);
  bar.style.setProperty('--hero', '150 22 34');
  setView(hero, bar,
    tracks.length
      ? trackList(tracks, { source, sourceName: YT_LIKED, showAdded: true })
      : h('div.empty', h('h2', { text: 'YouTube Music songs you like will appear here' }), h('p', { text: 'Tap the heart on any YouTube Music song. They’re kept on this device; no Google account is used.' }))
  );
}

async function viewAlbum(id, live) {
  loadingView('list');
  try {
    const a = await cached(`album:${id}`, 30 * 60 * 1000, () => api('album', id));
    if (!live()) return;
    const i = a.info;
    const source = `album:${id}`;
    const kind = i.albumType === 'single' ? 'Single' : i.albumType === 'ep' ? 'EP' : i.albumType === 'compilation' ? 'Compilation' : 'Album';
    const totalMs = a.tracks.reduce((s, t) => s + (t.durationMs || 0), 0);
    setView(
      collectionHeader({
        kind,
        title: i.name,
        image: i.image,
        meta: [h('b', artistLinks(i.artists)), i.year ? h('span', { text: String(i.year) }) : null, h('span', { text: plural(a.tracks.length, 'song') }), totalMs ? h('span', { text: fmtTime(totalMs / 1000) }) : null],
      }),
      actionsBar(() => player.playList(a.tracks, 0, source, i.name), () => { player.setShuffle(true); player.playList(a.tracks, Math.floor(Math.random() * a.tracks.length), source, i.name); },
        downloadButton(`album:${id}`, () => ({ name: i.name, image: i.image, owner: (i.artists || []).map((x) => x.name).join(', ') }), async () => a.tracks)),
      trackList(a.tracks, { source, sourceName: i.name, showAlbum: false, showArt: false })
    );
    syncDownload(`album:${id}`, i, a.tracks);
  } catch (e) {
    if (live()) errorView('This album didn’t load', e, route);
  }
}

async function viewArtist(id, live) {
  loadingView('list');
  try {
    const a = await cached(`artist:${id}`, 30 * 60 * 1000, () => api('artist', id));
    if (!live()) return;
    const i = a.info;
    const source = `artist:${id}`;
    const ytBtn = h('a.pill.yt-link', { href: '#', hidden: true }, srcMark('ytm'), 'More on YouTube Music');
    const v = setView(
      collectionHeader({ kind: 'Artist', title: i.name, image: i.imageLarge || i.image, round: true, meta: i.monthlyListeners ? [h('span', { text: `${fmtCount(i.monthlyListeners)} monthly listeners` })] : null }),
      actionsBar(() => player.playList(a.topTracks, 0, source, i.name), null, [h('a.pill', { href: `#discography/${id}` }, 'Discography'), ytBtn]),
      a.topTracks.length ? [h('h2', { text: 'Popular' }), trackList(a.topTracks, { source, sourceName: i.name, header: false })] : null,
      a.releases.length ? h('div.shelf-head', h('h2', { text: 'Discography' }), h('a.show-all', { href: `#discography/${id}`, text: 'Show all' })) : null,
      a.releases.length ? h('div.shelf', a.releases.map(tile)) : null,
      ...shelf('Fans also like', a.related)
    );
    // The same artist on YouTube Music (often with songs Spotify doesn't have).
    cached(`ytfind:${i.name.toLowerCase()}`, 24 * 3600 * 1000, () => api('ytFindArtist', i.name), { forView: false })
      .then((yt) => {
        if (!yt || !live() || !v.isConnected) return;
        ytBtn.href = `#ytartist/${yt.id}`;
        ytBtn.hidden = false;
      })
      .catch(() => {});
  } catch (e) {
    if (live()) errorView('This artist didn’t load', e, route);
  }
}

// ── Discography: every album, single, EP and compilation, each with its songs ─────────
const DISCO_KINDS = [['all', 'All'], ['album', 'Albums'], ['single', 'Singles and EPs'], ['compilation', 'Compilations']];
let discoKind = 'all';
async function viewDiscography(id, live) {
  loadingView('list');
  try {
    const [releases, artist] = await Promise.all([
      cached(`discography:${id}`, 60 * 60 * 1000, () => api('discography', id)),
      cached(`artist:${id}`, 30 * 60 * 1000, () => api('artist', id)).catch(() => null),
    ]);
    if (!live()) return;
    const name = (artist && artist.info.name) || 'Artist';
    const source = `discography:${id}`;
    const kindOf = (r) => (r.albumType === 'ep' ? 'single' : r.albumType || 'album');
    const list = () => releases.filter((r) => discoKind === 'all' || kindOf(r) === discoKind);
    const body = h('div.disco');
    const chips = h('div.chips.search-chips', { role: 'tablist', 'aria-label': 'Show' },
      DISCO_KINDS.filter(([k]) => k === 'all' || releases.some((r) => kindOf(r) === k)).map(([k, label]) =>
        h('button.chip', { role: 'tab', 'data-kind': k, 'aria-selected': String(k === discoKind), onclick: () => { discoKind = k; draw(); } }, label)));
    // Each release's songs load as it comes into view.
    const watch = new IntersectionObserver((entries) => {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        watch.unobserve(e.target);
        e.target.__load();
      }
    }, { root: main, rootMargin: '900px 0px' });
    const releaseBlock = (r) => {
      const songs = h('div.disco-songs', h('div.skeleton', { style: 'height:44px;margin:8px 0' }));
      const kind = r.albumType === 'single' ? 'Single' : r.albumType === 'ep' ? 'EP' : r.albumType === 'compilation' ? 'Compilation' : 'Album';
      const block = h('section.disco-release',
        h('div.disco-head',
          h('a', { href: `#album/${r.id}` }, r.image ? h('img', { src: r.image, alt: '', loading: 'lazy', decoding: 'async' }) : h('div.cov.note-cov', { html: ICONS.note })),
          h('div', { style: 'min-width:0' },
            h('a.disco-title', { href: `#album/${r.id}`, text: r.name }),
            h('div.disco-meta', { text: [kind, r.year, r.total ? plural(r.total, 'song') : ''].filter(Boolean).join(' • ') }),
            h('div.disco-actions', h('button.big-play.small', { 'aria-label': `Play ${r.name}`, onclick: () => playCollection(r) }, icon('play'))))),
        songs);
      block.__load = async () => {
        try {
          const al = await cached(`album:${r.id}`, 60 * 60 * 1000, () => api('album', r.id), { forView: false });
          songs.replaceChildren(trackList(al.tracks, { source: `album:${r.id}`, sourceName: r.name, showAlbum: false, showArt: false, header: false }));
        } catch (e) {
          songs.replaceChildren(h('p.lede', { text: `These songs didn’t load: ${e.message}` }));
        }
      };
      watch.observe(block);
      return block;
    };
    const draw = () => {
      chips.querySelectorAll('.chip').forEach((c) => c.setAttribute('aria-selected', String(c.dataset.kind === discoKind)));
      body.replaceChildren(...list().map(releaseBlock));
    };
    // Play everything shown, newest first: starts at once, the rest joins the queue as it loads.
    const playAll = async (shuffle = false) => {
      const rel = list();
      if (!rel.length) return;
      toast(`Playing all of ${name}’s ${discoKind === 'all' ? 'releases' : DISCO_KINDS.find((k) => k[0] === discoKind)[1].toLowerCase()}`);
      let started = false;
      for (const r of rel) {
        const al = await cached(`album:${r.id}`, 60 * 60 * 1000, () => api('album', r.id), { forView: false }).catch(() => null);
        if (!al || !al.tracks.length) continue;
        if (!started) {
          if (shuffle) player.setShuffle(true);
          player.playList(al.tracks, 0, source, `${name}: Discography`);
          started = true;
        } else if (!player.extend(al.tracks, source)) return; // something else is playing now
      }
    };
    setView(
      collectionHeader({ kind: 'Discography', title: name, image: artist && (artist.info.imageLarge || artist.info.image), round: true, meta: [h('span', { text: plural(releases.length, 'release') }), h('a.link', { href: `#artist/${id}`, text: 'Back to artist' })] }),
      actionsBar(() => playAll(false), () => playAll(true)),
      chips,
      body
    );
    draw();
  } catch (e) {
    if (live()) errorView('The discography didn’t load', e, route);
  }
}

// ── YouTube Music pages ────────────────────────────────────────────────────────
function savedYt(type, id) {
  return state.ytlib.some((x) => x.type === type && x.id === id);
}
// "Save to Your Library" for a YouTube Music playlist or album.
function ytSaveButton(item) {
  const b = h('button.act-icon.save-btn', { onclick: async () => {
    try {
      if (savedYt(item.type, item.id)) {
        state.ytlib = await api('ytLibraryRemove', item.type, item.id);
        toast('Removed from Your Library');
      } else {
        state.ytlib = await api('ytLibrarySave', { type: item.type, id: item.id, name: item.name, image: item.image, owner: item.owner || ((item.artists || [])[0] || {}).name || '' });
        toast('Saved to Your Library');
      }
      paint();
      renderLibrary();
      saveSnapshotSoon();
    } catch (e) {
      toast(e.message, true);
    }
  } });
  const paint = () => {
    const on = savedYt(item.type, item.id);
    b.setAttribute('aria-pressed', String(on));
    b.title = on ? 'Remove from Your Library' : 'Save to Your Library';
    b.setAttribute('aria-label', b.title);
    b.innerHTML = on ? ICONS.check : ICONS.plusCircle;
  };
  paint();
  return b;
}

async function viewYtArtist(id, live) {
  loadingView('list');
  try {
    const a = await cached(`ytartist:${id}`, 30 * 60 * 1000, () => api('ytArtist', id));
    if (!live()) return;
    const i = a.info;
    const source = `ytartist:${id}`;
    // Every song the artist has on YouTube Music: their "Songs" list.
    const allSongs = async () => (a.allSongsId ? (await cached(`ytplaylist:${a.allSongsId}`, 30 * 60 * 1000, () => api('ytPlaylist', a.allSongsId), { forView: false })).tracks : a.topSongs);
    const playAll = async (shuffle) => {
      const t = await allSongs().catch(() => a.topSongs);
      if (!t.length) return toast('No songs to play', true);
      if (shuffle) player.setShuffle(true);
      player.playList(t, shuffle ? Math.floor(Math.random() * t.length) : 0, source, i.name);
    };
    setView(
      collectionHeader({ kind: 'Artist on YouTube Music', title: i.name, image: i.image, round: true, desc: i.description ? i.description.slice(0, 240) + (i.description.length > 240 ? '…' : '') : '', meta: [srcMark('ytm'), i.stats ? h('span', { text: `${i.stats} subscribers` }) : null] }),
      actionsBar(() => playAll(false), () => playAll(true), a.allSongsId ? h('a.pill', { href: `#ytplaylist/${a.allSongsId}` }, 'All songs') : null),
      a.topSongs.length ? [h('div.shelf-head', h('h2', { text: 'Songs' }), a.allSongsId ? h('a.show-all', { href: `#ytplaylist/${a.allSongsId}`, text: 'Show all' }) : null), trackList(a.topSongs, { source, sourceName: i.name, header: false })] : null,
      ...shelf('Albums', a.albums),
      ...shelf('Singles and EPs', a.singles),
      a.videos.length ? [h('h2', { text: 'Videos' }), trackList(a.videos, { source: `${source}:videos`, sourceName: i.name, header: false, showAlbum: false })] : null,
      ...shelf('Playlists', a.playlists),
      ...shelf('Fans also like', a.related)
    );
  } catch (e) {
    if (live()) errorView('This artist didn’t load', e, route);
  }
}

function ytCollectionPage({ key, data, kind, item }) {
  const i = data.info;
  const totalMs = data.tracks.reduce((s, t) => s + (t.durationMs || 0), 0);
  const who = kind === 'ytalbum' ? (i.artists || []) : [];
  setView(
    collectionHeader({
      kind: kind === 'ytalbum' ? (i.albumType === 'single' ? 'Single' : i.albumType === 'ep' ? 'EP' : 'Album') : 'Playlist',
      title: i.name,
      image: i.image,
      desc: i.description ? i.description.slice(0, 280) : '',
      meta: [srcMark('ytm'), who.length ? h('b', artistLinks(who.map((x) => ({ ...x, type: 'ytartist' })))) : i.owner ? h('b', { text: i.owner }) : null, i.year ? h('span', { text: String(i.year) }) : null, h('span', { text: plural(data.tracks.length, 'song') }), totalMs ? h('span', { text: fmtTime(totalMs / 1000) }) : null],
    }),
    actionsBar(() => player.playList(data.tracks, 0, key, i.name), () => { player.setShuffle(true); player.playList(data.tracks, Math.floor(Math.random() * data.tracks.length), key, i.name); },
      [ytSaveButton(item), downloadButton(key, () => ({ name: i.name, image: i.image, owner: i.owner || (who[0] || {}).name || '' }), async () => data.tracks)]),
    data.tracks.length ? trackList(data.tracks, { source: key, sourceName: i.name, showAlbum: kind !== 'ytalbum', showArt: kind !== 'ytalbum' }) : h('div.empty', h('h2', { text: 'Nothing here yet' }))
  );
  syncDownload(key, i, data.tracks);
}

async function viewYtAlbum(id, live) {
  loadingView('list');
  const key = `ytalbum:${id}`;
  try {
    const data = await cached(key, 60 * 60 * 1000, () => api('ytAlbum', id));
    if (!live()) return;
    ytCollectionPage({ key, data, kind: 'ytalbum', item: { type: 'ytalbum', id, name: data.info.name, image: data.info.image, artists: data.info.artists } });
  } catch (e) {
    if (!(await offlineCopy(key, live, (tracks, info) => ytCollectionPage({ key, data: { info, tracks }, kind: 'ytalbum', item: { type: 'ytalbum', id, name: info.name, image: info.image } }))) && live()) errorView('This album didn’t load', e, route);
  }
}

async function viewYtPlaylist(id, live) {
  loadingView('list');
  const key = `ytplaylist:${id}`;
  try {
    const data = await cached(key, 15 * 60 * 1000, () => api('ytPlaylist', id));
    if (!live()) return;
    ytCollectionPage({ key, data, kind: 'ytplaylist', item: { type: 'ytplaylist', id, name: data.info.name, image: data.info.image, owner: data.info.owner } });
  } catch (e) {
    if (!(await offlineCopy(key, live, (tracks, info) => ytCollectionPage({ key, data: { info, tracks }, kind: 'ytplaylist', item: { type: 'ytplaylist', id, name: info.name, image: info.image } }))) && live()) errorView('This playlist didn’t load', e, route);
  }
}

// A podcast and its episodes, newest first. Episodes play from the show's own public feed.
async function viewShow(id, live) {
  loadingView('list');
  try {
    const sh = await cached(`show:${id}`, 15 * 60 * 1000, () => api('show', id));
    if (!live()) return;
    const i = sh.info;
    const list = sh.episodes.slice();
    const source = `show:${id}`;
    const opts = { source, sourceName: i.name, showAlbum: false, showAdded: true, addedLabel: 'Released', label: 'Episodes' };
    const tracksEl = trackList(list, opts);
    let loading = false;
    const more = h('button.pill', {
      text: 'Show more episodes',
      onclick: async () => {
        if (loading) return;
        loading = true;
        more.disabled = true;
        try {
          const page = await api('show', id, list.length);
          const from = list.length;
          list.push(...page.episodes);
          tracksEl.appendFrom(from);
          if (!page.episodes.length || list.length >= (i.total || 0)) more.remove();
        } catch (e) {
          toast(`More episodes didn’t load: ${e.message}`, true);
        } finally {
          loading = false;
          more.disabled = false;
        }
      },
    });
    setView(
      collectionHeader({
        kind: 'Podcast',
        title: i.name,
        image: i.imageLarge || i.image,
        desc: i.description ? i.description.slice(0, 280) + (i.description.length > 280 ? '…' : '') : '',
        meta: [i.publisher ? h('b', { text: i.publisher }) : null, i.total ? h('span', { text: plural(i.total, 'episode') }) : null],
      }),
      actionsBar(() => player.playList(list, 0, source, i.name), null),
      h('p.lede.podcast-note', { text: 'Episodes play from the podcast’s own public feed, not from Spotify. Spotify isn’t told what you listen to.' }),
      tracksEl,
      list.length < (i.total || 0) ? h('div', { style: 'margin:16px 0' }, more) : null
    );
  } catch (e) {
    if (live()) errorView('This podcast didn’t load', e, route);
  }
}

// A link to one episode: open its podcast.
async function viewEpisode(id, live) {
  loadingView('list');
  try {
    const ep = await api('episode', id);
    if (!live()) return;
    if (ep.show && ep.show.id) location.replace(`#show/${ep.show.id}`);
    else errorView('This episode didn’t load', new Error('Spotify didn’t say which podcast it belongs to.'), route);
  } catch (e) {
    if (live()) errorView('This episode didn’t load', e, route);
  }
}

// "YouTube bot checks": when YouTube flags an internet connection, it blocks everyone on it
// who isn't signed in (even a normal browser). Signing in with a spare account gets past it.
function botSection() {
  const sec = h('section');
  let acted = false; // once you've clicked something, a late status answer mustn't repaint over it
  const paint = (has) => {
    sec.replaceChildren(
      h('h2', { text: 'YouTube bot checks' }),
      h('p', { text: 'Sometimes YouTube flags an internet connection and says “Sign in to confirm you’re not a bot” to everyone on it who isn’t signed in, even in a normal browser. FreeTune tries other ways in by itself, and the flag usually lifts within a few hours. Switching networks (like a phone hotspot) also gets around it.' }),
      has
        ? h('p', { text: 'Using a cookies file from a spare Google account. YouTube can link the songs you play here to that account (not to your main one).' })
        : h('p', { text: 'If it keeps happening, you can give FreeTune a cookies.txt from a spare Google account (never your main one: YouTube can link what you play to it). In Chrome, install the “Get cookies.txt LOCALLY” extension and allow it in Incognito. In an Incognito window, sign in to the spare account on youtube.com, export cookies.txt with the extension, then close the Incognito window and choose the file here.' }),
      h('div.btns', has
        ? h('button.pill', { text: 'Stop using the cookies file', onclick: async () => { acted = true; await api('clearCookies'); paint(false); toast('Cookies file removed. FreeTune is back to not using any account.'); } })
        : [h('button.pill', { text: 'Use a cookies.txt file from a spare account…', onclick: async () => {
            acted = true;
            try {
              if (await api('chooseCookies')) { paint(true); toast('Cookies file added. Try the song again.'); }
            } catch (e) { toast(e.message, true); }
          } })]));
  };
  paint(false);
  api('cookiesStatus').then((has) => { if (!acted) paint(has); }).catch(() => {});
  return sec;
}

function downloadsSection() {
  const line = h('p.downloads-status', { text: downloadsLine() });
  const size = h('p', { text: '' });
  api('downloadsUsage').then((b) => { size.textContent = b ? `Using ${b >= 1e9 ? (b / 1e9).toFixed(1) + ' GB' : Math.max(1, Math.round(b / 1e6)) + ' MB'} on this device.` : ''; }).catch(() => {});
  return h('section',
    h('h2', { text: 'Downloads' }),
    line,
    size,
    h('div.btns',
      ft.platform !== 'android' ? h('button.pill', { text: 'Open downloads folder', onclick: () => api('downloadsOpenFolder') }) : null,
      h('button.pill.danger', {
        text: 'Remove all downloads',
        onclick: async () => {
          if (!Object.keys(state.dl.collections).length) return toast('Nothing is downloaded');
          if (!(await confirmDialog({ title: 'Remove all downloads?', body: 'Everything you downloaded is deleted from this device. You can download it again any time.', confirm: 'Remove all' }))) return;
          applyDownloads(await api('downloadRemoveAll'));
          size.textContent = '';
          toast('All downloads removed');
        },
      })
    )
  );
}

async function viewSettings() {
  const version = await api('version').catch(() => '');
  const updateBtn = h('button.pill', {
    text: 'Update playback engine',
    onclick: async () => {
      updateBtn.disabled = true;
      updateBtn.textContent = 'Checking…';
      try {
        const out = await api('engineUpdate');
        toast(/up to date|up-to-date/i.test(out || '') ? 'The playback engine is already up to date' : 'Playback engine updated');
      } catch (e) {
        toast(e.message, true);
      }
      updateBtn.disabled = false;
      updateBtn.textContent = 'Update playback engine';
    },
  });
  setView(
    h('h1', { text: 'Settings', style: 'font-size:40px;margin-bottom:10px' }),
    h('div.settings',
      h('section',
        h('h2', { text: 'Spotify account' }),
        h('p', { text: `Signed in as ${state.user.name}. FreeTune reads your library, playlists and recommendations from Spotify. It never plays audio from Spotify, so Spotify can’t insert ads.` }),
        h('div.btns', h('button.pill.danger', { text: 'Sign out', onclick: async () => { await api('logout'); ft.uiCacheSet(null).catch(() => {}); state.cache.clear(); location.hash = ''; showSignIn(); } }))
      ),
      h('section',
        h('h2', { text: 'Playback' }),
        h('p', { text: 'Songs play from YouTube Music, matched by title, artist and length. If a song sounds wrong, right-click it and choose “Wrong song?” to pick the right recording.' }),
        h('div.btns',
          updateBtn,
          h('button.pill', { text: 'Forget saved matches', onclick: async () => { await api('clearMatches'); toast('Saved matches cleared. Songs will be matched again as they play.'); } })
        )
      ),
      h('section',
        h('h2', { text: 'Privacy' }),
        h('ul',
          h('li', { text: 'No ads, no analytics, no crash reporting. FreeTune has no server of its own.' }),
          h('li', { text: 'The Spotify sign-in window blocks Spotify’s ad, tracking and event-logging requests.' }),
          h('li', { text: 'YouTube Music is searched and streamed without an account or cookies, so plays aren’t tied to you.' }),
          h('li', { text: 'Your matches, settings and a troubleshooting log are stored only on this PC.' })
        ),
        h('div.btns', h('button.pill', { text: 'Open log folder', onclick: () => api('openLogs') }))
      ),
      downloadsSection(),
      botSection(),
      discordSection(),
      updatesSection(version),
      h('section',
        h('h2', { text: 'About' }),
        h('p', {}, `FreeTune ${version}. Spotify integration ported from `,
          h('a.link', { href: '#', onclick: (e) => { e.preventDefault(); api('openExternal', 'https://github.com/FrancescoGrazioso/Meld'); }, text: 'Meld' }),
          ' by Francesco Grazioso. Audio extraction by ',
          h('a.link', { href: '#', onclick: (e) => { e.preventDefault(); api('openExternal', 'https://github.com/yt-dlp/yt-dlp'); }, text: 'yt-dlp' }),
          '. Free software under the GPL-3.0 license. Not affiliated with Spotify or YouTube.'
        )
      )
    )
  );
}

// ── sign-in ────────────────────────────────────────────────────────────────────
function showSignIn() {
  state.user = null;
  document.body.classList.add('signed-out');
  player.stop();
  const btn = h('button.pill.primary', {
    onclick: async () => {
      btn.disabled = true;
      btn.lastChild.textContent = 'Waiting for Spotify…';
      try {
        const s = await api('login');
        await onSignedIn(s.user);
      } catch (e) {
        toast(/closed/i.test(e.message) ? 'Sign-in was cancelled' : e.message, true);
      }
      btn.disabled = false;
      btn.lastChild.textContent = 'Sign in with Spotify';
    },
  }, icon('spotify'), h('span', { text: 'Sign in with Spotify' }));
  main.replaceChildren(h('div.signin', h('div.signin-card',
    h('h1', { text: 'Your Spotify, without the ads.' }),
    h('p', { text: 'FreeTune shows your Spotify playlists, liked songs and recommendations, and plays them from YouTube Music with no ads and no tracking.' }),
    h('p', { text: 'A free Spotify account works. Spotify’s own sign-in page opens in a new window.' }),
    btn,
    h('p.fine', { text: 'Your password goes only to Spotify. FreeTune keeps the sign-in on this PC so you stay signed in.' })
  )));
}

// fromCopy: drawn from the saved copy of the screens before Spotify has answered.
// refresh: Spotify has answered after that: bring everything up to date quietly.
async function onSignedIn(user, { fromCopy = false, refresh = false } = {}) {
  state.user = user;
  document.body.classList.remove('signed-out');
  $('#side-user').textContent = (user.name || '?').trim().charAt(0) || '?';
  $('.user-btn').title = `${user.name || 'You'} · Settings`;
  if (refresh) {
    loadSidebar({ quiet: true });
    warmUp();
    return;
  }
  if (fromCopy && state.playlists.length) renderLibrary();
  else loadSidebar();
  try { const sp = localStorage.getItem('ft.sidePanel'); if (sp) showSidePanel(sp); } catch {}
  if (!location.hash || location.hash === '#') location.hash = 'home';
  else route();
  if (!fromCopy) warmUp();
}

// After start: hearts for liked songs, then Liked Songs and your top playlists are loaded
// in the background (one at a time), so opening them from the menu is instant.
let warmedUp = false;
function warmUp() {
  if (warmedUp) return;
  warmedUp = true;
  (async () => {
    try {
      // The first 500 liked songs: hearts show correctly, and Liked Songs opens at once.
      const got = [];
      let total = 0;
      for (let off = 0; off < 500; off += 50) {
        const p = await api('liked', off);
        total = p.total;
        got.push(...p.tracks);
        p.tracks.forEach((t) => state.liked.add(t.uri));
        if (off + 50 >= p.total) break;
      }
      document.querySelectorAll('.like[data-uri]').forEach((b) => b.setAttribute('aria-pressed', String(state.liked.has(b.dataset.uri))));
      syncNowPlayingLike();
      const hit = state.cache.get('liked');
      if (!hit || hit.partial || Date.now() - hit.at > LIKED_TTL) state.cache.set('liked', { at: Date.now(), data: { total, tracks: got }, partial: got.length < total });
    } catch {}
    await new Promise((r) => setTimeout(r, 1500));
    const jobs = state.playlists.slice(0, 8).map((p) => () => warmPlaylist(p.id));
    for (const job of jobs) {
      if (!state.user) return;
      await job();
      await new Promise((r) => setTimeout(r, 700));
    }
    saveSnapshotSoon();
  })();
}
// Up to 300 songs ahead of time (a long playlist loads the rest when it's opened).
function warmPlaylist(id) {
  const key = `playlist:${id}`;
  const hit = state.cache.get(key);
  if ((hit && Date.now() - hit.at < PLAYLIST_TTL) || refreshing.has(key)) return Promise.resolve();
  return loadPlaylistAll(id, null, 300)
    .then((data) => {
      const now = state.cache.get(key);
      if (now && !now.partial && Date.now() - now.at < PLAYLIST_TTL) return;
      state.cache.set(key, { at: Date.now(), data, partial: data.tracks.length < (data.info.total || 0) });
      saveSnapshotSoon();
    })
    .catch(() => {});
}
// Hovering (or touching) a link starts loading that page, so it's ready when you click.
function prefetchHref(href) {
  if (!state.user) return;
  const m = /^#(playlist|album|artist|show|liked)(?:\/([\w-]+))?$/.exec(href || '');
  if (!m) return;
  const [, kind, id] = m;
  if (kind === 'liked') warm('liked', LIKED_TTL, () => loadLikedAll(null));
  else if (kind === 'playlist') warmPlaylist(id);
  else if (kind === 'album') warm(`album:${id}`, 30 * 60 * 1000, () => api('album', id));
  else if (kind === 'artist') warm(`artist:${id}`, 30 * 60 * 1000, () => api('artist', id));
  else if (kind === 'show') warm(`show:${id}`, 15 * 60 * 1000, () => api('show', id));
}
{
  let hoverTimer = null;
  document.addEventListener('pointerover', (e) => {
    const a = e.target.closest && e.target.closest('a[href^="#"]');
    if (!a) return;
    clearTimeout(hoverTimer);
    hoverTimer = setTimeout(() => prefetchHref(a.getAttribute('href')), 90);
  });
  document.addEventListener('pointerout', () => clearTimeout(hoverTimer));
  document.addEventListener('touchstart', (e) => {
    const a = e.target.closest && e.target.closest('a[href^="#"]');
    if (a) prefetchHref(a.getAttribute('href'));
  }, { passive: true });
}

// ── Your Library (sidebar) ─────────────────────────────────────────────────────
async function loadSidebar({ quiet = false } = {}) {
  const box = $('#side-playlists');
  renderPinned();
  if (!quiet || !state.playlists.length) box.replaceChildren(...Array.from({ length: 6 }, () => h('div.skeleton', { style: 'height:48px;margin:8px' })));
  const before = JSON.stringify([state.playlists, state.local, state.ytlib]);
  const [sp, local, me, ytlib] = await Promise.all([
    api('playlists').catch((e) => ({ error: e })),
    api('localPlaylists').catch(() => []),
    api('myId').catch(() => ''),
    api('ytLibrary').catch(() => state.ytlib),
  ]);
  state.local = Array.isArray(local) ? local : [];
  state.ytlib = Array.isArray(ytlib) ? ytlib : [];
  state.myId = me || '';
  if (sp && sp.error) {
    renderLibrary();
    if (!state.playlists.length) box.append(h('button.pill', { text: 'Reload Spotify playlists', style: 'margin:8px', onclick: () => loadSidebar() }));
    return;
  }
  state.playlists = sp;
  const changed = JSON.stringify([state.playlists, state.local, state.ytlib]) !== before;
  if (changed || !quiet) renderLibrary();
  if (changed && (location.hash === '#home' || !location.hash)) route({ keepScroll: true });
  saveSnapshotSoon();
}

// Only the on-this-PC list changes locally; Spotify's own list is reloaded on start.
async function refreshLibrary() {
  try {
    state.local = await api('localPlaylists');
    renderLibrary();
  } catch {}
}

function renderPinned() {
  const yt = state.ytLiked.length || state.dl.collections['ytliked:me'];
  $('#side-pinned').replaceChildren(
    h('a', { href: '#liked', title: 'Liked Songs', dataset: { source: 'liked:me', dl: 'liked:me' } },
      coverEl({ type: 'liked' }),
      h('div.txt', h('div.nm', { text: 'Liked Songs' }), h('div.sb', h('span.dl-dot', { html: ICONS.downloaded }), srcMark('spotify'), 'Playlist')),
      h('span.spk', { html: ICONS.speaker })
    ),
    yt
      ? h('a', { href: '#ytliked', title: YT_LIKED, dataset: { source: 'ytliked:me', dl: 'ytliked:me' } },
          coverEl({ type: 'ytliked' }),
          h('div.txt', h('div.nm', { text: YT_LIKED }), h('div.sb', h('span.dl-dot', { html: ICONS.downloaded }), srcMark('ytm'), 'Playlist • ', h('span.yt-count', { text: plural(state.ytLiked.length, 'song') }))),
          h('span.spk', { html: ICONS.speaker })
        )
      : ''
  );
  document.querySelectorAll('#side-pinned a[data-dl]').forEach(paintLibDl);
  if (state.libFilter === 'artists' || state.libFilter === 'podcasts' || state.libFilter === 'downloaded') $('#side-pinned').replaceChildren();
}

function libItem(p) {
  const mine = p.local || isMineSpotify(p);
  const sub = p.type === 'artist'
    ? ['Artist']
    : p.type === 'liked'
    ? [srcMark('spotify'), 'Playlist']
    : p.type === 'ytliked'
    ? [srcMark('ytm'), 'Playlist']
    : p.type === 'album'
    ? [`Album${p.owner ? ` • ${p.owner}` : ''}`]
    : p.type === 'show'
    ? [`Podcast${p.publisher ? ` • ${p.publisher}` : ''}`]
    : p.type === 'ytplaylist' || p.type === 'ytalbum'
    ? [srcMark('ytm'), `${p.type === 'ytalbum' ? 'Album' : 'Playlist'}${p.owner ? ` • ${p.owner}` : ''}`]
    : p.local
    ? [icon('pc'), 'Playlist • On this PC']
    : [srcMark('spotify'), `Playlist • ${p.owner || 'Spotify'}`];
  const a = h('a', {
    href: p.type === 'liked' ? '#liked' : p.type === 'ytliked' ? '#ytliked' : ['artist', 'show', 'album', 'ytplaylist', 'ytalbum'].includes(p.type) ? `#${p.type}/${p.id}` : hrefOf(p),
    title: p.name,
    'data-dl': dlKeyOf(p) || null,
    dataset: { source: p.type === 'artist' || p.type === 'show' ? `${p.type}:${p.id}` : p.local ? `mine:${p.id}` : `playlist:${p.id}` },
    oncontextmenu: (e) => { e.preventDefault(); if (p.type === 'playlist') playlistMenu(p, e.clientX, e.clientY); },
  },
    coverEl(p),
    h('div.txt', h('div.nm', { text: p.name }), h('div.sb', h('span.dl-dot', { html: ICONS.downloaded }), sub)),
    h('span.spk', { html: ICONS.speaker })
  );
  paintLibDl(a);
  if (mine) {
    // Drop songs here to add them.
    a.addEventListener('dragover', (e) => { if (dragData && dragData.tracks) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; a.classList.add('drop'); } });
    a.addEventListener('dragleave', () => a.classList.remove('drop'));
    a.addEventListener('drop', (e) => { e.preventDefault(); a.classList.remove('drop'); if (dragData && dragData.tracks) addTracksTo(p, dragData.tracks); });
  }
  return a;
}

let artistsLoaded = false;
let showsLoaded = false;
function renderLibrary() {
  const box = $('#side-playlists');
  renderPinned();
  document.querySelectorAll('.chips .chip').forEach((c) => c.setAttribute('aria-selected', String(c.dataset.filter === state.libFilter)));
  const text = ($('#lib-filter').value || '').trim().toLowerCase();
  let items;
  if (state.libFilter === 'downloaded') {
    items = state.dl.list.map((d) => (d.type === 'liked'
      ? { type: 'liked', id: 'me', name: 'Liked Songs' }
      : d.type === 'ytliked'
      ? { type: 'ytliked', id: 'me', name: YT_LIKED }
      : { type: d.type === 'mine' ? 'playlist' : d.type, local: d.type === 'mine', id: d.id, name: d.name, image: d.image, owner: d.owner, covers: d.image ? [d.image] : [] }));
  } else if (state.libFilter === 'podcasts') {
    if (!showsLoaded) {
      showsLoaded = true;
      api('shows').then((a) => { state.shows = a; renderLibrary(); }).catch(() => { showsLoaded = false; });
    }
    items = state.shows || [];
  } else if (state.libFilter === 'artists') {
    if (!artistsLoaded) {
      artistsLoaded = true;
      api('artists').then((a) => { state.artists = a; renderLibrary(); }).catch(() => { artistsLoaded = false; });
    }
    items = state.artists || [];
  } else {
    items = [...state.local, ...state.playlists, ...(state.libFilter === 'mine' ? [] : state.ytlib || [])];
    if (state.libFilter === 'mine') items = items.filter((p) => p.local || isMineSpotify(p));
  }
  if (text) items = items.filter((p) => p.name.toLowerCase().includes(text) || (p.owner || '').toLowerCase().includes(text));
  box.replaceChildren(...items.map(libItem));
  if (!items.length) {
    box.replaceChildren(h('div.side-empty',
      text ? `Nothing in Your Library matches “${text}”.`
        : state.libFilter === 'mine' ? h('div', h('p', { text: 'Playlists you make show up here.' }), h('button.pill', { onclick: () => createAndOpen() }, icon('plus'), 'Create playlist'))
        : state.libFilter === 'podcasts' ? 'Podcasts you follow in Spotify show up here.'
        : state.libFilter === 'downloaded' ? 'Downloads show up here. Use the download button on a playlist, album or Liked Songs to play it without internet.'
        : 'Playlists you make or follow in Spotify show up here.'));
  }
  markCurrent();
}

document.querySelectorAll('.chips .chip').forEach((c) => {
  c.onclick = () => {
    state.libFilter = state.libFilter === c.dataset.filter ? '' : c.dataset.filter;
    try { localStorage.setItem('ft.libFilter', state.libFilter); } catch {}
    renderLibrary();
  };
});
$('#lib-filter').addEventListener('input', () => renderLibrary());
$('#lib-title').onclick = () => { state.libFilter = ''; $('#lib-filter').value = ''; renderLibrary(); };
$('#create-btn').onclick = () => createAndOpen();

// ── player ─────────────────────────────────────────────────────────────────────
const audio = $('#audio');
const player = (() => {
  const q = state.queue;
  let playId = 0;
  let failures = 0;
  let seeking = false;

  const current = () => (q.pos >= 0 ? q.tracks[q.pos] : null);
  let loaded = null; // the song or episode the audio element holds right now

  function shuffleArr(a) {
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function playList(list, index, source, sourceName) {
    const tracks = list.filter(Boolean);
    q.original = tracks.slice();
    q.source = source;
    q.sourceName = sourceName || '';
    if (state.shuffle) {
      const first = tracks[index];
      const rest = tracks.filter((_, i) => i !== index);
      q.tracks = [first, ...shuffleArr(rest)];
      q.pos = 0;
    } else {
      q.tracks = tracks;
      q.pos = index;
    }
    failures = 0;
    start();
  }

  function setShuffle(on) {
    state.shuffle = on;
    $('#shuffle').setAttribute('aria-pressed', String(on));
    ft.setSetting('shuffle', on);
    if (!q.tracks.length) return;
    const cur = current();
    if (on) {
      const rest = q.tracks.filter((_, i) => i !== q.pos);
      q.tracks = [cur, ...shuffleArr(rest)];
      q.pos = 0;
    } else {
      q.tracks = q.original.slice();
      q.pos = Math.max(0, q.tracks.indexOf(cur));
    }
    renderQueue();
    preloadAround(300);
  }

  function setRepeat(mode) {
    state.repeat = mode;
    const b = $('#repeat');
    b.setAttribute('aria-pressed', String(mode !== 'off'));
    b.classList.toggle('one', mode === 'one');
    b.title = mode === 'off' ? 'Repeat' : mode === 'all' ? 'Repeat: all' : 'Repeat: this song';
    ft.setSetting('repeat', mode);
  }

  async function start() {
    const t = current();
    if (!t) return;
    saveProgress(true);
    loaded = null;
    const id = ++playId;
    showNowPlaying(t);
    document.body.classList.add('is-loading');
    audio.pause();
    try {
      if (t.playable === false) throw new Error('This song isn’t available');
      // Already saved and waiting: start it now. Otherwise look it up.
      const r = ahead && ahead.track === t ? { src: ahead.src } : await api('prepare', t);
      ahead = null;
      aheadTries = 0;
      if (id !== playId) return;
      // Podcast episodes pick up where you stopped (remembered on this PC only).
      const resume = isEpisode(t) ? await api('episodeProgress', t.uri).catch(() => null) : null;
      if (id !== playId) return;
      audio.src = r.src;
      loaded = t;
      if (resume && resume.pos > 15) {
        audio.addEventListener('loadedmetadata', () => {
          if (id === playId && audio.currentTime < 1) audio.currentTime = resume.pos;
        }, { once: true });
        toast(`Picking up “${t.name}” at ${fmtTime(resume.pos)}`);
      }
      await audio.play();
      failures = 0;
      preloadAround();
    } catch (e) {
      if (id !== playId) return;
      if (e.name === 'AbortError') return; // a newer play() replaced this one
      onFail(t, e);
    }
  }

  function onFail(t, e) {
    document.body.classList.remove('is-loading');
    console.warn('play failed', t.name, e);
    const why = e && e.message && !/MEDIA_ERR|no supported source/i.test(e.message) ? e.message : 'the audio stream didn’t load';
    // An episode that's only on Spotify isn't a playback problem: move on without counting it.
    const spotifyOnly = /only on Spotify/i.test(why);
    if (!spotifyOnly) failures++;
    // YouTube's bot check blocks every song, so skipping ahead would only make it worse: stop here.
    if (/(not|isn.t) a bot|ways in work|refusing to send/i.test(why)) {
      failures = 0;
      document.body.classList.remove('is-playing');
      toast(why, true);
      return;
    }
    if (failures >= 3) {
      toast(`Playback stopped after several songs failed. Last error: ${why}. Try “Update playback engine” in Settings.`, true);
      document.body.classList.remove('is-playing');
      return;
    }
    toast(spotifyOnly ? `Skipped “${t.name}”: it’s only on Spotify (no public feed or YouTube copy)` : `Skipped “${t.name}”: ${why}`, true);
    if (q.pos < q.tracks.length - 1) {
      q.pos++;
      start();
    }
  }

  // Save the next song and the previous one on this PC while this one plays, so skipping
  // either way (or the song ending) starts instantly with no gap. Waits a moment so the
  // current song gets the connection first.
  // Once the next song is saved, its address is kept ready ("ahead"), so when this song
  // ends the next one starts right away, with no lookups in between.
  let preloadTimer = null;
  let ahead = null; // { track, src }
  let aheadTries = 0;
  const upNext = () => (state.repeat === 'one' ? null : q.tracks[q.pos + 1] || (state.repeat === 'all' ? q.tracks[0] : null));
  function preloadAround(delay = 1500) {
    clearTimeout(preloadTimer);
    preloadTimer = setTimeout(warmAhead, delay);
  }
  async function warmAhead() {
    const next = upNext();
    const prev = q.tracks[q.pos - 1];
    const list = [next, prev].filter((t) => t && t !== current());
    if (!list.length) return;
    aheadTries++;
    await ft.preloadSongs(list).catch(() => {});
    if (!next || next !== upNext() || (ahead && ahead.track === next)) return;
    const r = await ft.prepare(next, { warm: true }).catch(() => null);
    if (r && r.ok && r.data && r.data.cached && next === upNext()) ahead = { track: next, src: r.data.src };
  }
  // Safety net: 25 seconds before the end, if the next song still isn't ready, try again.
  audio.addEventListener('timeupdate', () => {
    const d = audio.duration;
    if (!(d > 0) || d - audio.currentTime > 25 || aheadTries > 2) return;
    const next = upNext();
    if (next && !(ahead && ahead.track === next) && !isEpisode(next)) warmAhead();
  });

  function next(auto = false) {
    if (!q.tracks.length) return;
    if (auto && state.repeat === 'one') {
      audio.currentTime = 0;
      audio.play();
      return;
    }
    if (q.pos < q.tracks.length - 1) q.pos++;
    else if (state.repeat === 'all' || !auto) q.pos = 0;
    else {
      document.body.classList.remove('is-playing');
      return;
    }
    start();
  }

  function prev() {
    if (!q.tracks.length) return;
    if (audio.currentTime > 3 || q.pos === 0) {
      audio.currentTime = 0;
      return;
    }
    q.pos--;
    start();
  }

  function toggle() {
    if (!current()) {
      if (state.playlists[0]) playCollection(state.playlists[0]);
      return;
    }
    if (audio.paused) {
      if (!audio.src) start();
      else audio.play().catch(() => start());
    } else audio.pause();
  }

  function extend(tracks, source) {
    if (q.source !== source || !tracks.length) return false;
    q.tracks.push(...tracks);
    q.original.push(...tracks);
    renderQueue();
    if (q.pos >= q.tracks.length - tracks.length - 1) preloadAround(300);
    return true;
  }
  function playNext(t) {
    if (!q.tracks.length) return playList([t], 0, null, '');
    q.tracks.splice(q.pos + 1, 0, t);
    q.original.push(t);
    toast(`“${t.name}” will play next`);
    renderQueue();
    preloadAround(300);
  }
  function enqueue(t) {
    if (!q.tracks.length) return playList([t], 0, null, '');
    q.tracks.push(t);
    q.original.push(t);
    toast(`Added “${t.name}” to the queue`);
    renderQueue();
    if (q.pos === q.tracks.length - 2) preloadAround(300);
  }
  function jump(pos) {
    q.pos = pos;
    start();
  }
  function stop() {
    audio.pause();
    audio.removeAttribute('src');
    document.body.classList.remove('is-playing', 'is-loading');
    ft.discordUpdate(null);
  }
  function reload() {
    const t = audio.currentTime;
    start().then(() => {});
    audio.addEventListener('loadedmetadata', () => { if (t > 1) audio.currentTime = t; }, { once: true });
  }

  // audio element events
  audio.addEventListener('playing', () => {
    document.body.classList.add('is-playing');
    document.body.classList.remove('is-loading');
    navigator.mediaSession.playbackState = 'playing';
    reportPresence();
  });
  audio.addEventListener('pause', () => {
    document.body.classList.remove('is-playing');
    navigator.mediaSession.playbackState = 'paused';
    reportPresence();
  });
  audio.addEventListener('seeked', () => reportPresence());
  audio.addEventListener('waiting', () => document.body.classList.add('is-loading'));
  audio.addEventListener('canplay', () => document.body.classList.remove('is-loading'));
  audio.addEventListener('ended', () => next(true));
  audio.addEventListener('error', () => {
    if (!audio.getAttribute('src')) return;
    const t = current();
    if (t) onFail(t, new Error(audio.error && audio.error.message ? audio.error.message : 'the audio stream didn’t load'));
  });
  audio.addEventListener('timeupdate', updateTime);
  // Remember where you are in an episode (every 10 seconds, on pause, and when moving on).
  let progressAt = 0;
  function saveProgress(force) {
    const t = loaded;
    if (!isEpisode(t) || !audio.getAttribute('src') || !(audio.duration > 0)) return;
    if (!force && Date.now() - progressAt < 10000) return;
    progressAt = Date.now();
    ft.saveEpisodeProgress(t.uri, audio.currentTime, audio.duration).catch(() => {});
  }
  audio.addEventListener('timeupdate', () => saveProgress(false));
  audio.addEventListener('pause', () => saveProgress(true));
  audio.addEventListener('ended', () => {
    const t = loaded;
    if (isEpisode(t)) ft.saveEpisodeProgress(t.uri, 0, 0).catch(() => {});
  });
  window.addEventListener('beforeunload', () => saveProgress(true));
  audio.addEventListener('durationchange', updateTime);

  const seek = $('#seek');
  function trackDuration() {
    if (isFinite(audio.duration) && audio.duration > 0) return audio.duration;
    const t = current();
    return t && t.durationMs ? t.durationMs / 1000 : 0;
  }
  function updateTime() {
    const dur = trackDuration();
    $('#t-dur').textContent = fmtTime(dur);
    if (seeking) return;
    $('#t-cur').textContent = fmtTime(audio.currentTime);
    const v = dur ? Math.round((audio.currentTime / dur) * 1000) : 0;
    seek.value = v;
    seek.style.setProperty('--pct', v / 10 + '%');
    if (dur && 'setPositionState' in navigator.mediaSession) {
      try {
        navigator.mediaSession.setPositionState({ duration: dur, position: Math.min(audio.currentTime, dur), playbackRate: 1 });
      } catch {}
    }
  }
  seek.addEventListener('input', () => {
    seeking = true;
    const dur = trackDuration();
    $('#t-cur').textContent = fmtTime((seek.value / 1000) * dur);
    seek.style.setProperty('--pct', seek.value / 10 + '%');
  });
  seek.addEventListener('change', () => {
    const dur = trackDuration();
    if (dur) audio.currentTime = (seek.value / 1000) * dur;
    seeking = false;
  });

  // volume
  const vol = $('#volume');
  let lastVol = 0.8;
  function setVolume(v, save = true) {
    v = Math.max(0, Math.min(1, v));
    audio.volume = v * v; // perceptual curve
    vol.value = Math.round(v * 100);
    vol.style.setProperty('--pct', vol.value + '%');
    $('#mute').classList.toggle('muted', v === 0);
    if (v > 0) lastVol = v;
    if (save) ft.setSetting('volume', v);
  }
  vol.addEventListener('input', () => setVolume(vol.value / 100));
  $('#mute').onclick = () => setVolume(Number(vol.value) ? 0 : lastVol || 0.8);

  $('#play').onclick = toggle;
  $('#next').onclick = () => next(false);
  $('#prev').onclick = prev;
  $('#shuffle').onclick = () => setShuffle(!state.shuffle);
  $('#repeat').onclick = () => setRepeat(state.repeat === 'off' ? 'all' : state.repeat === 'all' ? 'one' : 'off');

  // Windows media keys and the volume flyout's media controls
  const ms = navigator.mediaSession;
  ms.setActionHandler('play', () => audio.play());
  ms.setActionHandler('pause', () => audio.pause());
  ms.setActionHandler('nexttrack', () => next(false));
  ms.setActionHandler('previoustrack', prev);
  try {
    ms.setActionHandler('seekto', (d) => { audio.currentTime = d.seekTime; });
  } catch {}

  return { playList, current, next, prev, toggle, setShuffle, setRepeat, setVolume, playNext, enqueue, extend, jump, stop, reload, trackDuration };
})();

function showNowPlaying(t) {
  const art = $('#np-art');
  if (t.image) art.src = t.image;
  else art.removeAttribute('src');
  const title = $('#np-title');
  title.textContent = t.name;
  title.href = t.album && t.album.id ? `#album/${t.album.id}` : '#';
  $('#np-artist').replaceChildren(artistLinks(t.artists));
  $('#np-like').hidden = !t.uri || isEpisode(t);
  syncNowPlayingLike();
  document.title = `${t.name} – ${t.artists.map((a) => a.name).join(', ')}`;
  applyPlayerTint(t.image);
  $('#seek').value = 0;
  $('#seek').style.setProperty('--pct', '0%');
  $('#t-cur').textContent = '0:00';
  $('#t-dur').textContent = t.durationMs ? fmtTime(t.durationMs / 1000) : '0:00';
  navigator.mediaSession.metadata = new MediaMetadata({
    title: t.name,
    artist: t.artists.map((a) => a.name).join(', '),
    album: (t.album && t.album.name) || '',
    artwork: [t.imageLarge || t.image].filter(Boolean).map((src) => ({ src, sizes: '640x640', type: 'image/jpeg' })),
  });
  markCurrent();
  renderQueue();
  if (location.hash === '#lyrics') viewLyrics();
  reportPresence();
}
function syncNowPlayingLike() {
  const t = player.current();
  const b = $('#np-like');
  b.setAttribute('aria-pressed', String(!!(t && state.liked.has(t.uri))));
  b.setAttribute('aria-label', t ? likeLabel(t) : 'Save to Liked songs');
}
$('#np-like').onclick = () => {
  const t = player.current();
  if (t) toggleLike(t);
};


// ── lyrics ─────────────────────────────────────────────────────────────────────
const lyricsUI = (() => {
  let lines = [];       // [{ t, text, el }]
  let synced = false;
  let active = -1;
  let raf = 0;
  let userScrollUntil = 0;
  let resyncBtn = null;

  function detach() {
    cancelAnimationFrame(raf);
    raf = 0;
    lines = [];
    active = -1;
  }

  function onUserScroll() {
    if (!synced || !lines.length) return;
    userScrollUntil = Date.now() + 4000;
    if (resyncBtn) resyncBtn.hidden = false;
  }
  main.addEventListener('wheel', onUserScroll, { passive: true });
  main.addEventListener('keydown', (e) => { if (/^(ArrowUp|ArrowDown|PageUp|PageDown|Home|End)$/.test(e.key)) onUserScroll(); });

  function centerOn(el, smooth = true) {
    const top = el.offsetTop - main.clientHeight * 0.38;
    main.scrollTo({ top: Math.max(0, top), behavior: smooth && !matchMedia('(prefers-reduced-motion: reduce)').matches ? 'smooth' : 'auto' });
  }

  function tick() {
    raf = requestAnimationFrame(tick);
    if (!synced || !lines.length) return;
    const t = audio.currentTime + 0.25; // show the line just before it's sung
    let i = active;
    if (i < 0 || i >= lines.length || lines[i].t > t || (lines[i + 1] && lines[i + 1].t <= t)) {
      // binary search for the last line whose time has passed
      let lo = 0, hi = lines.length - 1;
      i = -1;
      while (lo <= hi) {
        const mid = (lo + hi) >> 1;
        if (lines[mid].t <= t) { i = mid; lo = mid + 1; } else hi = mid - 1;
      }
    }
    if (i === active) return;
    if (active >= 0 && lines[active]) lines[active].el.classList.remove('active');
    lines.forEach((l, k) => l.el.classList.toggle('past', k < i));
    active = i;
    if (i >= 0) {
      lines[i].el.classList.add('active');
      if (Date.now() > userScrollUntil) {
        centerOn(lines[i].el);
        if (resyncBtn) resyncBtn.hidden = true;
      }
    }
  }

  function render(container, data, track) {
    detach();
    synced = !!data.synced;
    const wrap = h(`div.lyrics${synced ? '' : '.plain'}`);
    if (!synced) wrap.append(h('p.note', { text: 'These lyrics aren’t synced to the song yet.' }));
    lines = data.lines.map((l) => {
      const gap = synced && !l.text;
      const el = h(`button.line${gap ? '.gap' : ''}`, {
        type: 'button',
        tabindex: synced ? '0' : '-1',
        text: gap ? '♪' : l.text || ' ',
        onclick: synced ? () => {
          audio.currentTime = l.t;
          if (audio.paused) audio.play().catch(() => {});
          userScrollUntil = 0;
        } : null,
      });
      wrap.append(el);
      return { t: l.t, text: l.text, el };
    });
    resyncBtn = synced ? h('button.pill.resync', { hidden: true, text: 'Back to current line', onclick: () => {
      userScrollUntil = 0;
      if (active >= 0) centerOn(lines[active].el);
      resyncBtn.hidden = true;
    } }) : null;
    wrap.append(
      h('div.credit',
        h('span', { text: `Lyrics from ${data.source}` }),
        h('button', { type: 'button', text: 'Search again', onclick: () => viewLyrics({ refresh: true }) })
      )
    );
    container.replaceChildren(wrap);
    if (resyncBtn) container.append(resyncBtn);
    main.scrollTop = 0;
    if (synced) {
      active = -1;
      userScrollUntil = 0;
      raf = requestAnimationFrame(tick);
    }
    void track;
  }

  return { render, detach };
})();

let lyricsReq = 0;
async function viewLyrics(opts) {
  const refresh = !!(opts && opts.refresh);
  const t = player.current();
  const view = main.querySelector('.view.lyrics-host') || setView();
  view.classList.add('lyrics-host');
  if (!t) {
    view.replaceChildren(h('div.lyrics-empty', h('div',
      h('h2', { text: 'Play a song to see its lyrics' }),
      h('p', { text: 'Lyrics appear here and follow along as the song plays.' })
    )));
    return;
  }
  const req = ++lyricsReq;
  lyricsUI.detach();
  view.replaceChildren(h('div.lyrics', Array.from({ length: 7 }, (_, i) => h('div.sk', { style: `width:${[62, 80, 55, 74, 68, 85, 50][i]}%` }))));
  try {
    const data = await api('lyrics', t, { refresh });
    if (req !== lyricsReq || location.hash !== '#lyrics') return;
    if (data.episode) {
      view.replaceChildren(h('div.lyrics-empty', h('div', h('h2', { text: 'No lyrics for podcasts' }), h('p', { text: 'Lyrics are only shown for songs.' }))));
    } else if (data.instrumental) {
      view.replaceChildren(h('div.lyrics-empty', h('div', h('h2', { text: '♪ Instrumental' }), h('p', { text: 'This track has no lyrics.' }))));
    } else if (!data.lines || !data.lines.length) {
      view.replaceChildren(h('div.lyrics-empty', h('div',
        h('h2', { text: 'No lyrics found for this song' }),
        h('p', { text: 'FreeTune checked LRCLIB, KuGou and YouTube Music. Lyrics may be added later.' }),
        h('button.pill', { text: 'Search again', onclick: () => viewLyrics({ refresh: true }) })
      )));
    } else {
      lyricsUI.render(view, data, t);
    }
  } catch (e) {
    if (req !== lyricsReq) return;
    view.replaceChildren(h('div.lyrics-empty', h('div',
      h('h2', { text: 'Lyrics didn’t load' }),
      h('p', { text: e.message }),
      h('button.pill', { text: 'Try again', onclick: () => viewLyrics({ refresh: true }) })
    )));
  }
}

$('#lyrics-btn').onclick = () => {
  if (location.hash === '#lyrics') history.back();
  else go('lyrics');
};

// ── Discord ────────────────────────────────────────────────────────────────────
// Tells FreeTune's Discord connection what's playing (only used if turned on in Settings).
function reportPresence() {
  const t = player.current();
  if (!t || !audio.getAttribute('src')) return ft.discordUpdate(null);
  ft.discordUpdate({
    title: t.name,
    artists: t.artists.map((a) => a.name).join(', '),
    album: t.album && t.album.name,
    image: t.imageLarge || t.image,
    durationMs: isFinite(audio.duration) && audio.duration > 0 ? audio.duration * 1000 : t.durationMs,
    positionMs: audio.currentTime * 1000,
    playing: !audio.paused,
    uri: t.uri,
  });
}

let discordPaint = null;
ft.onDiscordStatus((st) => discordPaint && discordPaint(st));
const DISCORD_STATUS = {
  off: 'Off.',
  connected: 'Connected. Your Discord profile shows what you’re playing.',
  'no-discord': 'Waiting for Discord. Open the Discord desktop app and FreeTune connects by itself.',
  'bad-id': 'Discord didn’t accept that Application ID. Check you copied the Application ID (a long number), not the name.',
};
function discordSection() {
  const status = h('p', { text: '' });
  const paint = (st) => { status.textContent = `Status: ${DISCORD_STATUS[st] || st}`; };
  ft.discordStatus().then((r) => r && r.ok && paint(r.data));
  discordPaint = paint;
  const idInput = h('input', { type: 'text', inputmode: 'numeric', placeholder: 'Application ID, e.g. 1290000000000000000', 'aria-label': 'Discord Application ID', style: 'flex:1;min-width:260px;background:var(--bg);border:1px solid var(--line);border-radius:4px;padding:8px 10px;color:inherit;outline:none' });
  const toggle = h('input', { type: 'checkbox', 'aria-label': 'Show on Discord', style: 'width:18px;height:18px;accent-color:var(--accent)' });
  Promise.all([ft.getSetting('discordClientId'), ft.getSetting('discordEnabled')]).then(([id, on]) => {
    idInput.value = (id && id.ok && id.data) || '';
    toggle.checked = !!(on && on.ok && on.data);
  });
  const save = async () => {
    const id = idInput.value.replace(/\D/g, '');
    idInput.value = id;
    if (toggle.checked && !/^\d{15,22}$/.test(id)) {
      toggle.checked = false;
      toast('Paste your Discord Application ID first (steps above).', true);
      return;
    }
    await ft.setSetting('discordClientId', id);
    await ft.setSetting('discordEnabled', toggle.checked);
    if (toggle.checked) setTimeout(reportPresence, 1500);
    toast(toggle.checked ? 'Discord status on' : 'Discord status off');
  };
  toggle.addEventListener('change', save);
  idInput.addEventListener('change', save);
  return h('section',
    h('h2', { text: 'Discord' }),
    h('p', { text: 'Show the song you’re playing on your Discord profile, with album art, a time bar and an “Open in Spotify” button. Only your song name, artist and album art go to Discord, and only while this is on.' }),
    h('ol', { style: 'color:var(--muted);padding-left:20px;margin:0 0 14px;user-select:text' },
      h('li', {}, 'In your browser, go to discord.com/developers/applications and sign in.'),
      h('li', {}, 'Click “New Application” and name it FreeTune. The name is what friends see: “Listening to FreeTune”.'),
      h('li', {}, 'Copy the Application ID from the General Information page and paste it below.')),
    h('div.btns', { style: 'align-items:center' }, idInput, h('label', { style: 'display:flex;align-items:center;gap:8px;font-weight:600' }, toggle, 'Show on Discord')),
    status);
}

// ── Now playing view (right panel) ─────────────────────────────────────────────
function renderNowPlayingView() {
  const panel = $('#nowplaying');
  if (panel.hidden) return;
  const t = player.current();
  const q = state.queue;
  $('#npv-source').textContent = q.sourceName || 'Now playing';
  const body = $('#npv-body');
  if (!t) {
    body.replaceChildren(h('p.npv-empty', { text: 'Nothing is playing. Double-click a song to start.' }));
    return;
  }
  const like = h('button.icon-btn.like', {
    'aria-label': likeLabel(t),
    'aria-pressed': String(state.liked.has(t.uri)),
    dataset: { uri: t.uri || '' },
    onclick: () => toggleLike(t),
  }, icon('heart'));
  const next = q.tracks[q.pos + 1];
  body.replaceChildren(
    h('img.npv-art', { src: t.imageLarge || t.image || '', alt: '' }),
    h('div.npv-meta',
      h('div.tt',
        h('div.name', t.album && t.album.id ? h('a', { href: `#album/${t.album.id}`, text: t.name }) : t.name),
        h('div.by', artistLinks(t.artists))),
      t.uri && !isEpisode(t) ? like : null,
      t.uri ? h('button.icon-btn', { 'aria-label': 'Add to playlist', title: 'Add to playlist', onclick: (e) => addToPlaylistMenu([t], e.clientX, e.clientY) }, icon('plusCircle')) : null
    ),
    h('div.npv-card',
      h('div.hd', h('span', { text: 'Next in queue' }), h('button', { text: 'Open queue', onclick: () => showSidePanel('queue') })),
      next
        ? h('div.qrow', { ondblclick: () => player.jump(q.pos + 1), title: 'Double-click to play' },
            h('img', { src: next.image || '', alt: '' }),
            h('div.tt', h('div.name', { text: next.name }), h('div.by', { text: next.artists.map((a) => a.name).join(', ') })))
        : h('p.muted', { text: 'Nothing else is queued.', style: 'margin:4px' })
    )
  );
}

// Now playing view and Queue share the right side; only one shows at a time.
function showSidePanel(which) {
  const npv = $('#nowplaying');
  const qp = $('#queue');
  npv.hidden = which !== 'npv';
  qp.hidden = which !== 'queue';
  $('#npv-btn').setAttribute('aria-pressed', String(which === 'npv'));
  $('#queue-btn').setAttribute('aria-pressed', String(which === 'queue'));
  try { localStorage.setItem('ft.sidePanel', which || ''); } catch {}
  renderNowPlayingView();
  renderQueue();
}
$('#npv-btn').onclick = () => showSidePanel($('#nowplaying').hidden ? 'npv' : null);
$('#npv-close').onclick = () => showSidePanel(null);

// ── queue panel ────────────────────────────────────────────────────────────────
function renderQueue() {
  renderNowPlayingView();
  const panel = $('#queue');
  if (panel.hidden) return;
  const q = state.queue;
  const list = $('#queue-list');
  const row = (t, pos) =>
    h('div.qrow', { ondblclick: () => player.jump(pos), oncontextmenu: (e) => { e.preventDefault(); trackMenu(t, e); }, title: 'Double-click to play' },
      h('img', { src: t.image || '', alt: '', loading: 'lazy' }),
      h('div.tt', h('div.name', { text: t.name }), h('div.by', { text: t.artists.map((a) => a.name).join(', ') }))
    );
  const cur = q.tracks[q.pos];
  const upcoming = q.tracks.slice(q.pos + 1, q.pos + 81);
  list.replaceChildren(
    ...[
      cur ? [h('h3', { text: 'Now playing' }), Object.assign(row(cur, q.pos), { className: 'qrow current' })] : h('p.muted', { text: 'Nothing is playing. Double-click a song to start.', style: 'padding:6px' }),
      upcoming.length ? [h('h3', { text: q.sourceName ? `Next from ${q.sourceName}` : 'Next up' }), upcoming.map((t, i) => row(t, q.pos + 1 + i))] : null,
    ].flat(Infinity).filter(Boolean)
  );
}
function toggleQueue(force) {
  const open = force != null ? force : $('#queue').hidden;
  showSidePanel(open ? 'queue' : null);
}
$('#queue-btn').onclick = () => toggleQueue();
$('#queue-close').onclick = () => toggleQueue(false);

// ── search box ─────────────────────────────────────────────────────────────────
let searchTimer;
$('#search-input').addEventListener('input', (e) => {
  clearTimeout(searchTimer);
  const q = e.target.value.trim();
  searchTimer = setTimeout(() => {
    const target = `#search/${encodeURIComponent(q)}`;
    if (location.hash.startsWith('#search')) history.replaceState(null, '', target);
    else history.pushState(null, '', target);
    route();
  }, 350);
});
$('#search-form').addEventListener('submit', (e) => {
  e.preventDefault();
  clearTimeout(searchTimer);
  location.hash = `search/${encodeURIComponent($('#search-input').value.trim())}`;
});

// ── keyboard ───────────────────────────────────────────────────────────────────
document.addEventListener('keydown', (e) => {
  const typing = /^(INPUT|TEXTAREA)$/.test(document.activeElement.tagName) && document.activeElement.type !== 'range';
  if (e.key === 'Escape') closeMenu();
  if ((e.ctrlKey && e.key.toLowerCase() === 'f') || (e.ctrlKey && e.key.toLowerCase() === 'l')) {
    e.preventDefault();
    $('#search-input').focus();
    $('#search-input').select();
    return;
  }
  if (e.altKey && e.key === 'ArrowLeft') return history.back();
  if (e.altKey && e.key === 'ArrowRight') return history.forward();
  if (typing) return;
  if (e.code === 'Space' && !/^(BUTTON|A)$/.test(document.activeElement.tagName)) {
    e.preventDefault();
    player.toggle();
  } else if (e.ctrlKey && e.key === 'ArrowRight') player.next(false);
  else if (e.ctrlKey && e.key === 'ArrowLeft') player.prev();
  else if (e.ctrlKey && e.key === 'ArrowUp') { e.preventDefault(); player.setVolume($('#volume').value / 100 + 0.05); }
  else if (e.ctrlKey && e.key === 'ArrowDown') { e.preventDefault(); player.setVolume($('#volume').value / 100 - 0.05); }
  else if (e.key.toLowerCase() === 'm' && !e.ctrlKey) $('#mute').click();
  else if (e.key.toLowerCase() === 'l' && !e.ctrlKey) $('#lyrics-btn').click();
});

// ── playback engine (first-run download) ───────────────────────────────────────
function engineBanner(s) {
  const b = $('#engine-banner');
  if (!s || s.state === 'ready') {
    b.hidden = true;
    document.body.classList.remove('has-banner');
    if (s && s.state === 'ready') toast('Playback engine ready');
    return;
  }
  b.hidden = false;
  document.body.classList.add('has-banner');
  b.classList.toggle('error', s.state === 'error');
  if (s.state === 'downloading') {
    b.replaceChildren(h('span', { text: 'Setting up the playback engine. This happens once and takes a few seconds.' }), h('progress', { max: '1', value: String(s.progress || 0) }));
  } else {
    b.replaceChildren(
      h('span', { text: `The playback engine didn’t download: ${s.message}. Check your internet connection.` }),
      h('button.pill', { text: 'Try again', onclick: () => { engineBanner({ state: 'downloading', progress: 0 }); ft.engineEnsure(); } })
    );
  }
}

// ── updates ────────────────────────────────────────────────────────────────────
// Save an update file (e.g. "FreeTune-1.2.0.update") into Downloads and this banner appears.
function updateBanner(u) {
  const b = $('#update-banner');
  if (!u) {
    b.hidden = true;
    document.body.classList.remove('has-update');
    return;
  }
  const go = h('button.pill.primary', { text: 'Restart and update', onclick: async () => {
    go.disabled = true;
    go.textContent = 'Installing…';
    try {
      await api('updateApply');
    } catch (e) {
      go.disabled = false;
      go.textContent = 'Restart and update';
      toast(e.message, true);
    }
  } });
  b.replaceChildren(
    h('b', { text: `FreeTune ${u.version} is ready to install.` }),
    h('span.notes', { text: u.notes || `You have ${u.current}.` }),
    go,
    h('button.pill', { text: 'Later', onclick: () => updateBanner(null) }));
  b.hidden = false;
  document.body.classList.add('has-update');
}
function updatesSection(version) {
  const check = h('button.pill', { text: 'Check for updates', onclick: async () => {
    check.disabled = true;
    try {
      const u = await api('updateCheck');
      if (u) updateBanner(u);
      else toast('No newer FreeTune update found in your Downloads folder.');
    } catch (e) {
      toast(e.message, true);
    }
    check.disabled = false;
  } });
  const pick = h('button.pill', { text: 'Install update file…', onclick: async () => {
    try {
      const u = await api('updatePick');
      if (u) updateBanner(u);
    } catch (e) {
      toast(e.message, true);
    }
  } });
  return h('section',
    h('h2', { text: 'Updates' }),
    h('p', { text: `You have version ${version}. To update, save the .update file you’re sent into your Downloads folder. FreeTune notices it and offers to restart. Only signed updates made for FreeTune are accepted.` }),
    h('div.btns', check, pick));
}

ft.onEngineStatus(engineBanner);
ft.onUpdate(updateBanner);
ft.updateCheck().then((r) => r && r.ok && r.data && updateBanner(r.data));

// ── start ──────────────────────────────────────────────────────────────────────
(async function boot() {
  // The saved copy of the screens is read first, so the app opens straight to your home
  // page and library while Spotify is asked for anything new in the background.
  const [snap, vol, shuffle, repeat, dls, eng, ytl, extras] = await Promise.all([
    ft.uiCacheGet().catch(() => null),
    ft.getSetting('volume'),
    ft.getSetting('shuffle'),
    ft.getSetting('repeat'),
    ft.downloadsStatus().catch(() => null),
    ft.engineStatus(),
    ft.ytLiked ? ft.ytLiked().catch(() => null) : null,
    ft.playlistExtras ? ft.playlistExtras().catch(() => null) : null,
  ]);
  player.setVolume(vol && vol.ok && typeof vol.data === 'number' ? vol.data : 0.8, false);
  if (shuffle && shuffle.ok && shuffle.data) { state.shuffle = true; $('#shuffle').setAttribute('aria-pressed', 'true'); }
  if (repeat && repeat.ok && repeat.data) player.setRepeat(repeat.data);
  if (eng && eng.ok && !eng.data.installed) engineBanner({ state: 'downloading', progress: 0 });
  if (dls && dls.ok) applyDownloads(dls.data);
  ft.onDownloads(applyDownloads);
  if (extras && extras.ok && extras.data) state.extras = extras.data;
  if (ytl && ytl.ok) state.ytLiked = Array.isArray(ytl.data) ? ytl.data : [];

  const copy = snap && snap.ok && snap.data && snap.data.v === 1 && snap.data.user ? snap.data : null;
  if (copy) applySnapshot(copy);
  setYtLiked(state.ytLiked);
  if (copy) {
    onSignedIn(copy.user, { fromCopy: true });
  } else {
    main.replaceChildren(h('div.signin', h('div.skeleton', { style: 'width:240px;height:18px' })));
  }
  try {
    const s = await api('authStatus');
    if (s.signedIn) await onSignedIn(s.user, { refresh: !!copy });
    else {
      ft.uiCacheSet(null).catch(() => {});
      showSignIn();
    }
  } catch (e) {
    if (copy) {
      toast('Can’t reach Spotify right now. Showing what was saved; downloaded music still plays.', true);
      return;
    }
    main.replaceChildren(h('div.signin', h('div.signin-card',
      h('h1', { text: 'Can’t reach Spotify' }),
      h('p', { text: e.message }),
      h('button.pill.primary', { text: 'Try again', onclick: () => location.reload() })
    )));
  }
})();
