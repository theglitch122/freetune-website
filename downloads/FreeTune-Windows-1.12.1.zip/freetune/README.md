# FreeTune

Your Spotify playlists, liked songs, home recommendations and search, played ad-free from
YouTube Music, with no tracking. Built for Windows 10 and 11.

## Install (Windows 10/11)

1. Extract this zip to a folder you'll keep (for example `Documents\FreeTune`).
2. Double-click **Install FreeTune.bat**.
3. Wait 2–5 minutes. It downloads what it needs (about 250 MB), builds the app, and opens
   the installer.
4. Windows may say "Windows protected your PC" because the app isn't code-signed.
   Click **More info**, then **Run anyway**.
5. Open FreeTune and click **Sign in with Spotify**. A free account works.

The first time you play a song, FreeTune downloads its playback engine (yt-dlp, about
15 MB). After that it starts instantly and updates itself every couple of days.

## Using it

- Double-click any song to play. Space plays and pauses, Ctrl+Left/Right skips,
  Ctrl+F searches. Your keyboard's media keys work too.
- Right-click a song for Play next, Add to queue, Go to album or artist, and
  **Wrong song?** to paste the right YouTube link if a match is off.
- The heart saves songs to your Spotify Liked songs.
- The microphone button (or the L key) shows lyrics. Synced lyrics follow the song and
  highlight the current line; click any line to jump to it. Lyrics come from LRCLIB,
  KuGou and YouTube Music, in that order.
- **Discord status** (optional): Settings → Discord shows the song you're playing on your
  Discord profile. It needs a free Application ID from discord.com/developers; the steps
  are in Settings.

## How it works, and what it doesn't do

- **Spotify** is used only for data: your library, playlists, recommendations and search.
  You sign in on Spotify's own page. FreeTune never streams audio from Spotify, so there
  are no Spotify ads. Spotify's ad and tracking requests are blocked in the sign-in window.
- **Audio** comes from YouTube Music, found by matching title, artist and length. It's
  fetched without a Google account or cookies, so plays aren't tied to you.
- **No servers, no analytics.** Settings, saved matches and a troubleshooting log stay in
  `%APPDATA%\FreeTune`.

Things to know:

- This uses unofficial Spotify and YouTube interfaces, as Meld does. It breaks when they
  change, and it isn't permitted by either service's terms. The risk to your accounts is
  low but not zero.
- Spotify's internal query IDs change every few weeks. FreeTune reads the list that the
  Meld project keeps up to date, so it normally fixes itself on the next launch.
- If playback stops working, go to **Settings → Update playback engine**.
- Podcasts and audiobooks aren't supported.

## Troubleshooting

- **Setup can't download anything:** check your internet connection, and that antivirus
  isn't blocking PowerShell. Then run **Install FreeTune.bat** again.
- **Songs skip with an error:** Settings → Update playback engine. If that doesn't help,
  Settings → Open log folder and look at `freetune.log`.
- **Spotify pages say a query changed:** restart FreeTune so it picks up the newest
  query list.

## For developers

```
npm install
npm start            # run from source
npm run build:win    # build dist/FreeTune-Setup-<version>.exe
```

Code layout: `src/main` (Spotify client, YouTube matching, yt-dlp manager, local audio
relay), `src/renderer` (interface), `src/preload.js` (the bridge between them).

## Updating

Save the update file you're given (for example `FreeTune-1.2.0.update`) into your
**Downloads** folder. FreeTune notices it within a few seconds and shows
**Restart and update**. Click it: FreeTune closes, swaps in the new version and reopens.
Your settings, history and downloads are kept. You can also use
**Settings → Updates → Install update file…** for a file saved somewhere else.

Updates are saved next to the installed version, so nothing in use is replaced, and
the app restarts into the newest one. If a new version ever fails to start three times in
a row, the app goes back to the previous one by itself.

Update files are signed. FreeTune only installs files signed with this project's key, made
for FreeTune, and newer than what you have, so a random file can't replace it.

To make an update yourself after changing the code: `node scripts/make-update.js "What changed"`.
It needs `signing/update-key.pem`. Keep that file private: anyone who has it can make
updates your apps will accept.

## Credits and license

Spotify integration (GraphQL queries and response parsing) and the track-matching
algorithm are ported from [Meld](https://github.com/FrancescoGrazioso/Meld) by Francesco
Grazioso. Audio extraction by [yt-dlp](https://github.com/yt-dlp/yt-dlp). FreeTune is
licensed under the GNU GPL v3 or later (see `LICENSE`). Not affiliated with Spotify or
YouTube.
