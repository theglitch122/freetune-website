﻿# Installs FreeTune 1.12.2 over FreeTune 1.12.1 (or any installed version).
# It adds app-1.12.2.asar next to the installed app, the same way FreeTune's own updater
# does. Nothing is replaced or deleted, and your settings, likes and downloads are kept.
# FreeTune picks the newest version it finds the next time it starts.

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$version = '1.12.2'
$asarName = "app-$version.asar"
$source = Join-Path $here $asarName
$expected = '8cc294fb0e48bffbba97230edf49ec2ce8952ae23fff742dc2c1d09b5d5dc63a'

function Done($msg, $color = 'Green') {
  Write-Host ''
  Write-Host $msg -ForegroundColor $color
  Write-Host ''
  Read-Host 'Press Enter to close'
  exit
}

Write-Host "FreeTune $version update" -ForegroundColor White

if (-not (Test-Path $source)) { Done "$asarName is missing. Unzip the whole folder first, then run this again." 'Red' }
if ((Get-FileHash -Algorithm SHA256 $source).Hash.ToLower() -ne $expected) { Done "$asarName is damaged. Download the update again." 'Red' }

# -- find where FreeTune is installed --
$candidates = New-Object System.Collections.Generic.List[string]
Get-Process -Name 'FreeTune' -ErrorAction SilentlyContinue | ForEach-Object { if ($_.Path) { $candidates.Add((Split-Path -Parent $_.Path)) } }
foreach ($root in 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall') {
  Get-ChildItem $root -ErrorAction SilentlyContinue | ForEach-Object {
    $p = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
    if ($p -and $p.DisplayName -like 'FreeTune*' -and $p.InstallLocation) { $candidates.Add($p.InstallLocation.Trim('"')) }
  }
}
$shell = New-Object -ComObject WScript.Shell
foreach ($lnk in @("$env:USERPROFILE\Desktop\FreeTune.lnk", "$env:PUBLIC\Desktop\FreeTune.lnk", "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\FreeTune.lnk", "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\FreeTune.lnk")) {
  if (Test-Path $lnk) { $t = $shell.CreateShortcut($lnk).TargetPath; if ($t -like '*FreeTune.exe') { $candidates.Add((Split-Path -Parent $t)) } }
}
$candidates.Add("$env:LOCALAPPDATA\Programs\FreeTune")
$candidates.Add("$env:LOCALAPPDATA\Programs\freetune")
$candidates.Add("$env:ProgramFiles\FreeTune")

$installDir = $null
foreach ($c in $candidates) {
  if ($c -and (Test-Path (Join-Path $c 'FreeTune.exe')) -and (Test-Path (Join-Path $c 'resources\app.asar'))) { $installDir = $c; break }
}
if (-not $installDir) {
  Done "Couldn't find an installed FreeTune. If you run FreeTune from its setup folder instead of the installed app, tell Claude and it will send that version." 'Red'
}
$resources = Join-Path $installDir 'resources'
Write-Host "Found FreeTune in $installDir"

# -- add the new version next to the installed one --
$target = Join-Path $resources $asarName
$part = "$target.part"
try {
  Copy-Item $source $part -Force
  if ((Get-FileHash -Algorithm SHA256 $part).Hash.ToLower() -ne $expected) { throw 'The copy came out different.' }
  Move-Item $part $target -Force
} catch {
  Remove-Item $part -Force -ErrorAction SilentlyContinue
  Done "Couldn't save the update into $resources : $($_.Exception.Message)" 'Red'
}
Write-Host "Saved $asarName"

# -- restart FreeTune so it opens the new version --
if (Get-Process -Name 'FreeTune' -ErrorAction SilentlyContinue) {
  Write-Host ''
  Write-Host 'FreeTune is open. Quit it (right-click its icon in the taskbar and choose Close window), then come back here.' -ForegroundColor Yellow
  while (Get-Process -Name 'FreeTune' -ErrorAction SilentlyContinue) {
    $answer = Read-Host 'Press Enter once FreeTune is closed (or type S to skip and restart it yourself later)'
    if ($answer -match '^[Ss]') { Done "Done. FreeTune switches to $version the next time you open it." }
  }
  Start-Process (Join-Path $installDir 'FreeTune.exe')
  Done "Done. FreeTune $version is starting."
}
Done "Done. Open FreeTune and it starts on version $version."
