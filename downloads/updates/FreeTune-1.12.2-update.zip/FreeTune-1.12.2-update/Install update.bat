@echo off
title FreeTune 1.12.2 update
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-update.ps1"
