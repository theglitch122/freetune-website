FreeTune 1.12.2 for computers that have FreeTune 1.12.1

What's new since 1.12.1
- Lyrics translations: tap Translate on the lyrics screen. 32 languages, with the
  pronunciation for lyrics in another alphabet (Japanese, Korean, Chinese and more).
- Tyler, The Creator's Bastard (2009) in Your Library, played from YouTube.
- Songs with no cover show a music note instead of a broken picture.

How to install
1. Unzip this folder anywhere (for example your Downloads folder).
2. Double-click "Install update.bat".
3. If Windows says it protected your PC, click More info, then Run anyway.
4. If FreeTune is open, it asks you to close it, then reopens it on 1.12.2.

Your settings, playlists, likes and downloads are kept. Nothing is deleted: the update is
saved next to your installed FreeTune, the same way FreeTune's own updates are.

After this, future FreeTune update files install the normal way again (save them in your
Downloads folder).
